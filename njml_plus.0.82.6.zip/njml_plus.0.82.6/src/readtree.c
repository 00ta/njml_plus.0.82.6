/* Jan 20, 2001 - July 16, 2001 */

#include "protml.h"
#include "tools.h"
#define NS            1000
#define NBRANCH       (NS*2-2)

struct CommonInfo {
   char *z[2*NS-1], spname[NS][10], daafile[96];
   int ns,ls,npatt,*fpatt,np,ntime,ncode,clock,rooted,model,icode,cleandata;
   int seqtype, *pose;
   double kappa, omega, alpha, pi[64],*rates, *chunk, daa[20*20];
}  com;
struct TREEB {
   int nbranch, nnode, origin, branches[NBRANCH][2];
}  tree;
struct TREEN {
   int father, nson, sons[3], ibranch;
   double branch, divtime, omega, *lkl, daa[20*20];
}  nodes[2*NS-1];
static char *PARTITION;

int ReadaTreeN ();
int ReadaTreeN2 ();

int ReadaTreeN (FILE *ftree, int *hasbranch, int popline)
{
/* Read a tree from ftree, using the parenthesis node representation of trees.
   If branch lengths are provided, they are read in nodes[].branch, with
   hasbranch set to 1.  Both names and numbers for species are fine.  
   Species names are considered case-sensitive, with trailing blanks ignored;
   they have to match the names in the sequence data file.
*/
   int cnode, cfather=-1;  /* current node and father */
   int inodeb=0;  /* node number that will have the next branch length */
   int i,j, level=0, hasname, ch=' ';
   char check[NS], line[255], delimiters[]="(),:#";

   *hasbranch=0;
   while(isspace(ch)) ch=fgetc(ftree);
   ungetc(ch, ftree);
   if (isdigit(ch)) { ReadaTreeB (ftree, popline); return (0); }

   tree.nnode=com.ns;  tree.nbranch=0;
   FOR (i, 2*com.ns-1) ClearNode (i);
   FOR (i, com.ns) check[i]=0;
   for (;;) {
      ch = fgetc (ftree);
      if (ch==EOF) return(-1);
      else if (!isgraph(ch)) continue;
      else if (ch=='(') {
         level++;
         cnode=tree.nnode++;
         if (cfather>=0) {
            nodes[cfather].sons[nodes[cfather].nson++] = cnode;
            nodes[cnode].father=cfather;
            tree.branches[tree.nbranch][0]=cfather;
            tree.branches[tree.nbranch][1]=cnode;
            nodes[cnode].ibranch=tree.nbranch++;
         }
         else
            tree.origin=cnode;
         cfather=cnode;
      }
      else if (ch==')')
         { level--;  inodeb=cfather; cfather=nodes[cfather].father; }
      else if (ch==':') {
         *hasbranch=1; fscanf(ftree,"%lf",&nodes[inodeb].branch);
      }
#ifdef BASEML
      else if (ch=='#') {
         fscanf(ftree,"%lf",&nodes[inodeb].parmark);
      }
#endif
      else if (ch==',') ;
      else { /* read species name or number */
         line[0]=(char)ch;  line[1]=(char)fgetc(ftree);
         if (com.ns<10 && isdigit(line[0]) && isdigit(line[1])) 
           { ungetc(line[1], ftree); line[1]=0; }
         else 
            for (i=1; ; )  { 
               if (strchr(delimiters,line[i]))
                  { ungetc(line[i], ftree); line[i]=0; break; }
               line[++i]=(char)fgetc(ftree);
         }
         for(j=i-1; j>0; j--)    if (!isgraph(line[j])) line[j]=0;
         for(i=0,hasname=0; line[i]; i++)  if (!isdigit(line[i])) hasname=1;

         if (hasname) {   /* name */
            for (i=0; i<com.ns; i++) if (!strcmp(line,com.spname[i])) break;
            if ((cnode=i)==com.ns) printf("\nSpecies %s?\n", line);
         }
         else {           /* number */
            sscanf(line, "%d", &cnode);   cnode--;
            if (cnode<0 || cnode>=com.ns)
               { printf("\nspecies # %d in ReadaTreeN\n", cnode+1); exit(-1); }
         }
         nodes[cnode].father=cfather;
         nodes[cfather].sons[nodes[cfather].nson++]=cnode;
         tree.branches[tree.nbranch][0]=cfather;
         tree.branches[tree.nbranch][1]=cnode;
         nodes[cnode].ibranch=tree.nbranch++;
         check[inodeb=cnode]++;
      }
      if (level==0) break;
   }
   if (popline) fgets (line, 254, ftree);
   if (tree.nnode != tree.nbranch+1)
      printf ("\n??nnode%6d   nbranch%6d\n", tree.nnode, tree.nbranch);

   com.ntime = com.clock ? tree.nnode-com.ns+(tree.origin<com.ns)
                         : tree.nbranch;

   FOR(i,com.ns)  if(check[i]!=1) return(-1);
   if(tree.nbranch>2*com.ns-2) { 
      printf("nbranch %d", tree.nbranch); error("too many branches in tree?");
   }

   return (0);
}

int ReadaTreeB (FILE *ftree, int popline)
{
   char line[255];
   int i,j, state=0, YoungAncestor=0;

   fscanf (ftree, "%d", &tree.nbranch);
   FOR (j, tree.nbranch) {
      FOR (i,2) {
         if (fscanf (ftree, "%d", & tree.branches[j][i]) != 1) state=-1;
         tree.branches[j][i]--;
         if(tree.branches[j][i]<0 || tree.branches[j][i]>com.ns*2-1) 
            error("err ReadaTreeB.");
      }
      if (tree.branches[j][0]<com.ns) YoungAncestor=1;
/*
      printf ("\nBranch #%3d: %3d -> %3d",
         j+1, tree.branches[j][0]+1,tree.branches[j][1]+1);
*/
   }
   if(popline) fgets(line, 254, ftree);
   tree.origin=tree.branches[0][0];
   if (YoungAncestor) error("Ancestors in the data?  To be fixed later.");

   com.ntime = com.clock ? tree.nnode-com.ns+(tree.origin<com.ns)
                         : tree.nbranch;

   BranchToNode ();
   return (state);
}

void ClearNode (int inode)
{
   nodes[inode].father=nodes[inode].ibranch=-1;
   nodes[inode].nson=0;
   /* nodes[inode].branch=0; clear node structure only, not branch lengths */
   /* FOR (i, com.ns) nodes[inode].sons[i]=-1; */
}

int ReadaTreeN2 (char *ctree, int *hasbranch, int popline, int ns)
{
/* Read a tree from ftree, using the parenthesis node representation of trees.
   If branch lengths are provided, they are read in nodes[].branch, with
   hasbranch set to 1.  Both names and numbers for species are fine.  
   Species names are considered case-sensitive, with trailing blanks ignored;
   they have to match the names in the sequence data file.
*/
   int cnode, cfather=-1;  /* current node and father */
   int inodeb=0;  /* node number that will have the next branch length */
   int i,j, level=0, hasname, ch=' ';
   char check[NS], line[255], delimiters[]="(),:#";

   com.ns = ns;
   *hasbranch=0;
   while(isspace(ch)) ch=*ctree; ctree++;
   ctree--;

   tree.nnode=com.ns;  tree.nbranch=0;
   FOR (i, 2*com.ns-1) ClearNode (i);
   FOR (i, com.ns) check[i]=0;
   for (;;) {
     ch = *ctree; ctree++;
     if (ch=='\0') return(-1);
     else if (!isgraph(ch)) continue;
     else if (ch=='(') {
         level++;
         cnode=tree.nnode++;
         if (cfather>=0) {
            nodes[cfather].sons[nodes[cfather].nson++] = cnode;
            nodes[cnode].father=cfather;
            tree.branches[tree.nbranch][0]=cfather;
            tree.branches[tree.nbranch][1]=cnode;
            nodes[cnode].ibranch=tree.nbranch++;
         }
         else
            tree.origin=cnode;
         cfather=cnode;
      }
      else if (ch==')')
         { level--;  inodeb=cfather; cfather=nodes[cfather].father; }
      else if (ch==':') {
         *hasbranch=1; sscanf(ctree,"%lf",&nodes[inodeb].branch);
      }
#ifdef BASEML
      else if (ch=='#') {
         fscanf(ftree,"%lf",&nodes[inodeb].parmark);
      }
#endif
      else if (ch==',') ;
      else { /* read species name or number */
	line[0]=(char)ch;  line[1]=*ctree; ctree++;
	if (com.ns<10 && isdigit(line[0]) && isdigit(line[1])) 
	  { ctree--; line[1]=0; }
	else 
	  for (i=1; ; )  { 
	    if (strchr(delimiters,line[i]))
	      { ctree--; line[i]=0; break; }
	    line[++i]=*ctree; ctree++;
	  }
         for(j=i-1; j>0; j--)    if (!isgraph(line[j])) line[j]=0;
         for(i=0,hasname=0; line[i]; i++)  if (!isdigit(line[i])) hasname=1;

         if (hasname) {   /* name */
	   /*
            for (i=0; i<com.ns; i++) if (!strcmp(line,com.spname[i])) break;
	    */
            for (i=0; i<com.ns; i++) if (!strcmp(line,Identif[i])) break;
            if ((cnode=i)==com.ns) printf("\nSpecies %s?\n", line);
         }
         else {           /* number */
	   sscanf(line, "%d", &cnode);   cnode--;
	   if (cnode<0 || cnode>=com.ns)
	     { printf("\nspecies # %d in ReadaTreeN\n", cnode+1); exit(-1); }
         }
         nodes[cnode].father=cfather;
         nodes[cfather].sons[nodes[cfather].nson++]=cnode;
         tree.branches[tree.nbranch][0]=cfather;
         tree.branches[tree.nbranch][1]=cnode;
         nodes[cnode].ibranch=tree.nbranch++;
         check[inodeb=cnode]++;
      }
     if (level==0) break;
   }
   /*
   if (popline) fgets (line, 254, ftree);
   */
   if (tree.nnode != tree.nbranch+1)
      printf ("\n??nnode%6d   nbranch%6d\n", tree.nnode, tree.nbranch);

   com.ntime = com.clock ? tree.nnode-com.ns+(tree.origin<com.ns)
                         : tree.nbranch;

   FOR(i,com.ns)  if(check[i]!=1) return(-1);
   if(tree.nbranch>2*com.ns-2) { 
      printf("nbranch %d", tree.nbranch); error("too many branches in tree?");
   }

   return (0);
}

void BranchToNode (void)
{
/* tree.origin need to be specified before calling this
*/
   int i,j, from, to;
   
   tree.nnode=tree.nbranch+1;
/*
   if (tree.origin<0 || tree.origin>com.ns*2-2) 
      { printf ("root at %d", tree.origin+1); error ("tree origin"); }
*/
   FOR (j,tree.nnode) ClearNode (j);   /* Is this necessary? */
   FOR (i,tree.nbranch) {
      from=tree.branches[i][0];
      to  =tree.branches[i][1];
      nodes[from].sons[nodes[from].nson++]=to;
      nodes[to].father=from;
      nodes[to].ibranch=i;
   }
/*
   printf("\nNode\n%7s%7s%7s%7s%7s\n","father","node","branch","nson:","sons");
   FOR (i, tree.nnode) {
      printf ("\n%7d%7d%7d:%7d",
         nodes[i].father+1, i+1, nodes[i].ibranch+1, nodes[i].nson);
      FOR (j, nodes[i].nson) printf ("%4d", nodes[i].sons[j]+1);
   }
*/
}

void BranchPartition (char partition[], int parti2B[])
{
/* calculates branch partitions.
   partition[0,...,ns-1] marks the species bi-partition by the first interior 
   branch.  It uses 0 and 1 to indicate which side of the branch each species 
   is.  
   partition[ns,...,2*ns-1] marks the second interior branch.
   parti2B[0] maps the partition (internal branch) to the branch in tree.
   Use NULL for parti2B if this information is not needed.
   partition[nib*com.ns].  nib: # of interior branches.
*/
   int i,j, nib;  /* number of internal branches */

   for (i=0,nib=0; i<tree.nbranch; i++) {
      if (tree.branches[i][1]>=com.ns){
         PARTITION=partition+nib*com.ns;
         FOR (j,com.ns) PARTITION[j]=0;
         DescentGroup (tree.branches[i][1]);
         if (parti2B) parti2B[nib]=i;
         nib++;
      }
   }
   if (nib!=tree.nbranch-com.ns) error("err BranchPartition"); 
}

int OutaTreeN (FILE *fout, int spnames, int branchlen)
{
   OutSubTreeN (fout, tree.origin, spnames, branchlen);
   return (0);
}

int OutaTreeB (FILE *fout)
{
   int j;
   char *fmt[]={" %3d..%-3d", " %2d..%-2d"};
   FOR (j, tree.nbranch)
      fprintf(fout, fmt[0], tree.branches[j][0]+1,tree.branches[j][1]+1);
   return (0);
}

int NSameBranch (char partition1[],char partition2[], int nib1,int nib2,
    int IBsame[])
{
/* counts the number of correct (identical) bipartitions.
   nib1 and nib2 are the numbers of interior branches in the two trees
   correctIB[0,...,(correctbranch-1)] lists the correct interior branches, 
   that is, interior branches in tree 1 that is also in tree 2.
   IBsame[i]=1 if interior branch i is correct.
*/
   int i,j,k, nsamebranch,nsamespecies;

   for (i=0,nsamebranch=0; i<nib1; i++)  for(j=0,IBsame[i]=0; j<nib2; j++) {
      for (k=0,nsamespecies=0;k<com.ns;k++)
         nsamespecies+=(partition1[i*com.ns+k]==partition2[j*com.ns+k]);
      if (nsamespecies==0 || nsamespecies==com.ns)
         { nsamebranch++;  IBsame[i]=1;  break; } 
   }
   return (nsamebranch);
}

void DescentGroup (int inode)
{
   int i;
   for (i=0; i<nodes[inode].nson; i++) 
      if (nodes[inode].sons[i]<com.ns) 
         PARTITION[nodes[inode].sons[i]]=1;
      else 
         DescentGroup (nodes[inode].sons[i]);
}

int OutSubTreeN (FILE *fout, int inode, int spnames, int branchlen)
{
   int i;

   fputc ('(', fout);

   FOR (i, nodes[inode].nson) {
      if (nodes[nodes[inode].sons[i]].nson <= 0) {
         if (spnames) fprintf (fout, "%s", com.spname[nodes[inode].sons[i]]);
         else         fprintf (fout, "%d", nodes[inode].sons[i]+1);
      }
      else
         OutSubTreeN (fout, nodes[inode].sons[i], spnames, branchlen);
      if (branchlen)fprintf(fout,":%.6f", nodes[nodes[inode].sons[i]].branch);

      if (com.ns>9 || spnames || branchlen)
         if (i<nodes[inode].nson-1) fprintf(fout, ", ");
   }
   fputc (')', fout);
   return (0);
}

void error (char * message)
{ printf("\n%s.\n", message);    exit (-1); }
