//
//  removeibranch.c
//  conbstree_plus
//
//  Created by Satoshi Oota on 3/27/14.
//  Copyright (c) 2014 Satoshi Oota. All rights reserved.
//

/* Remove an internal branch */

#include "protml.h"

void removeibranch(Tree * tree, int ibranch) {
    Node *rp, *np;
    
    rp = tree->ibrnchp[ibranch];
    for (np = rp->isop; np != rp; np = np->isop) {
        if (np->isop == rp) {
            np->isop = tree->ibrnchp[ibranch]->kinp->isop;
            if (tree->rootp == rp)
                tree->rootp = np->isop;
            break;
        }
    }
    rp = tree->ibrnchp[ibranch]->kinp;
    for (np = rp->isop; np != rp; np = np->isop) {
        if (np->isop == rp) {
            np->isop = tree->ibrnchp[ibranch]->isop;
            tree->rootp = np->isop;
            if (tree->rootp == rp)
                tree->rootp = np->isop;
            break;
        }
    }
    /* Remove the internal branch completely */
    rp->isop = NULL;
    rp->kinp->isop = NULL;
}


