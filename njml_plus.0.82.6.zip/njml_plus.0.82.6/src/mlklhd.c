/*
 * mlklhd.c   Adachi, J.   1994.06.26
 * Copyright (C) 1992-1994 J. Adachi & M. Hasegawa; All rights reserved.
 */

/* Modified by Satoshi Ota (OOta) Oct 12, 2000 - Jan 20, 2001 */

/* Modification: */
/* In mlvalue Infotree->ltplgy is set; Jan 20, 2001 */
/* In mlvalue Infotree is sorted; Jan 17, 2001 */ 
/* In mlvalue a bootstrap value for the best is output */
/* Numbrnch was changed to Maxbrnch in mlvalue; Oct 12, 2000 */
/* Numbrnch was changed to Maxbrnch in mlikelihood_njml; Oct 12, 2000 */

#include "protml.h"

void reliml(Tree *, Node*, double, LPVECTOR, double*);
void noexch(Node *, ivector);
void reroot(Tree*, Node*);
void slslength(Tree *, dmatrix, int);
void evallkl(Node *);
double probnormal(double);
void localbp(dmatrix, LPVECTOR, LPCUBE, ivector, int, int);
void mlvalue();
void strctree();
void tdiffmtrx();
int lslength(Tree*, dvector, int);

#ifdef DEBUG
static void
prprob(xprob)
dmatrix xprob;
{
	int i, j;

	for (i = 0; i < Numptrn; i++) {
		for (j = 0; j < Tpmradix; j++)
			printf(" %3.0f", xprob[i][j] * 100.0);
		putchar('\n');
	}
} /* prprob */
#endif


void 
prodpart(op)
Node *op;
{
	Node *cp;
	int i;
	dvector opb, cpb;

	cp = op;
	while (cp->isop->isop != op) {
		cp = cp->isop;
		opb = *(op->iprob);
		cpb = *(cp->iprob);
		for (i = 0; i < Numptrn; i++) {
#ifndef NUC
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
#else		/* NUC */
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
			*opb++ *= *cpb++;
#endif		/* NUC */
		}
	}
/*	if (Debug) prprob(op->iprob); */
} /*_ prodpart */


void 
partilkl(op)
Node *op;
{
	int i, j, k;
	double sum;
	dmattpmty tprob;
	dmatrix oprob, cprob;
	dvector opb, cpb, cpb2, tpb;

	tprobmtrx(op->length, tprob);
	oprob = op->iprob;
	cprob = op->kinp->isop->iprob;
	for (k = 0; k < Numptrn; k++) {
		opb = oprob[k];
		cpb = cprob[k];
		tpb = *tprob;
#ifndef NUC
		for (i = 0; i < Tpmradix; i++) {
			cpb2 = cpb;
			sum  = *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			sum += *tpb++ * *cpb2++;
			opb[i] = sum;
		}
#else	/* NUC */
		opb[0] = tpb[ 0] * cpb[0] + tpb[ 1] * cpb[1]
			   + tpb[ 2] * cpb[2] + tpb[ 3] * cpb[3];
		opb[1] = tpb[ 4] * cpb[0] + tpb[ 5] * cpb[1]
			   + tpb[ 6] * cpb[2] + tpb[ 7] * cpb[3];
		opb[2] = tpb[ 8] * cpb[0] + tpb[ 9] * cpb[1]
		       + tpb[10] * cpb[2] + tpb[11] * cpb[3];
		opb[3] = tpb[12] * cpb[0] + tpb[13] * cpb[1]
			   + tpb[14] * cpb[2] + tpb[15] * cpb[3];
#endif	/* NUC */
	}
/*	if (Debug) prprob(oprob); */
} /*_ partilkl */


void 
partelkl(op)
Node *op;
{
	int i, j, k;
	dmattpmty tprob;
	dmatrix oprob;
	ivector dseqi;
	dvector opb;

	tprobmtrx(op->length, tprob);
	oprob = op->iprob;
	dseqi = op->kinp->eprob;
	for (k = 0; k < Numptrn; k++) {
	opb = oprob[k];
#ifndef NUC
		if ((j = dseqi[k]) >= 0) {
			for (i = 0; i < Tpmradix; i++)
				opb[i] = tprob[i][j];
		} else {
			for (i = 0; i < Tpmradix; i++)
				opb[i] = 1.0; /* !? */
		}
#else	/* NUC */
		if ((j = dseqi[k]) >= 0) {
			opb[0] = tprob[0][j];
			opb[1] = tprob[1][j];
			opb[2] = tprob[2][j];
			opb[3] = tprob[3][j];
		} else {
			opb[0] = 1.0;
			opb[1] = 1.0;
			opb[2] = 1.0;
			opb[3] = 1.0;
		}
#endif	/* NUC */
	}
#if 0
	for (i = 0; i < Numptrn; i++) printf("%2d", dseqi[i]); putchar('\n');
	for (i = 0; i < Tpmradix; i++) {
		for (j = 0; j < Tpmradix; j++) printf(" %3.0f", tprob[i][j] * 100.0);
		putchar('\n');
	}
#endif
} /*_ partelkl */


void 
initpartlkl(tr)
Tree *tr;
{
	Node *cp, *rp;

	cp = rp = tr->rootp;
	do {
		cp = cp->isop->kinp;
		if (cp->isop == NULL) { /* external node */
			if (Debug) printf("mle\t%3d\t%2d\n", cp->number, cp->descen);
			cp = cp->kinp; /* not descen */
			partelkl(cp);
		} else { /* internal node */
			if (Debug) printf("mli\t%3d\t%2d\n", cp->number, cp->descen);
			if (!cp->descen) {
				prodpart(cp->kinp->isop);
				partilkl(cp);
			}
		}
	} while (cp != rp);
} /*_ initpartlkl */


void 
mlibranch(op, loop) /* Optimize internal branches */
Node *op; /* op->kinp == descen */
int loop;
{
	int i, j, k, it, numloop;
	double sumlk, sumd1, sumd2, lkld1, lkld2, prod1, prod2, vari, lklhd;
	double arc, arcold, arcdiff, arcpre, slk, sd1, sd2;
	dmattpmty tprob, tdif1, tdif2;
	dmatrix oprob, cprob;
	dvector tpb, td1, td2, opb, cpb;
#ifdef NUC
	double cpb0, cpb1, cpb2, cpb3;
#endif /* NUC */

	oprob = op->isop->iprob;
	cprob = op->kinp->isop->iprob;
	arc = op->length; /* Branch length */
	arcpre = arc;
/*	if (Debug) { prprob(oprob); prprob(cprob); } */
	loop < 3 ? (numloop = 1) : (numloop = 3);
	for (it = 0; it < numloop; it++) {
		tdiffmtrx(arc, tprob, tdif1, tdif2);
		lkld1 = lkld2 = 0.0;
		for (k = 0; k < Numptrn; k++) {
			sumlk = sumd1 = sumd2 = 0.0;
			opb = oprob[k];
			cpb = cprob[k];
#ifdef NUC
			cpb0 = cpb[0]; cpb1 = cpb[1]; cpb2 = cpb[2]; cpb3 = cpb[3];
#endif		/* NUC */
			for (i = 0; i < Tpmradix; i++) {
				tpb = tprob[i]; /* Transition prob matrix */
				td1 = tdif1[i];
				td2 = tdif2[i];
				prod1 = Freqtpm[i] * opb[i];
#ifndef NUC
				slk = sd1 = sd2 = 0.0;
				for (j = 0; j < Tpmradix; j++) {
					prod2 = cpb[j];
					slk += prod2 * tpb[j];
					sd1 += prod2 * td1[j];
					sd2 += prod2 * td2[j];
				}
				sumlk += prod1 * slk;
				sumd1 += prod1 * sd1;
				sumd2 += prod1 * sd2;
#else			/* NUC */
				slk = cpb0*tpb[0] + cpb1*tpb[1] + cpb2*tpb[2] + cpb3*tpb[3];
				sd1 = cpb0*td1[0] + cpb1*td1[1] + cpb2*td1[2] + cpb3*td1[3];
				sd2 = cpb0*td2[0] + cpb1*td2[1] + cpb2*td2[2] + cpb3*td2[3];
				sumlk += prod1 * slk;
				sumd1 += prod1 * sd1;
				sumd2 += prod1 * sd2;
#endif			/* NUC */
			}
			sumd1 /= sumlk;
			lkld1 += sumd1 * Weight[k];
			lkld2 += (sumd2 / sumlk - sumd1 * sumd1) * Weight[k];
		}
		vari = 1.0 / fabs(lkld2);
		arcold = arc;
		arcdiff = - (lkld1 / lkld2);
		arc += arcdiff;
		if (arc > MIDARC && arcpre < 10.0) arc = MINARC;
		if (arc < MINARC) arc = MINARC;
		if (arc > MAXARC) arc = MAXARC;
	/*	printf("mli\t%3d\t%8.3f\t%8.3f\t%12.7f\t%12.7f\t%10.3f\n",
			op->number, arc, arcold, arcdiff, lkld1, lkld2); */
		/* If the branch length no longer varies, stop iteration */
		if (fabs(arcold - arc) < EPSILON) break;
	}
	/* Branch lengths must be the same
	   in either directions */
	op->kinp->length = arc;
	op->length = arc;          
	op->lklhdl = vari; /* variance? */
	if (Debug)
		printf("mli\t%4d\t%3d\t%8.3f\t%8.3f\t%12.7f\t%12.7f\t%12.7f\t%10.3f\n",
		op->number, it+1, arc, arcpre, arcpre-arc, sqrt(vari), lkld1, lkld2);

	tprobmtrx(arc, tprob); /* Transition probability */
	if ((op->number == Numibrnch-1 && fabs(arc-arcpre) < EPSILON) ||
		loop == MAXIT-1) {
		for (k = 0, lklhd = 0.0; k < Numptrn; k++) {
			opb = oprob[k];
			cpb = cprob[k];
#ifdef NUC
			cpb0 = cpb[0]; cpb1 = cpb[1]; cpb2 = cpb[2]; cpb3 = cpb[3];
#endif		/* NUC */
			for (i = 0, sumlk = 0.0; i < Tpmradix; i++) {
				tpb = tprob[i];
				prod1 = Freqtpm[i] * opb[i];
#ifndef NUC
				for (j = 0, slk = 0.0; j < Tpmradix; j++)
					slk += cpb[j] * tpb[j];
				sumlk += prod1 * slk;
#else			/* NUC */
				slk = cpb0*tpb[0] + cpb1*tpb[1] + cpb2*tpb[2] + cpb3*tpb[3];
				sumlk += prod1 * slk;
#endif			/* NUC */
			}
			sumlk = log(sumlk);
			Alklptrn[k] = sumlk; /* Likelihood at a site */
			lklhd += sumlk * Weight[k];
		/*	printf("%3d %10.5f\n", k, sumlk); */
		} /* end of for loop */
		Ctree->lklhd = lklhd;
		printf("Ctree->lklhd = %f\n", Ctree->lklhd);
	}

#ifdef NUC
		tpb = tprob[0];
#endif	/* NUC */
	oprob = op->iprob;
	for (k = 0; k < Numptrn; k++) {
		opb = oprob[k];
		cpb = cprob[k];
#ifndef NUC
		for (i = 0; i < Tpmradix; i++) {
			tpb = tprob[i];
			for (j = 0, sumlk = 0.0; j < Tpmradix; j++)
				sumlk += tpb[j] * cpb[j];
			opb[i] = sumlk;
		}
#else	/* NUC */
		cpb0 = cpb[0]; cpb1 = cpb[1]; cpb2 = cpb[2]; cpb3 = cpb[3];
		opb[0] = tpb[ 0]*cpb0 + tpb[ 1]*cpb1 + tpb[ 2]*cpb2 + tpb[ 3]*cpb3;
		opb[1] = tpb[ 4]*cpb0 + tpb[ 5]*cpb1 + tpb[ 6]*cpb2 + tpb[ 7]*cpb3;
		opb[2] = tpb[ 8]*cpb0 + tpb[ 9]*cpb1 + tpb[10]*cpb2 + tpb[11]*cpb3;
		opb[3] = tpb[12]*cpb0 + tpb[13]*cpb1 + tpb[14]*cpb2 + tpb[15]*cpb3;
#endif	/* NUC */
	}
/*	if (Debug) prprob(oprob); */
} /*_ mlibranch */

void 
mlibranch_njml(tr, op, loop) /* Optimize internal branch lengths */
Tree *tr;
Node *op; /* op->kinp == descen */
int loop;
{
	int i, j, k, it, numloop;
	double sumlk, sumd1, sumd2, lkld1, lkld2, prod1, prod2, vari, lklhd;
	double arc, arcold, arcdiff, arcpre, slk, sd1, sd2;
	dmattpmty tprob, tdif1, tdif2;
	dmatrix oprob, cprob;
	dvector tpb, td1, td2, opb, cpb;
#ifdef NUC
	double cpb0, cpb1, cpb2, cpb3;
#endif /* NUC */

	oprob = op->isop->iprob;
	cprob = op->kinp->isop->iprob;
	arc = op->length; /* Branch length */
	arcpre = arc;
/*	if (Debug) { prprob(oprob); prprob(cprob); } */
	loop < 3 ? (numloop = 1) : (numloop = 3);
	for (it = 0; it < numloop; it++) {
#if 1
		tdiffmtrx(arc, tprob, tdif1, tdif2);
#endif
		lkld1 = lkld2 = 0.0;
		for (k = 0; k < Numptrn; k++) {
			sumlk = sumd1 = sumd2 = 0.0;
			opb = oprob[k];
			cpb = cprob[k];
#ifdef NUC
			cpb0 = cpb[0]; cpb1 = cpb[1]; cpb2 = cpb[2]; cpb3 = cpb[3];
#endif		/* NUC */
			for (i = 0; i < Tpmradix; i++) {
				tpb = tprob[i]; /* Transition prob matrix */
				td1 = tdif1[i];
				td2 = tdif2[i];
				prod1 = Freqtpm[i] * opb[i];
#ifndef NUC
				slk = sd1 = sd2 = 0.0;
				for (j = 0; j < Tpmradix; j++) {
					prod2 = cpb[j];
					slk += prod2 * tpb[j];
					sd1 += prod2 * td1[j];
					sd2 += prod2 * td2[j];
				}
				sumlk += prod1 * slk;
				sumd1 += prod1 * sd1;
				sumd2 += prod1 * sd2;
#else			/* NUC */
				slk = cpb0*tpb[0] + cpb1*tpb[1] + cpb2*tpb[2] + cpb3*tpb[3];
				sd1 = cpb0*td1[0] + cpb1*td1[1] + cpb2*td1[2] + cpb3*td1[3];
				sd2 = cpb0*td2[0] + cpb1*td2[1] + cpb2*td2[2] + cpb3*td2[3];
				sumlk += prod1 * slk;
				sumd1 += prod1 * sd1;
				sumd2 += prod1 * sd2;
#endif			/* NUC */
			}
			sumd1 /= sumlk;
			lkld1 += sumd1 * Weight[k];
			lkld2 += (sumd2 / sumlk - sumd1 * sumd1) * Weight[k];
		}
		vari = 1.0 / fabs(lkld2);
		arcold = arc;
		arcdiff = - (lkld1 / lkld2);
		arc += arcdiff;
		if (arc > MIDARC && arcpre < 10.0) arc = MINARC;
		if (arc < MINARC) arc = MINARC;
		if (arc > MAXARC) arc = MAXARC;
	/*	printf("mli\t%3d\t%8.3f\t%8.3f\t%12.7f\t%12.7f\t%10.3f\n",
			op->number, arc, arcold, arcdiff, lkld1, lkld2); */
		/* If the branch length no longer varies, stop iteration */
		if (fabs(arcold - arc) < EPSILON) break;
	}
	/* Branch lengths must be the same
	   in either direction */
	op->kinp->length = arc;
	op->length = arc;          
	op->lklhdl = vari; /* variance? */
	if (Debug)
		printf("mli\t%4d\t%3d\t%8.3f\t%8.3f\t%12.7f\t%12.7f\t%12.7f\t%10.3f\n",
		op->number, it+1, arc, arcpre, arcpre-arc, sqrt(vari), lkld1, lkld2);

	tprobmtrx(arc, tprob); /* Transition probability */
	/*
	printf("MAXIT = %d\n", MAXIT);
	printf("loop = %d\n", loop);
	printf("op->number = %d\n", op->number);
	printf("Numibrnch = %d\n", Numibrnch);
	*/
	if ((op->number == Numibrnch-1 && fabs(arc-arcpre) < EPSILON) ||
		loop == MAXIT-1) {
		for (k = 0, lklhd = 0.0; k < Numptrn; k++) {
			opb = oprob[k];
			cpb = cprob[k];
#ifdef NUC
			cpb0 = cpb[0]; cpb1 = cpb[1]; cpb2 = cpb[2]; cpb3 = cpb[3];
#endif		/* NUC */
			for (i = 0, sumlk = 0.0; i < Tpmradix; i++) {
				tpb = tprob[i];
				prod1 = Freqtpm[i] * opb[i];
#ifndef NUC
				for (j = 0, slk = 0.0; j < Tpmradix; j++)
					slk += cpb[j] * tpb[j];
				sumlk += prod1 * slk;
#else			/* NUC */
				slk = cpb0*tpb[0] + cpb1*tpb[1] + cpb2*tpb[2] + cpb3*tpb[3];
				sumlk += prod1 * slk;
#endif			/* NUC */
			}
			sumlk = log(sumlk);
			Alklptrn[k] = sumlk; /* Likelihood at a site */
			lklhd += sumlk * Weight[k];
		/*	printf("%3d %10.5f\n", k, sumlk); */
		} /* end of for loop */
		tr->lklhd = lklhd;
		/*
		printf("tr->lklhd = %f\n", tr->lklhd);
		*/
	}

#ifdef NUC
		tpb = tprob[0];
#endif	/* NUC */
	oprob = op->iprob;
	for (k = 0; k < Numptrn; k++) {
		opb = oprob[k];
		cpb = cprob[k];
#ifndef NUC
		for (i = 0; i < Tpmradix; i++) {
			tpb = tprob[i];
			for (j = 0, sumlk = 0.0; j < Tpmradix; j++)
				sumlk += tpb[j] * cpb[j];
			opb[i] = sumlk;
		}
#else	/* NUC */
		cpb0 = cpb[0]; cpb1 = cpb[1]; cpb2 = cpb[2]; cpb3 = cpb[3];
		opb[0] = tpb[ 0]*cpb0 + tpb[ 1]*cpb1 + tpb[ 2]*cpb2 + tpb[ 3]*cpb3;
		opb[1] = tpb[ 4]*cpb0 + tpb[ 5]*cpb1 + tpb[ 6]*cpb2 + tpb[ 7]*cpb3;
		opb[2] = tpb[ 8]*cpb0 + tpb[ 9]*cpb1 + tpb[10]*cpb2 + tpb[11]*cpb3;
		opb[3] = tpb[12]*cpb0 + tpb[13]*cpb1 + tpb[14]*cpb2 + tpb[15]*cpb3;
#endif	/* NUC */
	}
/*	if (Debug) prprob(oprob); */
} /*_ mlibranch_njml */


void 
mlebranch(op, loop) /* Optimize external branches */
Node *op; /* op->kinp == descen */
int loop;
{
//    #define DEBUG
//    #define DEBUG2
	int i, j, k, it, numloop;
	double sumlk, sumd1, sumd2, lkld1, lkld2, prod, vari, total;
	double arc, arcold, arcdiff, arcpre;
	dmattpmty tprob, tdif1, tdif2;
	dmatrix oprob;
	ivector dseqi;
	dvector opb;
#ifdef NUC
	dvector tpb, td1, td2;
	double pn0, pn1, pn2, pn3;
#endif /* NUC */
	oprob = op->isop->iprob; //Internal probabilities
#ifdef DEBUG
        for (i=0; i<Numptrn; i++) {
            printf("Weight[%d]: %d\n", i, Weight[i]);
        total=0.0;
        for (j=0; j<Tpmradix; j++) {
            total+=oprob[i][j];
            printf("oprob[%d][%d]: %f\n", i, j, oprob[i][j]);
        }
        printf("Total: %f\n", total);
    }
#endif
	dseqi = op->kinp->eprob; //?
#ifdef DEBUG
    total=0.0;
    for (i=0; i<Numptrn; i++) {
        total+=dseqi[i];
        printf("dseqi[%d]: %d\n", i, dseqi[i]);
        }
        printf("Total: %f\n", total);
#endif
	arc = op->length; // Branch length
	arcpre = arc; // Store the previous branch length

//    loop < 3 ? (numloop = 1) : (numloop = 3);
	for (it = 0; it < numloop; it++) {
		tdiffmtrx(arc, tprob, tdif1, tdif2);
#ifdef NUC
		tpb = *tprob; td1 = *tdif1; td2 = *tdif2;
#endif	/* NUC */
#ifdef DEBUG2
		lkld1 = lkld2 = 0.0;
        printf("\n-------------------------------------\n");
        printf("Pt.\tFq.\tsumd1\tsumd2\tlkld1\tlkld2\n");
        printf("-------------------------------------\n");
#endif
		for (k = 0; k < Numptrn; k++) {
			if ((j = dseqi[k]) >= 0) {
				opb = oprob[k];
#ifndef NUC
				sumlk = sumd1 = sumd2 = 0.0;
				for (i = 0; i < Tpmradix; i++) {
					prod = Freqtpm[i] * opb[i];
					sumlk += prod * tprob[i][j];
					/* tprob: Transition prob */
					sumd1 += prod * tdif1[i][j];
					sumd2 += prod * tdif2[i][j];
				}
#else			/* NUC */
				pn0 = Freqtpm[0] * opb[0];
				pn1 = Freqtpm[1] * opb[1];
				pn2 = Freqtpm[2] * opb[2];
				pn3 = Freqtpm[3] * opb[3];
				sumlk = pn0 * tpb[j  ] + pn1 * tpb[j+ 4]
					  + pn2 * tpb[j+8] + pn3 * tpb[j+12];
				sumd1 = pn0 * td1[j  ] + pn1 * td1[j+ 4]
					  + pn2 * td1[j+8] + pn3 * td1[j+12];
				sumd2 = pn0 * td2[j  ] + pn1 * td2[j+ 4]
					  + pn2 * td2[j+8] + pn3 * td2[j+12];
#endif			/* NUC */
				sumd1 /= sumlk;
				lkld1 += sumd1 * Weight[k];
				lkld2 += (sumd2 / sumlk - sumd1 * sumd1) * Weight[k];
#ifdef DEBUG2
                printf("%d\t%d\t%3.3f\t%3.3f\t%3.3f\t%3.3f\n", k, Weight[k], sumd1, sumd2, lkld1, lkld2);
#endif
			}
		}
#ifdef DEBUG2
         printf("-------------------------------------\n");
#endif
        vari = 1.0 / fabs(lkld2);
		arcold = arc;
		arcdiff = - (lkld1 / lkld2);
#ifdef DEBUG3
        printf("arcdiff=%f\n\n", arcdiff);
#endif
		arc += arcdiff;
#ifdef DEBUG3
        printf("arc (Before): %3.3f\n", arc);
        printf("arcpre: %3.3f\n", arcpre);
#endif
		if (arc > MIDARC && arcpre < 10.0) arc = MINARC;
		if (arc < MINARC) arc = MINARC;
		if (arc > MAXARC) arc = MAXARC;
#ifdef DEBUG3
        printf("arc (After): %3.3f\n", arc);
#endif
	/*	printf("mle\t%3d\t%8.3f\t%8.3f\t%12.7f\t%12.7f\t%10.3f\n",
			op->number, arc, arcold, arcdiff, lkld1, lkld2); */
#ifdef DEBUG3
        printf("fabs(arcold - arc): %f\n", fabs(arcold - arc));
#endif
            if (fabs(arcold - arc) < EPSILON) break;
	}
	op->kinp->length = arc;
	op->length = arc;
	op->lklhdl = vari;
    Debug=1;
	if (Debug)
		printf("mle\t%4d\t%3d\t%8.3f\t%8.3f\t%12.7f\t%12.7f\t%12.7f\t%10.3f\n",
		op->number, it+1, arc, arcpre, arcpre-arc, sqrt(vari), lkld1, lkld2);
	oprob = op->iprob;
	tprobmtrx(op->length, tprob);
#ifdef NUC
	tpb = *tprob;
#endif /* NUC */
	for (k = 0; k < Numptrn; k++) {
	opb = oprob[k];
#ifndef NUC
		if ((j = dseqi[k]) >= 0) {
			for (i = 0; i < Tpmradix; i++)
				opb[i] = tprob[i][j];
		} else {
			for (i = 0; i < Tpmradix; i++)
				opb[i] = 1.0; /* !? */
		}
#else	/* NUC */
		if ((j = dseqi[k]) >= 0) {
			opb[0] = tpb[j];
			opb[1] = tpb[j+4];
			opb[2] = tpb[j+8];
			opb[3] = tpb[j+12];
		} else {
			opb[0] = 1.0;
			opb[1] = 1.0;
			opb[2] = 1.0;
			opb[3] = 1.0;
		}
#endif	/* NUC */
	}
} /*_ mlebranch */


Node *
mlikelihood(tr) /* Optimaize tree tr */
Tree *tr;
{
	Node *cp, *rp;
	int l, nconv, nconv2;
	double lendiff;

	nconv = nconv2 = 0;
	Numit = 0;
	Converg = FALSE;
	for (l = 0; l < MAXIT; l++) { /* MAXIT: Max iteration */
		Numit++;
		if (Debug) printf("ml:%3d\n", l);

		cp = rp = tr->rootp;
		do {
			cp = cp->isop->kinp;
			prodpart(cp->kinp->isop);
			if (cp->isop == NULL) { /* external node */
				if (Debug) printf("mle\t%3d\t%2d\n", cp->number, cp->descen);
				cp = cp->kinp; /* not descen */
				lendiff = cp->length;
#if 1
				mlebranch(cp, l);  /* Optimize 
						      extanal branches  */ 
#endif
				lendiff = fabs(lendiff - cp->length);
				lendiff < EPSILON ? (nconv++)  : (nconv = 0);
				lendiff < 0.1     ? (nconv2++) : (nconv2 = 0);
			} else { /* internal node */
				if (Debug) printf("mli\t%3d\t%2d\n", cp->number, cp->descen);
				if (cp->descen) { /* Descendant node */
#if 1
					partilkl(cp);
#endif
				} else {          /* Ancestral node */
					lendiff = cp->length;
#if 1
					mlibranch(cp, l); /* Optimize
							     internal
							     branches */
#endif
					lendiff = fabs(lendiff - cp->length);
					lendiff < EPSILON ? (nconv++)  : (nconv = 0);
					lendiff < 0.1     ? (nconv2++) : (nconv2 = 0);
				}
			}
			if (nconv >= Numbrnch) goto convergence;
		} while (cp != rp);

	}
	if (nconv2 >= Numbrnch) Converg = 2;
	return rp;

convergence:
	Converg = TRUE;
	return cp;
} /*_ mlikelihood */

Node *
mlikelihood_njml(tr) /* Optimaize tree tr */
Tree *tr;
{
	Node *cp, *rp;
	int l, nconv, nconv2;
	double lendiff;

	nconv = nconv2 = 0;
	Numit = 0;
	Converg = FALSE;
	for (l = 0; l < MAXIT; l++) { /* MAXIT: Max iteration */
		Numit++;
        // Debug=1;
		if (Debug) {
            printf("Iteration:%3d\n", l);
            prtopology(tr);
        }
		cp = rp = tr->rootp;
		do {
            prtopology(tr);
			cp = cp->isop->kinp;
			prodpart(cp->kinp->isop);
			if (cp->isop == NULL) { /* external node */
				if (Debug) printf("mle\t%3d\t%2d\n", cp->number, cp->descen);
				cp = cp->kinp; /* not descen */
				lendiff = cp->length;
#if 1
				mlebranch(cp, l);  /* Optimize 
						      extanal branches  */ 
#endif
				lendiff = fabs(lendiff - cp->length);
				lendiff < EPSILON ? (nconv++)  : (nconv = 0);
				lendiff < 0.1     ? (nconv2++) : (nconv2 = 0);
			} else { /* internal node */
				if (Debug) printf("mli\t%3d\t%2d\n", cp->number, cp->descen);
				if (cp->descen) { /* Descendant node */
					partilkl(cp);
				} else {          /* Ancestral node */
					lendiff = cp->length;
#if 1
					mlibranch_njml(tr, cp, l); /* Optimize
							     internal
							     branches */
#endif
					lendiff = fabs(lendiff - cp->length);
					lendiff < EPSILON ? (nconv++)  : (nconv = 0);
					lendiff < 0.1     ? (nconv2++) : (nconv2 = 0);
				}
			}
			/*
			if (nconv >= Numbrnch) goto convergence;
			 */
            if (nconv >= Maxbrnch) goto convergence;
		} while (cp != rp);

	}
	/*
	if (nconv2 >= Numbrnch) Converg = 2;
	*/
	if (nconv2 >= Maxbrnch) Converg = 2;
	return rp;

convergence:
	Converg = TRUE;
	return cp;
} /*_ mlikelihood_njml */


void
mlvalue(tr, rp, infotrs)
Tree *tr;
Node *rp;
Infotree *infotrs;
{
	int n, k, npara;
	double lklhd, tblen, aic, lkl, varilkl, ldiff;
	Infotree *cp2, *bp, *op;
    
#ifdef DIST
	int i, j, i1, i2;
	double dist;
	dmatrix amt;
	imatrix pths;
    
	/*
     amt = new_dmatrix(Numpair, Numbrnch);
     */
	amt = new_dmatrix(Numpair, Maxbrnch);
	pths = tr->paths;
	for (i = 0, i1 = 0; i1 < (Numspc - 1); i1++) {
		for (i2 = i1 + 1; i2 < Numspc; i2++, i++) {
            /*
             for (j = 0; j < Numbrnch; j++) {
             */
			for (j = 0; j < Maxbrnch; j++) {
				if (pths[j][i1] != pths[j][i2])
					amt[i][j] = 1.0;
				else
					amt[i][j] = 0.0;
			}
		}
	}
	for (i = 0, i1 = 0; i1 < (Numspc - 1); i1++) {
		for (i2 = i1 + 1; i2 < Numspc; i2++, i++) {
            /*
             for (j = 0, dist = 0.0; j < Numbrnch; j++) {
             */
			for (j = 0, dist = 0.0; j < Maxbrnch; j++) {
				if (amt[i][j]) dist += tr->brnchp[j]->length;
			}
			printf("%5.1f",dist);
		}
	}
	putchar('\n');
	free_dmatrix(amt);
#endif /* DIST */
    
	tblen = 0.0;
	for (n = 0; n < Numspc;    n++) tblen += tr->ebrnchp[n]->length;
        for (n = 0; n < Numibrnch; n++) tblen += tr->ibrnchp[n]->length;
            
            npara = Numspc + Numibrnch;
            if (Frequ_optn) npara += Tpmradix - 1;
#ifdef NUC
                if (AlphaBeta != 1.0) npara++;
	if (AlphaYR != 1.0) npara++;
#endif /* NUC */
    
	lklhd = tr->lklhd;
	aic = npara * 2 - 2.0 * lklhd;
	lkl = lklhd / Numsite;
	for (k = 0, varilkl = 0.0; k < Numptrn; k++) {
		ldiff = Alklptrn[k] - lkl;
		varilkl += ldiff * ldiff * Weight[k];
	}
	tr->varilkl = varilkl;
	tr->npara = npara;
	tr->aic = aic;
	tr->tblength = tblen;
	infotrs[Cnotree].npara = npara;
	infotrs[Cnotree].lklhd = lklhd;
	infotrs[Cnotree].lklaprox = 0.0; /* !? */
	infotrs[Cnotree].aic = aic;
	infotrs[Cnotree].tblength = tblen;
	strctree(tr, infotrs[Cnotree].ltplgy);
	if (Cnotree == 0) {
		Maxlkltree = 0;
		Minaictree = 0;
		Maxlkl = lklhd;
		Minaic = aic;
	} else {
		if (lklhd > Maxlkl) {
			Maxlkltree = Cnotree;
			Maxlkl = lklhd;
		}
		if (aic < Minaic) {
			Minaictree = Cnotree;
			Minaic = aic;
		}
	}
#if 1
	/* Sort Infotrees */
	op = &infotrs[Cnotree];
	for (bp = &Atail2, cp2 = bp->up; lklhd > cp2->lklhd; bp = cp2, cp2 = cp2->up)
	    ;
	op->up = cp2;
	bp->up = op;  /* Atail2 is updated */
#endif
	return;
} /*_ mlvalue */


void
reliabranch(tr)
Tree *tr;
{
	boolean localconv, vibrate_flag;
	int ib, i, j, n, ll, forder, exn, exn0, exb, exb0;
	double lklorg, lklold, lklhd1, lklhd2, uldiff, muldiff, rel, minrel, iblen;
	Node *rp, *dp, *ap, *cp, *cp0, *cp1, *kp, *kp0, *kp1, *ncp;
	Node **exchbrnch1, **exchbrnch2, **ebrn, **ibrn;
	dvector elenvec, ilenvec, exchldiff, exchrelia;
	ivector exchstate, exchorder, whichml;
	LPVECTOR mlklptrn;
	LPCUBE   rlklptrn;
    
    /*   root   kp1                 cp        [1] [2]
     * R   D ---(d)   ap   I  dp    (a)--- A   X   Y
     *                (a)-----(d)
     * Z   C ---(a)   kp0     cp0   (a)--- B   Y   X
     *          kp                  cp1
     *
     *   [1]: A(X) <--> C(Z) , [2]: B(X) <--> C(Z)
     */
	elenvec = new_dvector(Maxspc);
	ilenvec = new_dvector(Numibrnch);
	exchbrnch1 = (Node **)malloc((unsigned)Numibrnch * sizeof(Node *));
	if (exchbrnch1 == NULL) maerror("exchbrnch1 in reliabranch().");
        exchbrnch2 = (Node **)malloc((unsigned)Numibrnch * sizeof(Node *));
        if (exchbrnch2 == NULL) maerror("exchbrnch2 in reliabranch().");
            exchstate = new_ivector(Numibrnch);
            exchorder = new_ivector(Numibrnch);
            whichml   = new_ivector(Numibrnch);
            exchrelia = new_dvector(Numibrnch);
            exchldiff = new_dvector(Numibrnch+1);
            exchldiff[Numibrnch] = - DBL_MAX;
            rlklptrn  = NEW_LPCUBE(Numibrnch, 2, Numptrn);
            ebrn = tr->ebrnchp;
            ibrn = tr->ibrnchp;
            mlklptrn = Alklptrn;
            lklorg = tr->lklhd;
            exn = 0;
            exb = Numibrnch;
            
            for (ll = 0, localconv = vibrate_flag = FALSE; !localconv; ll++) {
                if (ll) printf("%%%d\n", ll);
                if (Verbs_optn) fprintf(stderr, "%2d:", ll+1);
                for (i = 0; i < Numspc; i++)    elenvec[i] = ebrn[i]->length;
                for (i = 0; i < Numibrnch; i++) ilenvec[i] = ibrn[i]->length;
                
                for (ib = 0, forder = Numibrnch, muldiff = 0.0; ib < Numibrnch; ib++) {
                    if (Verbs_optn) fprintf(stderr, " %d", ib+1);
                    dp = ibrn[ib];
                    kp0 = ap = dp->kinp;
                    if (dp->isop->isop->isop != dp || ap->isop->isop->isop != ap) {
                        Relistat[ib] = -1;
                        exchstate[ib] = 0;
                        continue;
                    }
                    for (kp = ap->isop; kp->descen || kp == tr->rootp;
                         kp0 = kp, kp = kp->isop)
                        ;
                    kp1 = kp->isop;
                    
                    for (cp=dp->isop, cp0=dp, n=0; cp != dp; cp0=cp, cp=cp->isop, n++) {
                        cp1 = cp->isop;
                        kp0->isop = cp; cp->isop = kp1;
                        cp0->isop = kp; kp->isop = cp1;
                        for (i = 0; i < Numspc; i++)
                            ebrn[i]->length = ebrn[i]->kinp->length = elenvec[i];
                        for (i = 0; i < Numibrnch; i++)
                            ibrn[i]->length = ibrn[i]->kinp->length = ilenvec[i];
                        iblen = ap->length * 0.5;
                        if (iblen < Llimit) iblen = Llimit;
                        dp->length = ap->length = iblen;
                        n == 0 ? (Alklptrn=rlklptrn[ib][0]):(Alklptrn=rlklptrn[ib][1]);
                        reliml(tr, ap, lklorg, mlklptrn, &rel);
                        n == 0 ? (lklhd1 = tr->lklhd) : (lklhd2 = tr->lklhd);
                        if (n == 0) {
                            Relinum[ib][0]  = dp->isop->number;
                            Relinum[ib][1]  = dp->isop->isop->number;
                            ncp = cp;
                            minrel = rel;
                        } else if (lklhd2 > lklhd1) {
                            Relinum[ib][0]  = dp->isop->number;
                            Relinum[ib][1]  = dp->isop->isop->number;
                            ncp = cp;
                            minrel = rel;
                        }
                        kp0->isop = kp; kp->isop = kp1;
                        cp0->isop = cp; cp->isop = cp1;
                    } /* for cp */
                    
                    if (lklhd1 > lklhd2) {
                        lklorg > lklhd1 ? (Relistat[ib] = 0) : (Relistat[ib] = 1);
                        uldiff = lklhd1 - lklorg;
                        whichml[ib] = 1;
                    } else {
                        lklorg > lklhd2 ? (Relistat[ib] = 0) : (Relistat[ib] = 2);
                        uldiff = lklhd2 - lklorg;
                        whichml[ib] = 2;
                    }
                    if (uldiff > 0.0 && uldiff < 0.00001 &&
                        minrel < 0.5 && minrel > 0.499   &&
                        fabs(lklhd1 - lklhd2)  < 0.00001) { /* attention! */
                        /*	printf("%3d %20.15f %20.15f %20.15f\n",
                         ib+Numspc+1, uldiff, minrel, fabs(lklhd1-lklhd2)); */
                        uldiff = 0.0;
                        minrel = 0.5;
                        Relistat[ib] = 0;
                    }
                    Reliprob[ib][0] = minrel;
                    Reliprob[ib][1] = 1.0 - minrel;
                    uldiff > 0 ? (exchstate[ib] = 1) : (exchstate[ib] = 0);
                    exchorder[ib] = -Numspc-1; /* -1 */
                    exchldiff[ib] = uldiff;
                    exchrelia[ib] = 1.0 - minrel;
                    exchbrnch1[ib] = kp;
                    exchbrnch2[ib] = ncp;
                    if (uldiff > muldiff) {
                        exchorder[ib] = forder;
                        forder = ib;
                        muldiff = uldiff;
                    } else if (uldiff > 0.0) {
                        for (i = forder; ; i = j) {
                            j = exchorder[i];
                            /* printf("exchorder[%3d]:%3d\n",i+1,j+1); */
                            if (uldiff > exchldiff[j]) {
                                exchorder[ib] = j;
                                exchorder[i] = ib;
                                break;
                            }
                        }
                    }
                } /* for ib */
                if (Verbs_optn) fprintf(stderr, "\n");
#if 0
                printf(" ib RS N1 N2  LBP1  LBP2 ES %3d   ldiff         relia\n",
                       forder+Numspc+1);
                for (ib = 0; ib < Numibrnch; ib++) {
                    printf("%3d%3d%3d%3d%6.3f%6.3f%3d%4d%15.10f%14.10f\n",
                           ib+Numspc+1, Relistat[ib], Relinum[ib][0]+1, Relinum[ib][1]+1,
                           Reliprob[ib][0], Reliprob[ib][1], exchstate[ib],
                           exchorder[ib]+Numspc+1, exchldiff[ib], exchrelia[ib]);
                } putchar('\n');
#endif
                for (i = forder; i < Numibrnch; i = exchorder[i]) {
                    if (exchstate[i]) noexch(ibrn[i], exchstate);
                }
                
                if (Xreli_optn) goto ONCE;
                
                if (muldiff <= 0.0) {
                    localconv = TRUE;
                } else {
                    prtopology(tr); putchar('\n');
                    exn0 = exn;
                    exb0 = exb;
                    exn = 0;
                    for (i = forder; i < Numibrnch; i = exchorder[i]) {
                        if (exchstate[i]) {
                            exn++;
                            exb = i;
                            kp = exchbrnch1[i];
                            cp = exchbrnch2[i];
                            /*
                             printf("%%%3d %3d<->%-3d  ln L:%12.3f +%7.3f\n",i+Numspc+1,
                             kp->kinp->number+1,cp->kinp->num+1,lklorg,exchldiff[i]);
                             */
                            printf("%%%3d %3d<->%-3d  ln L:%12.3f +%17.10f\n",i+Numspc+1,
                                   kp->kinp->number+1,cp->kinp->number+1,lklorg,exchldiff[i]);
                            dp = ibrn[i];
                            ap = dp->kinp;
                            kp->isop->isop->isop = cp;
                            cp->isop->isop->isop = kp;
                            ncp = cp->isop;
                            cp->isop = kp->isop;
                            kp->isop = ncp;
                            if (vibrate_flag) break;
                        }
                    }
                    fflush(stdout);
                    Alklptrn = mlklptrn;
                    pathing(tr);
                    slslength(tr, Distanmat, Maxspc);
                    initpartlkl(tr);
                    rp = (Node *)mlikelihood(tr);
                    lklold = lklorg;
                    lklorg = tr->lklhd;
                    /* printf("%%%3d %3d %3d %3d %20.10f\n",
                     exn, exn0, exb, exb0, lklorg - lklold); */
                    if (exn == 1 && exn0 == 1 && exb == exb0) { /* attention! */
                        if (fabs(lklorg - lklold) < 0.00001) localconv = TRUE;
                    }
                    if (lklorg < lklold) vibrate_flag = TRUE;
                }
            } /* for ll (!localconv) */
    
ONCE: /* if (Xreli_optn) */
    
	Alklptrn = mlklptrn;
	for (i = 0; i < Numspc; i++)
		ebrn[i]->length = ebrn[i]->kinp->length = elenvec[i];
        for (i = 0; i < Numibrnch; i++)
            ibrn[i]->length = ibrn[i]->kinp->length = ilenvec[i];
            initpartlkl(tr);
            rp = (Node *)mlikelihood(tr);
            mlvalue(tr, rp, Infotrees);
            prtopology(tr); putchar('\n');
            if (Verbs_optn) fputs("rerooting\n", stderr);
            /* ??
             reroot(tr, tr->rootp);
             */
                putctopology(tr); putchar('\n');
                localbp(Reliprob, mlklptrn, rlklptrn, whichml, Numibrnch, Numsite);
                FREE_LPCUBE(rlklptrn);
                free_dvector(exchrelia);
                free_dvector(exchldiff);
                free_ivector(exchstate);
                free_ivector(exchorder);
                free_ivector(whichml);
                free(exchbrnch1);
                free(exchbrnch2);
                free_dvector(elenvec);
                free_dvector(ilenvec);
                } /*_ reliabranch */

void
reliml(tr, op, lklorg, mlklptrn, rel)
Tree *tr;
Node *op;
double lklorg;
LPVECTOR mlklptrn;
double *rel;
{
	Node *cp, *kp;
	int i, l, nconv, nconv2;
	double eps, lendiff, suml1, suml2, ldiff, sdlkl, lkldiff;
    
	/* prtopology(tr); */
	kp = op->kinp;
	cp = op;
	do {
		cp = cp->isop->kinp;
		if (cp->isop == NULL) { /* external node */
			/* printf("rmle %3d%3d\n", cp->number+1,cp->descen); */
			cp = cp->kinp; /* not descen */
			partelkl(cp);
		} else { /* internal node */
			if (cp->kinp->descen != 2) {
				cp->descen = 2;
			} else {
				/* printf("rmli %3d%3d\n", cp->number+1,cp->descen); */
				prodpart(cp->kinp->isop);
				partilkl(cp);
				cp->descen ? (cp->kinp->descen = FALSE)
                : (cp->kinp->descen = TRUE);
			}
		}
	} while (cp != op);
    
	prodpart(op->isop);
	mlibranch(op, 0.1);
#if RELIDEBUG
	printf("\n%3s", "");
	for (i = 0; i < Numbrnch; i++) printf("%5d",i+1); putchar('\n');
#endif
        op->isop->kinp->descen = op->isop->isop->kinp->descen = 2;
        kp->isop->kinp->descen = kp->isop->isop->kinp->descen = 2;
        
        for (l = 0, nconv = 0; l < MAXIT; l++) {
            if      (l == 0) eps = 0.5;
            else             eps = 0.1;
#if RELIDEBUG
            printf("%3d", l+1);
            for (i = 0; i < Numspc; i++)
                printf("%5.0f",tr->ebrnchp[i]->length*100);
            for (i = 0; i < Numibrnch; i++)
                printf("%5.0f",tr->ibrnchp[i]->length*100);
            putchar('\n');
#endif
            cp = op;
            do {
                cp = cp->isop->kinp;
                prodpart(cp->kinp->isop);
                if (cp->isop == NULL) { /* external node */
                    cp = cp->kinp; /* not descen */
                    lendiff = cp->length;
                    mlebranch(cp, eps);
                    lendiff = fabs(lendiff - cp->length);
                    lendiff < 0.1 ? (nconv++) : (nconv = 0);
                    /* printf("e%3d%9.3f%9.3f\n", cp->number+1,cp->length,lendiff); */
                } else { /* internal node */
                    if (!cp->descen && cp->kinp->descen)
                        partilkl(cp);
                    if (cp->descen == 2 || (cp->descen && !cp->kinp->descen)) {
                        if (cp->descen ==2 ) cp = cp->kinp;
                        lendiff = cp->length;
                        mlibranch(cp, eps);
                        lendiff = fabs(lendiff - cp->length);
                        lendiff < 0.1 ? (nconv++) : (nconv = 0);
                        /* printf("i%3d%9.3f%9.3f\n",
                         cp->number+1,cp->length,lendiff); */
                    }
                }
            } while (cp != op);
            if (nconv >= 5) break;
        }
	op->isop->descen ?
    (op->isop->kinp->descen = 0) : (op->isop->kinp->descen = 1);
	op->isop->isop->descen ?
    (op->isop->isop->kinp->descen = 0) : (op->isop->isop->kinp->descen = 1);
	kp->isop->descen ?
    (kp->isop->kinp->descen = 0) : (kp->isop->kinp->descen = 1);
	kp->isop->isop->descen ?
    (kp->isop->isop->kinp->descen = 0) : (kp->isop->isop->kinp->descen = 1);
    
	nconv = nconv2 = 0;
	Converg = FALSE;
	for (l = 0, Numit = 1; l < MAXIT; l++, Numit++) {
		if      (l == 0) eps = 0.5;
		else if (l == 1) eps = 0.1;
		else             eps = Epsilon;
#if RELIDEBUG
		printf("%3d", l+1);
		for (i = 0; i < Numspc; i++)
			printf("%5.0f",tr->ebrnchp[i]->length*100);
		for (i = 0; i < Numibrnch; i++)
			printf("%5.0f",tr->ibrnchp[i]->length*100);
		putchar('\n');
#endif
		cp = op;
		do {
			cp = cp->isop->kinp;
			prodpart(cp->kinp->isop);
			if (cp->isop == NULL) { /* external node */
				/* if (Debug) printf("mle\t%3d\t%3d\n",cp->number+1,cp->descen); */
				cp = cp->kinp; /* not descen */
				lendiff = cp->length;
				mlebranch(cp, eps);
				lendiff = fabs(lendiff - cp->length);
				lendiff < Epsilon ? (nconv++)  : (nconv = 0);
				lendiff < 0.5     ? (nconv2++) : (nconv2 = 0);
			} else { /* internal node */
				/* if (Debug) printf("mli\t%3d\t%3d\n",cp->number+1,cp->descen); */
				if (cp->descen) {
					partilkl(cp);
				} else {
					lendiff = cp->length;
					mlibranch(cp, eps);
					lendiff = fabs(lendiff - cp->length);
					lendiff < Epsilon ? (nconv++)  : (nconv = 0);
					lendiff < 0.5     ? (nconv2++) : (nconv2 = 0);
				}
			}
			if (nconv >= Numbrnch) {
				Converg = TRUE;
				break;
			}
		} while (cp != op);
		if (Converg) break;
	}
	if (!Converg && nconv2 >= Numbrnch) Converg = 2;
        evallkl(cp);
        
        for (i = 0, suml1 = suml2 = 0.0; i < Numptrn; i++) {
            ldiff = Alklptrn[i] - mlklptrn[i];
            suml1 += ldiff * Weight[i];
            suml2 += ldiff * ldiff * Weight[i];
        }
	suml1 /= Numsite;
	sdlkl = sqrt( (double)Numsite/(Numsite-1) * (suml2-suml1*suml1*Numsite) );
	lkldiff = lklorg - tr->lklhd;
	*rel = probnormal(lkldiff / sdlkl);
#if 0
	printf("%3d", op->number+1);
	printf(" %7.3f %7.3f %7.3f %7.3f", lkldiff,sdlkl,lkldiff/sdlkl,*rel);
	printf("  %3s%3d\n",
           (Converg == TRUE ? "con" : (Converg == 2 ? "jbc" : "Noc")), Numit);
#endif
	return;
} /*_ reliml */


void
noexch(rp, exchstate)
Node *rp;
ivector exchstate;
{
	Node *cp;

	cp = rp->kinp;
	do {
		cp = cp->isop->kinp;
		if (cp->isop == NULL) { /* external node */
			cp = cp->kinp;
		} else { /* internal node */
			if (exchstate[cp->number - Maxspc] == 1) {
				exchstate[cp->number - Maxspc] = 2;
			} else if (exchstate[cp->number - Maxspc] == 2) {
				exchstate[cp->number - Maxspc] = 0;
			} else {
				cp = cp->kinp;
			}
		}
	} while (cp != rp);
	exchstate[cp->number - Maxspc] = 1;
#if 0
	for (j = exchorder[i]; j < Numibrnch; j = exchorder[j]) {
		if (exchstate[j] && exchldiff[i] > exchldiff[j]) {
			cp = ibrn[j];
			if (rp == cp->isop->kinp ||
				rp == cp->isop->isop->kinp ||
				rp == cp->kinp->isop ||
				rp == cp->kinp->isop->kinp ||
				rp == cp->kinp->isop->isop ||
				rp == cp->kinp->isop->isop->kinp) {
				exchstate[j] = 0;
			}
		}
	}
#endif
} /* noexch */


void
reroot(tr, rp)
Tree *tr;
Node *rp;
{
	Node *cp, *op, *xp, *bp, *ap;
	boolean exch_flag;

	tr->rootp = rp;
	cp = rp;
	do {
		cp = cp->isop->kinp;
		if (cp->isop == NULL) { /* external node */
			cp->descen = TRUE;
			cp = cp->kinp;
			cp->descen = FALSE;
		} else { /* internal node */
			if (cp->descen != -1) {
				cp->descen = TRUE;
				cp->kinp->descen = -1;
				tr->ibrnchp[cp->number - Maxspc] = cp;
			} else {
				/* printf("inode %3d\n", cp->kinp->number+1); */
				cp->descen = FALSE;
				cp = cp->kinp; /* reversed */
				op = cp;
				do {
					exch_flag = FALSE;
					/* printf("op:%3d\n", op->number+1); */
					for (bp = cp; bp->isop->isop != op; bp = bp->isop) {
						xp = bp->isop;
						ap = xp->isop;
						/* printf("bp:%3d xp:%3d ap:%3d\n",
							bp->number+1,xp->number+1,ap->number+1); */
						if (ap->number < xp->number) {
							xp->isop = ap->isop;
							ap->isop = xp;
							bp->isop = ap;
							exch_flag = TRUE;
						}
					}
					op = bp->isop;
				} while (exch_flag);
				cp->kinp->number = cp->isop->number;
				for (xp = cp->isop; xp != cp; xp = xp->isop) {
					xp->number = xp->kinp->number;
				}
				cp = cp->kinp; /* reversed */
			}
		}
	} while (cp != rp);

	/* printf("root: %d\n", cp->kinp->number+1); */
	op = cp;
	do {
		exch_flag = FALSE;
		/* printf("op:%3d\n", op->number+1); */
		for (bp = cp; bp->isop->isop != op; bp = bp->isop) {
			xp = bp->isop;
			ap = xp->isop;
			/* printf("bp:%3d xp:%3d ap:%3d\n",
				bp->number+1,xp->number+1,ap->number+1); */
			if (ap->number < xp->number) {
				xp->isop = ap->isop;
				ap->isop = xp;
				bp->isop = ap;
				exch_flag = TRUE;
			}
		}
		op = bp->isop;
	} while (exch_flag);

	cp->number = cp->kinp->number;
	for (xp = cp->isop; xp != cp; xp = xp->isop) {
		xp->number = xp->kinp->number;
	}
} /* reroot */


void
slslength(tr, dmat, ns) /* simplify least square method (not equal LS) */
Tree *tr;
dmatrix dmat;
int ns;
{
	int i, j, k, m, ne, ni, l, r, ll, rr;
	int numibrnch, numbrnch;
	double sumc, suml, sumr, leng, alllen, rss, coef;
	ivector pths, lpaths, rpaths, npaths;
	Node **ebp, **ibp, *dp, *ap, *xp;

	lpaths = new_ivector(ns);
	rpaths = new_ivector(ns);
	npaths = new_ivector(ns);
	numibrnch = Numibrnch;
	numbrnch = ns + numibrnch;
	ebp = tr->ebrnchp;
	ibp = tr->ibrnchp;
	alllen = 0.0;

#if SLSDEBUG
	for (i = 0; i < ns; i++) {
		for (j = 0; j < ns; j++) printf("%6.0f", dmat[i][j]*1000);
		putchar('\n');
	} putchar('\n');
	for (i = 0; i < ns; i++) {
		for (j = 0, sumc = 0.0; j < ns; j++) sumc += dmat[i][j];
		printf("%6.0f", sumc*1000);
	} putchar('\n'); putchar('\n');
#endif /* SLSDEBUG */

	for ( ne = 0; ne < numbrnch; ne++) {

		for (k = 0; k < ns; k++) {
			npaths[k] = rpaths[k] = 0;
		}
		if (ne < ns) { /* internal */
			l = 1;
			ll = 1;
			dp = ebp[ne];
			ap = ebp[ne]->kinp;
			pths = dp->paths;
			for (k = 0; k < ns; k++) lpaths[k] = pths[k];
			npaths[ne] = 1;
		} else { /* external */
			ni = ne - ns;
			dp = ibp[ni];
			ap = ibp[ni]->kinp;
			pths = dp->paths;
			for (k = 0, l = 0; k < ns; k++) {
				lpaths[k] = 0;
				if (pths[k]) l++;
			}
			for (xp = dp->isop, j = 1; xp != dp; xp = xp->isop, j++) {
				pths = xp->paths;
				for (k = 0, m = 0; k < ns; k++) if (pths[k]) m++;
				if (xp->descen) {
					m = ns - m;
					for (k = 0; k < ns; k++) {
						if (!pths[k]) {
							lpaths[k] = j;
							npaths[k] = m;
						}
					}
				} else {
					for (k = 0; k < ns; k++) {
						if (pths[k]) {
							lpaths[k] = j;
							npaths[k] = m;
						}
					}
				}
			}
			ll = j - 1;
		}
		r = ns - l;
		for (xp = ap->isop, j = 1; xp != ap; xp = xp->isop, j++) {
			pths = xp->paths;
			for (k = 0, m = 0; k < ns; k++) if (pths[k]) m++;
			if (xp->descen) {
				m = ns - m;
				for (k = 0; k < ns; k++) {
					if (!pths[k]) {
						rpaths[k] = j;
						npaths[k] = m;
					}
				}
			} else {
				for (k = 0; k < ns; k++) {
					if (pths[k]) {
						rpaths[k] = j;
						npaths[k] = m;
					}
				}
			}
		}
		rr = j - 1;

#if SLSDEBUG
		for (k = 0; k < ns; k++) printf("%2d", lpaths[k]); putchar('\n');
		for (k = 0; k < ns; k++) printf("%2d", rpaths[k]); putchar('\n');
		for (k = 0; k < ns; k++) printf("%2d", npaths[k]); putchar('\n');
#endif /* SLSDEBUG */

		sumc = suml = sumr = 0.0;
		for (i = 0; i < ns - 1; i++) {
			for (j = i + 1; j < ns; j++) {
				coef = (double)npaths[i] * (double)npaths[j];
				if (lpaths[i]) {
					if (rpaths[j]) {
						sumc += dmat[i][j] / coef;
#if						SLSDEBUG
						printf("c1:%3d%3d%8.0f%7.0f\n",
							i+1,j+1,sumc*1000,dmat[i][j]/coef*1000);
#endif					/* SLSDEBUG */
					} else if (lpaths[i] != lpaths[j]) {
						suml += dmat[i][j] / coef;
#if						SLSDEBUG
						printf("l :%3d%3d%8.0f%7.0f\n",
							i+1,j+1,suml*1000,dmat[i][j]/coef*1000);
#endif					/* SLSDEBUG */
					}
				} else {
					if (!rpaths[j]) {
						sumc += dmat[i][j] / coef;
#if						SLSDEBUG
						printf("c2:%3d%3d%8.0f%7.0f\n",
							i+1,j+1,sumc*1000,dmat[i][j]/coef*1000);
#endif					/* SLSDEBUG */
					} else if (rpaths[i] != rpaths[j]) {
						sumr += dmat[i][j] / coef;
#if						SLSDEBUG
						printf("r :%3d%3d%8.0f%7.0f\n",
							i+1,j+1,sumr*1000,dmat[i][j]/coef*1000);
#endif					/* SLSDEBUG */
					}
				}
			}
		}

#if		SLSDEBUG
		printf("%3s:%3d",(ne < ns ? "ext" : "int"), ne+1);
		printf(" %3d%3d%3d%3d", l, r, ll, rr);
		printf(" %5.2f%5.2f", (ne < ns ? 0 : (double)rr / (double)(ll-1)),
			(double)ll / (double)(rr-1));
		printf("%7.0f%7.0f%7.0f", sumc*1000, suml*1000, sumr*1000);
#endif	/* SLSDEBUG */
		if (ne >= ns) suml *= (double)rr / (double)(ll-1);
		sumr *= (double)ll / (double)(rr-1);
		leng = ( sumc - sumr - suml ) / (double)(ll * rr);
#if		SLSDEBUG
		printf("   leng:%9.5f\n", leng);
#endif	/* SLSDEBUG */

		alllen += leng;

		if (leng < 0.0) leng = 0.0;  /* caution!? */
		if (ne < ns) /* external */
			pths = ebp[ne]->paths;
		else /* internal */
			pths = ibp[ni]->paths;
		for (i = 1; i < ns ; i++) {
			for (j = 0; j < i; j++) {
				if (pths[i] != pths[j]) dmat[i][j] -= leng;
			}
		}

		if (leng > Ulimit) leng = Ulimit;
		if (ne < ns)  { /* external */
			if (leng < LOWERLIMIT) leng = LOWERLIMIT;
			ebp[ne]->length = ebp[ne]->kinp->length = leng;
		} else { /* internal */
			if (leng < Llimit) leng = Llimit;
			ibp[ni]->length = ibp[ni]->kinp->length = leng;
		}
		Brnlength[ne] = leng; /* !? */

	} /* for ne */

	for (i = 1, rss = 0.0; i < ns ; i++) {
		for (j = 0; j < i; j++) {
			rss += dmat[i][j] * dmat[i][j];
#if			SLSDEBUG
			printf("%3d%3d%9.3f\n", i+1, j+1, dmat[i][j]);
#endif		/* SLSDEBUG */
		}
	}
	tr->rssleast = sqrt(rss); /* / numpair !? */
#if SLSDEBUG
	printf("rss: %9.3f%9.3f\n", rss, tr->rssleast);
#endif /* SLSDEBUG */
	for (i = 1; i < ns ; i++) {
		for (j = 0; j < i; j++) dmat[i][j] = dmat[j][i];
	}

	tr->tbldis = alllen;
	free_ivector(lpaths);
	free_ivector(rpaths);
	free_ivector(npaths);
} /*_ slslength */


void 
evallkl(op)
Node *op;
{
	/*      op
	 *      (a)----------( )
	 *     / oprob
	 *  (i)
	 *  iprob
	 */
	int i, k;
	double sumlk, lklhd;
	dvector opb, ipb;
	dmatrix oprob, iprob;

	oprob = op->iprob;
	iprob = op->isop->iprob;

	for (k = 0, lklhd = 0.0; k < Numptrn; k++) {
		opb = oprob[k];
		ipb = iprob[k];
		for (i = 0, sumlk = 0.0; i < Tpmradix; i++) {
			sumlk += Freqtpm[i] * opb[i] * ipb[i];
		}
		sumlk = log(sumlk);
		Alklptrn[k] = sumlk;
		lklhd += sumlk * Weight[k];
		/* printf("%3d %10.5f\n", k, sumlk); */
	}
	/* printf("branch:%3d ln L: %12.5f\n", op->kinp->num+1,lklhd); */
	Ctree->lklhd = lklhd;

} /*_ evallkl */

double
probnormal(z)  /* lower probability of normal distribution */
double z;
{
	int i;
	double z2, prev, p, t;

	z2 = z * z;
	t = p = z * exp(-0.5 * z2) / sqrt(2 * 3.14159265358979323846264);
	for (i = 3; i < 200; i += 2) {
		prev = p;  t *= z2 / i;  p += t;
		if (p == prev) return 0.5 + p;
	}
	return (z > 0);
} /* probnormal */


void
localbp(reliprob, mlklptrn, rlklptrn, whichml, nb, ns)
dmatrix reliprob;
LPVECTOR mlklptrn;
LPCUBE rlklptrn;
ivector whichml;
int nb, ns;
{
	int i, j, k, ib, imax, nsite, nptrn;
	double coefrand;
	ivector addweight;
	imatrix bpn;
	dmatrix bpl;

	if (Verbs_optn) fprintf(stderr, "bootstraping\n");
	addweight = new_ivector(ns);
	bpn = new_imatrix(nb, 3);
	bpl = new_dmatrix(nb, 3);
	coefrand = (double)Numsite / ((double)RANDOM_MAX + 1.0);
	for ( j = 0, k = 0; k < Numptrn; k++ ) {
		for ( i = 0, imax = Weight[k]; i < imax; i++ ) addweight[j++] = k;
	}

	for (ib = 0; ib < nb; ib++)
		bpn[ib][0] = bpn[ib][1] = bpn[ib][2] = 0;
	for (i = 0; i < NUMBOOTSR; i++) {
		for (ib = 0; ib < nb; ib++)
			bpl[ib][0] = bpl[ib][1] = bpl[ib][2] = 0.0;
		for (k = 0; k < ns; k++) {
			nsite = (int)( coefrand * (double)rand() ); /* RANDOM */
			nptrn = addweight[nsite];
			for (ib = 0; ib < nb; ib++) {
				bpl[ib][0] += mlklptrn[nptrn];
				bpl[ib][1] += rlklptrn[ib][0][nptrn];
				bpl[ib][2] += rlklptrn[ib][1][nptrn];
			}
		}
		for (ib = 0; ib < nb; ib++) {
			bpl[ib][1] > bpl[ib][2]
			? ( bpl[ib][0] > bpl[ib][1] ? bpn[ib][0]++ : bpn[ib][1]++ )
			: ( bpl[ib][0] > bpl[ib][2] ? bpn[ib][0]++ : bpn[ib][2]++ );
		}
	}
	for (ib = 0; ib < nb; ib++) {
		reliprob[ib][0] = (double)bpn[ib][0] / (double)NUMBOOTSR;
		reliprob[ib][1] = (double)bpn[ib][whichml[ib]] / (double)NUMBOOTSR;
	}

	free_imatrix(bpn);
	free_dmatrix(bpl);
	free_ivector(addweight);
} /* localbp */
