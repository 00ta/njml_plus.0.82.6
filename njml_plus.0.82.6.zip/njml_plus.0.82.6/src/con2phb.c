/* Aug 3 - 30, 1999 */
/* con2phb converts a concensus tree to a bootstrap tree */
/* This program was written in ad hoc. Memory allocations are clude.
   Rewrite later. */

#define MAIN_MODULE 1
#include "protml.h"

void con2phb(char **, char **);
void get_conbs(char **, char **);
void get_contree(FILE *, char **);

int main(int argc, char **argv) {
  FILE *ifp;
  char *contree, *phbtree, *urphbtree;

  if ((ifp = fopen(argv[1], "r")) == NULL) {
    fprintf(stderr,"%s: can't open %s\n",argv[0],argv[1]);
    return -1;
  }
  phbtree = new_cvector(5000); /* Ad hoc! */
  urphbtree = new_cvector(5000); /* Ad hoc! */
  get_contree(ifp, &contree);
  con2phb(&contree, &phbtree);
  unroot2(&phbtree, &urphbtree);
  printf("%s\n", urphbtree);
  return 0;
}

/* Get the consensus tree (topologies) */ 
void get_contree(FILE *ifp, char **contree) {
  char line[BUFLINE], *cp, *np;
  int i; /* Length of contree */

  /* Allocate contree */
  i = 0;
  while ((fgets(line, BUFLINE, ifp) != NULL)) {
    for (cp = line; (*cp != ';') && (*cp != '\n');) {
      cp++;
      i++;
    }  
    if (*cp == '\n')
      i++;
    if (*cp == ';') {
      i++;
      break;
    }
  }
  *contree = new_cvector(i);
  /* Get the consensus tree (topologies) */ 
  np = *contree;
  fseek(ifp, 0, 0);
  while (fgets(line, BUFLINE, ifp) != NULL) {
    for (cp = line; (*cp != ';') && (*cp != '\n');) {
      *np = *cp;
      cp++;
      np++;
    }  
    if (*cp == ';') {
      *np = *cp;
      cp++;
      np++;
      break;
    }
  }
  *np = '\0';
}

/* Convert a consensus tree to a bootstrap tree */
void con2phb(char **contree, char **phbtree) {
  char *np, *phbtree2;
  int i;

  /* phbtree2: bootstrap value */
  phbtree2 = new_cvector(6);  /* The bootstrap value must be less
				 than 9999 */
  np = *phbtree;
  for (; **contree != ';'; ) {
    if (**contree == ')') {
      /* Get a bootstrap value of the consensus tree */
      get_conbs(contree, &phbtree2);
      strcat(*phbtree, phbtree2);
      /* Proceed the pointer of np for the concatenated substring */
      for (i = 0; i < strlen(phbtree2); i++)
	np++;
    } else {
      *np = **contree;
      (*contree)++;
      np++;
    }
  }
  *np = '\0';
}

void get_conbs(char **contree, char **phbtree) {
  char *np;

  np = *phbtree;
  /* Copy ')' */
  *np = **contree;
  (*contree)++;
  np++;
  if (**contree == ';') {
      *np = **contree;
      np++;
      *np = '\0';
      return;
  }
  /* Skip ':' */
  (*contree)++;
  /* Set a dummy distance */
  for (; (**contree != ',') && (**contree != ')'); ) {
      *np = **contree;
      (*contree)++;
      np++;
  }
  *np = ':';
  np++;
  *np = '0';
  np++;
  *np = '\0';
}

