/* Tree operation */

#define MAIN_MODULE 1
#include "protml.h"

int main(argc, argv)
int argc;
char **argv;
{
  FILE *ifp, *tplfp;
  int buftree;
  char *comment;
  ivector alias;

  /* Open files for sequence data and  topologies */
  if ((ifp = fopen(argv[1], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n",argv[0],argv[1]);
  if ((tplfp = fopen(argv[2], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n",argv[0],argv[2]);
  
  /* Get size of sequence data */
  getsize(ifp, &Maxspc, &Maxsite, &comment);

  /* Allocate memory space for names of sequence data */
  Identif = (char **)malloc((unsigned)Maxspc * sizeof(char *));
  if (Identif == NULL) maerror("in tree");

  /* Allocate memory space for sequene data */
  Seqchar = new_cmatrix(Maxspc, Maxsite);

  /* Get sequence data */
  getseqs(ifp, Identif, Seqchar, Maxspc, Maxsite);

  /* Allocate memory space for a topology represented by a string */
  buftree =  getbuftree(Maxspc, Identif);
  Strtree = new_cvector(buftree);

  /* Get the number of trees in the file */
  getnumtree(tplfp, &Numtree);

  /* Some preparations for making trees */  
  getfreqepm(Seqchar, Freqemp, Maxspc, Maxsite);
  alias = new_ivector(Maxsite);
  radixsort_njml(Seqchar, alias, Maxspc, Maxsite, &Numptrn);
  Seqconint = new_imatrix(Maxspc, Numptrn);
  Weight = new_ivector(Numptrn);
  condenceseq(Seqchar, alias, Seqconint, Weight, Maxspc, Maxsite, Numptrn);
  convseq(Seqconint, Maxspc, Numptrn);
  
  Maxbrnch = 2 * Maxspc - 3;
  Maxibrnch = Maxspc - 3;
  Maxpair = (Maxspc * (Maxspc - 1)) / 2;

  Numspc = Maxspc;
  Numbrnch = Maxbrnch;
  Numpair = Maxpair;
  Numsite = Maxsite;
  Numibrnch = Numspc - 3;
  Converg = TRUE;
  Numit = 0;

  Ctree = (Tree *) new_tree(Maxspc, Maxibrnch, Numptrn, Seqconint);

  for (Cnotree = 0; Cnotree < Numtree; Cnotree++) {
    /* Get a topology */
    getusertree(tplfp, Strtree, buftree);
    /* Make a tree */
    constructtree(Ctree, Strtree);
    /* Display the topology */
    prtopology(Ctree);
    putchar('\n');

    /* Remove an internal branch */ 
    removeibranch(Ctree, 0);
    prtopology(Ctree);
    putchar('\n');
    removeibranch(Ctree, 1);
    prtopology(Ctree);
    putchar('\n');
    removeibranch(Ctree, 2);
    prtopology(Ctree);
    putchar('\n');
    removeibranch(Ctree, 3);
    prtopology(Ctree);
    putchar('\n');
    removeibranch(Ctree, 4);
    prtopology(Ctree);
    putchar('\n');
    removeibranch(Ctree, 5);
    prtopology(Ctree);
    putchar('\n');
    removeibranch(Ctree, 6);
    prtopology(Ctree);
    putchar('\n');
    insertibranch(Ctree, Ctree->rootp, Ctree->ibrnchp[0]);
    prtopology(Ctree);
  }
  /*
  insertbranch(ibp, np);
  movebranch(jbp, ip);
  prtopology(tr)
  */
  return 0;
}
