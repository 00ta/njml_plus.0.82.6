/*
 * sltree.c   Adachi, J.   1994.06.24
 * Copyright (C) 1992-1994 J. Adachi & M. Hasegawa, All rights reserved.
 */

#include "protml.h"

void print_paths(ivector);
int lslength(Tree*, dvector, int);

Infosltree *
newinfosltrees(num, maxbrnch)
int num;
int maxbrnch;
{
	int i;
	Infosltree *info;
	double *v;

	info = (Infosltree *)malloc((unsigned)num * sizeof(Infosltree));
	if (info == NULL) maerror("1 in newinfosltrees().");
	v = (double *)malloc((unsigned)(num * maxbrnch) * sizeof(double));
	if (v == NULL) maerror("2 in newinfosltrees().");
	for (i = 0; i < num; i++, v+=maxbrnch)
		info[i].lengths = v;

	return info;
} /*_ newinfosltrees */


Tree *
new_stree(maxspc, maxibrnch, numptrn, seqconint)
int maxspc, maxibrnch;
imatrix seqconint;
{
	int n, i;
	Tree *tr;
	Node *dp, *up;

	tr = (Tree *) malloc(sizeof(Tree));
	if (tr == NULL) maerror("tr in new_tree().");
	tr->ebrnchp = (Node **) malloc((unsigned)maxspc * sizeof(Node *));
	if (tr->ebrnchp == NULL) maerror("ebrnchp in new_tree().");
	tr->ibrnchp = (Node **) malloc((unsigned)maxibrnch * sizeof(Node *));
	if (tr->ibrnchp == NULL) maerror("ibrnchp in new_tree().");
	tr->bturn = new_ivector(maxspc);
	for (n = 0; n < maxspc; n++) {
		tr->bturn[n] = n;
		dp = (Node *) malloc(sizeof(Node));
		if (dp == NULL) maerror("dp in new_tree().");
		up = (Node *) malloc(sizeof(Node));
		if (up == NULL) maerror("up in new_tree().");
		dp->isop = NULL;
		up->isop = NULL;
		dp->kinp = up;
		up->kinp = dp;
		dp->descen = TRUE;
		up->descen = FALSE;
		dp->number = n;
		up->number = n;
		dp->length = 0.0;
		up->length = 0.0;
		dp->lklhdl = 0.0;
		up->lklhdl = 0.0;
		dp->paths = new_ivector(maxspc);
		up->paths = dp->paths;
		for (i = 0; i < maxspc; i++) dp->paths[i] = 0;
		dp->paths[n] = 1;
		dp->eprob = seqconint[n];
		up->eprob = NULL;
		dp->iprob = NULL;
		up->iprob = new_dmatrix(numptrn, Tpmradix);
		tr->ebrnchp[n] = dp;
	}
	for (n = 0; n < maxspc - 1; n++) {
		tr->ebrnchp[n]->kinp->isop = tr->ebrnchp[n + 1]->kinp;
	}
	tr->ebrnchp[maxspc - 1]->kinp->isop = tr->ebrnchp[0]->kinp;
	for (n = 0; n < maxibrnch; n++) {
		dp = (Node *) malloc(sizeof(Node));
		if (dp == NULL) maerror("dp in new_tree().");
		up = (Node *) malloc(sizeof(Node));
		if (up == NULL) maerror("up in new_tree().");
		dp->isop = NULL;
		up->isop = NULL;
		dp->kinp = up;
		up->kinp = dp;
		dp->descen = TRUE;
		up->descen = FALSE;
		dp->number = n;
		up->number = n;
		dp->length = 0.0;
		up->length = 0.0;
		dp->lklhdl = 0.0;
		up->lklhdl = 0.0;
		dp->paths = new_ivector(maxspc);
		up->paths = dp->paths;
		for (i = 0; i < maxspc; i++) dp->paths[i] = 0;
		dp->eprob = NULL;
		up->eprob = NULL;
		dp->iprob = new_dmatrix(numptrn, Tpmradix);
		up->iprob = new_dmatrix(numptrn, Tpmradix);
		tr->ibrnchp[n] = dp;
	}
	tr->rootp = tr->ebrnchp[maxspc - 1]->kinp;

	return tr;
} /*_ new_stree */


void
insertbranch(ibp, np)
Node *ibp, *np;
{
	np->isop = ibp->isop->isop;
	ibp->isop->isop = np->kinp;
	np->kinp->isop = ibp->isop;
	ibp->isop = np;
} /* insertbranch */


void
deletebranch(ibp, np)
Node *ibp, *np;
{
	np->kinp->isop->isop = np->isop;
	ibp->isop = np->kinp->isop;
	np->kinp->isop = NULL; /* redundancy */
	np->isop = NULL; /* redundancy */
} /* deletebranch */


void
movebranch(jbp, ip)
Node *jbp, *ip;
{
	Node *jp;

	jp = jbp->isop; /* Copy jbp->isop */
	jbp->isop = jp->isop; /* Change jp->isop */
	jp->isop = ip->isop;
	ip->isop = jp;
} /* movebranch */

void
removebranch(jbp, ip) /* Re-move branch */
Node *jbp, *ip;
{
	Node *jp;

	jp = ip->isop;
	ip->isop = jp->isop;
	jp->isop = jbp->isop;
	jbp->isop = jp;
} /* removebranch */


void
subpathing(np)
Node *np;
{
  /* paths: pathing to external nodes
     This is an integer vector containing 
     boolean values, FALSE or TRUE
     FALSE: not passed
     TRUE:  passed */

	int i;
	Node *cp; /* isop of a node np */
	boolean *npi, *cpi;

	/* Initialize paths npi to FALSE: "not passed" */
	for (i = 0, npi = np->paths; i < Maxspc; i++) *npi++ = FALSE;
	/* Traverse isop nodes of np */
	for (cp = np->isop; cp != np; cp = cp->isop) {
		npi = np->paths;
		/* print_paths(np->paths); */
		cpi = cp->paths;
		/* print_paths(cp->paths); */
		/* printf("\n"); */
		for (i = 0; i < Maxspc; i++, npi++, cpi++) {
			if (*cpi == TRUE) *npi = *cpi;
			/* print_paths(np->paths); */
			/* printf("\n"); */
			/* printf("\n"); */
		}
	}
/*	for (i=0; i<Maxspc; i++) printf("%1d",np->paths[i]);
	putchar('\n'); */
} /* subpathing */


void
copylength(tr, lengs)
Tree *tr;
dvector lengs; /* branch length vector */ 
{
	int i, j;
	Node **bp;

	bp = tr->ebrnchp;
	for (i = 0; i < Numspc; i++) {
		bp[i]->length = lengs[i];
		bp[i]->kinp->length = lengs[i];
	}
	bp = tr->ibrnchp;
	for (j = 0, i = Numspc; j < Numibrnch; j++, i++) {
		bp[j]->length = lengs[i];
		bp[j]->kinp->length = lengs[i];
	}
}


void
decomposition(tr, n, infosltrees)
Tree *tr;
int n;
Infosltree *infosltrees;
{
	Node *rp, *np, *ibp, *jbp, *ip, *jp, *ibp2, *jbp2, *maxibp, *maxjbp, *op;
	double maxlklhd, maxaprlkl, res, rate, minres;
	Infosltree *head, *tail, *xp, *yp, *zp;
	int i, npair, ntree;
	dvector lengs;

/*	putchar('\n'); */

	/* rp: A pointer to the root */  
	rp = tr->rootp;
	/* np: The n-th internal branch */
	np = tr->ibrnchp[n]->kinp;
	npair = 0;
	minres = 1.0e+37; /* An initial value for the minimum redisual
			     value */
	/* head has lowest liklihood value and
	   the minimum residual */
	head = &infosltrees[MAXSLBUF];
	/* MAXSLBUF = 20 */
	/* At the initial state, tail == head */
	tail = head;
	/* Traverse the star phylogeny */
	for(ibp = rp; ibp->isop != rp; ibp = ibp->isop) {
		ibp2 = ibp;
		ip = ibp->isop;
	/*	printf("ip:%3d\n", ip->number); */
		/* Insert an internal branch np at node ibp */
		prtopology(tr); /* For checking */
		/* printf("%s\n", (char*) fputcphylogeny2(tr)); */
		insertbranch(ibp, np);
		prtopology(tr); /* For checking */
		/* printf("%s\n", (char*) fputcphylogeny2(tr)); */

		/* Make a pairwise cluster */
		for(jbp = np; jbp != rp; jbp = jbp->isop) {
			jbp2 = jbp;
			jp = jbp->isop;
			if (jbp->isop == rp) tr->rootp = jbp;
			movebranch(jbp, ip);
			prtopology(tr); /* For checking */

			subpathing(np->kinp);
		/*	pathing(tr); */
			/* Compute least square branch lengths */
			lslength(tr, Distanvec, Maxspc);
		/*	aproxlkl(tr);
			praproxlkl(tr);
			putctopology(tr); */

			res = tr->rssleast;
			/* A residual value */
#if 0
			printf("%4d%4d%4d%4d %.3f\n",
				n, npair, ip->number+1, jp->number+1, res);
#endif
			/* npair: The current number of infosltrees,
			   which may be less than MAXSLBUF */
			/* Under the following condition,
			   we need to modify infosltrees */
			if (npair < MAXSLBUF || res < tail->residual) {
			  /* tail has the lowest likelihood 
			     value and the lowest redisual so far */
			  /* MAXSLBUF is the length of infosltrees */
				if (res < minres) minres = res;
				/* Update minres */
				if (npair < MAXSLBUF) {
				  /* npiar? */
					yp = &infosltrees[npair];
					/* yp? */
				} else if (res < tail->residual) {
				  /* Update tail */
					yp = tail;
					tail = yp->up;
				}
				yp->residual = res;
				/* The minimum residural */
				yp->ibp = ibp2;
				yp->jbp = jbp2;
				lengs = yp->lengths;
				for (i = 0; i < Numbrnch; i++) lengs[i] = Brnlength[i];
				/* Skip nodes while the residural is the
				   minimum */
				for (xp = tail; res < xp->residual; zp = xp, xp = xp->up)
					;
				/* Move to the next Infosltree */
				yp->up = xp;
				if (tail == xp)
					tail = yp;
				else
					zp->up = yp;
			}
			/* Remove a branch jbp from ip */
			removebranch(jbp, ip);
			/* Close the tree? */ 
			if (jbp->isop == rp) tr->rootp = rp;
			if (jbp == rp) rp = jbp->isop;
			npair++;
			/* npair: probably the number of 
			   stored Infosltrees */
		}
		/* Delete a branch having node ibp at node np */
		deletebranch(ibp, np);
	}
	/* If stored Infosltrees does not reach its upper limit */
	if (npair < MAXSLBUF)
		ntree = npair;
	else
		ntree = MAXSLBUF;
	/* The lowest maximum likelihood method */
	maxaprlkl = -1.0e+37;
	/* xp: ? */ 
	/* Traverse (move on) Infosltrees from tail to head */
	for (xp = tail; xp != head; xp = xp->up) {
		ntree--; /* The number of trees */
		/* Ratio of the current residural and
		   the minimum residural */
		rate = xp->residual / minres; /* !? */
		if (rate < SRSRATE || ntree < 12) { /* SRSRATE = 0.5 */
			tr->rssleast = rate;
			ibp = xp->ibp;
			ip = ibp->isop;
			insertbranch(ibp, np);
			jbp = xp->jbp;
			jp = jbp->isop;
			if (jbp->isop == rp) tr->rootp = jbp;

			movebranch(jbp, ip);
			subpathing(np->kinp);
		/*	pathing(tr); */
			copylength(tr, xp->lengths);
		/*	lslength(tr, Distanvec, Maxspc); */
			aproxlkl(tr);
			xp->lklaprox = tr->lklhd;
#if 0
			printf("%4d%4d%4d ", ntree, ip->number+1, jp->number+1);
			praproxlkl(tr);
			putctopology(tr);
#endif
			removebranch(jbp, ip);
			if (jbp->isop == rp) tr->rootp = rp;
			if (jbp == rp) rp = jbp->isop;
			deletebranch(ibp, np);

			if (tr->lklhd > maxaprlkl) maxaprlkl = tr->lklhd;
			/* Compare likelihood values */
		}
	}

/*	putchar('\n'); */

	maxlklhd = -1.0e+37;
	for (xp = tail; xp != head; xp = xp->up) {
		rate = maxaprlkl - xp->lklaprox; /* !? */
		if (rate < 20) {
			tr->rssleast = rate;
			ibp = xp->ibp;
			ip = ibp->isop;
			insertbranch(ibp, np);
			jbp = xp->jbp;
			jp = jbp->isop;
			if (jbp->isop == rp) tr->rootp = jbp;
			movebranch(jbp, ip);
			subpathing(np->kinp);
		/*	pathing(tr); */
			copylength(tr, xp->lengths);
		/*	lslength(tr, Distanvec, Maxspc); */
			initpartlkl(tr);
			op = (Node *)mlikelihood(tr);
			mlvalue(tr, op, Infotrees);
			xp->lklaprox = tr->lklhd;
#if 0
			printf("%4d%4d\t", ip->number+1, jp->number+1);
			praproxlkl(tr);
			putctopology(tr);
#endif
		/*	prtopology(tr);
			resulttree(tr); */
			removebranch(jbp, ip);
			if (jbp->isop == rp) tr->rootp = rp;
			if (jbp == rp) rp = jbp->isop;
			deletebranch(ibp, np);

			if (tr->lklhd > maxlklhd) {
				maxibp = xp->ibp;
				maxjbp = xp->jbp;
				maxlklhd = tr->lklhd;
			}
		}
	}


	ip = maxibp->isop;
	insertbranch(maxibp, np);
	jp = maxjbp->isop;
/*	printf("%4d%4d%4d\t", n, ip->number + 1, jp->number + 1); */
	if (maxjbp->isop == rp) tr->rootp = maxjbp;
	movebranch(maxjbp, ip);
	subpathing(np->kinp);
/*	lslength(tr, Distanvec, Maxspc);
	initpartlkl(tr);
	op = (Node *)mlikelihood(tr);
	mlvarue(tr, op, Infotrees);
	praproxlkl(tr); */
#if 1
	putctopology(tr);
#endif
} /* decomposition */


void
stardecomp(tr, maxibrnch)
Tree *tr;
int maxibrnch;
{
	int i;
	Infosltree *infosltrees;

	infosltrees = (Infosltree *)newinfosltrees(MAXSLBUF + 1, Maxbrnch);
	/* Make tree informaion infosltrees
	   MAXSLBUF is the number of infosltrees - 1 */
	infosltrees[MAXSLBUF].lklaprox = -1.0e+36;
	/* infosltrees[MAXSLBUF] has the lowest liklihood value */
	infosltrees[MAXSLBUF].residual = 0.0;
	/* infosltrees[MAXSLBUF] has no residual */
	for (i = 0; i < maxibrnch; i++) {
		Numibrnch++;
		Numbrnch++;
		decomposition(tr, i, infosltrees);
	}
} /* stardecomp */


