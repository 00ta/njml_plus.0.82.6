/*
 * tridist.h   Adachi, J.   1994.06.30
 * Copyright (C) 1993, 1994 J. Adachi & M. Hasegawa; All rights reserved.
 */

#include "molphy.h"
#include "matrixut.h"

#define MAXARC    300.0
#define MINARC    0.001
#define EPSILON   0.001
#define MAXCOLUMN 80
#define BUFLINE   512
#define MAXOVER   50
#define MAXLENG   30
#define NMLNGTH   10 /* max. num. of characters in species name with S or I */
#define SWITCHES  "Hhilm:O:ST:vwzZ"
#define VERSION   "1.2.1"
#define DATE      "Jun 30 1994"

typedef struct node {
	struct node *isop;
	struct node *kinp;
	int descen;           /* descendants */
	int number;
	double length;
} Node;

typedef struct tree {
	Node *rootp;
	Node *firstp;
	Node **brnchp;
	double ablength;
	double rssleast;
	int npara;
	imatrix paths;
} Tree;

#ifdef MAIN_MODULE
#define EXTERN
#else
#define EXTERN extern
#endif

EXTERN boolean Least_optn;    /* l option least squares */
EXTERN boolean Outgr_optn;    /* O option */
EXTERN boolean Tfile_optn;    /* T option  Tree file option */
EXTERN boolean Seque_optn;    /* S option  PHYLIP Sequential input format */
EXTERN boolean Verbs_optn;    /* v option  Verbose to stderr */
EXTERN boolean Info_optn;     /* i option  get Information */
EXTERN boolean Multi_optn;    /* m option  multiple data sets */
EXTERN boolean Write_optn;    /* w option  output more infomation */
EXTERN boolean Debug_optn;    /* z option  output debug data */
EXTERN boolean Debug;         /* Z option  output more debug data */

EXTERN char *Prog_name;
EXTERN int Numspc;
EXTERN int Numtree;
EXTERN int Cnotree;
EXTERN int Maxbrnch;
EXTERN int Numbrnch;
EXTERN int Numpair;
EXTERN int Numexe;           /* number of executes */
EXTERN int Cnoexe;           /* curent numbering of executes */
EXTERN int Outgroup;
EXTERN double Proportion;

EXTERN Tree *Ctree;
EXTERN char **Identif;
EXTERN char **Sciname;
EXTERN dmatrix Distanmat;
EXTERN dvector Distanvec;
EXTERN dvector Lengths;
