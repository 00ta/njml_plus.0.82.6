/* Aug 15, 1999 - June 27, 2001 */

/* Modes were changed following the MS; Mar 16, 2001 */
/* Rivived the part for setting bootstrap values the obtained
   topologies. So bootstrap values will be set in njmltrees. njml+
   does not suit simulation any more; Mar 15, 2001 */
/* njml_plus: A new method to reconstruct phylogenetic trees */
/* No site-specific heterogenity is assumed */
/* Aproximation mode is available */
/* Imporoved mode is available */
/* Threshold is dynamically assigned when threshold is "auto" */

/* Modification: */
/* HKY model was added only to ML evaluation; Mar 1, 2001 */
/* init_nj_treefile is used as a final tree for indicating a previous
   tree in tabletree3 (mltree.c); Jan 21, 2001 */
/* all_topon option: -fp -> -p for the JC model; Dec 15, 2000 */
/* init_nj_treefile is used as a final tree in case of Eigen system
   error; Dec 15, 2000 */
/* Deleted the part for setting bootstrap values the obtained topologies. So
   bootstrap values won't be set in njmltrees. This is for simulation
   and ad hoc; Dec 15, 2000 */
/* Eigen system error procedure was added. If eigen system error,
   an initial bootstrap tree will be output as finaltree; Dec 15, 2000 */
/* all_topon option: -p -> -fp for the JC model; Dec 14, 2000 */
/* all_topon option: -fp -> -p for the JC model; Dec 14, 2000 */
/* Set bootstrap values to a final tree (finaltree2); Sep 26, 2000 */
/* Controle file: "njml_plus.ctl" is used; Sep 25, 2000 */
/* Deleting work files before redirection (treefile); Sep23, 2000 */
/* Number of removed branch is now available; Sep 22, 2000 */
/* con2phb was move to under $NJMLDIR; Aug 31, 2000 */
/* phylip_batch was move to under $NJMLDIR; Aug 31, 2000 */

/* Written by Satoshi Ota :- OOta. */

#define MAIN_MODULE 1
#include "protml.h"

char NJMLDIR[256]; /* Environment variable */

boolean select_mltree();
void itoa(int, char*);
void reverse(char *);
int all_topon();
int all_topo();
void nuc_mode_a_b(char *, char *);
void aa_mode_a_b(char *, char *);
void nuc_mode_c_d(char *, char *);
void aa_mode_c_d(char *, char *);
void init_bstree(char *, char *, char *, char *);
int mygetopt(char **, char*, char*);
void make_proper_model(char **);
void aa_all_nuc_mode_b_c2(char *, char *, char *);
void aa_nuc_mode_b_c2(char *);
int get_options ();
MyOption *new_option();
void error (char *);
cvector new_cvector_test();

int main(int argc, char *argv[])
{
  char commandString[256], commandString2[256], mltree[BUFLINE], threshold[64];
  boolean  only_one_tree;
  FILE *ifp, *ofp, *tfp;
  FILE *lfp; /* Likelihood values */
  MyOption *option;
  int step=0;

  option = new_option();
  strcpy(option->ts_tv, "4.0");  /* Default Ts/Tv ratio = 4.0 */

  if (getenv("NJMLDIR") == '\0') {
    puts("set environment variable NJMLDIR.");
    return 1;
  } 
  if (*getenv("NJMLDIR") == '\0') {
    puts("set environment variable NJMLDIR.");
    return 1;
  }
  strcpy(NJMLDIR, getenv("NJMLDIR"));

  if((argc != 1)&&(argc != 2)&&(argc != 5)&&(argc != 6)&&(argc != 7)) {
      puts("njml_plus <Seq file|Control fiile> <auto|Threshod> <JC|K2P|HKY||JTT|JTT2|Dayhoff|Dayhoff2|Poisson> <A|B|C|E> [n [Initial bootstrap tree]]");
      return(1);
  }
  if (argc == 5) {
    /* An initial bootstrap NJ tree */
    strcpy(option->seqfile, argv[1]);
    strcpy(option->threshold, argv[2]);
    strcpy(option->model, argv[3]);
    strcpy(option->mode, argv[4]);
    strcpy(option->n, "3");  /* Default */
    init_bstree(argv[0], option->seqfile, option->model, option->mode);
  } else {
    if (argc == 6) {
      /* An initial bootstrap NJ tree */
      strcpy(option->seqfile, argv[1]);
      strcpy(option->threshold, argv[2]);
      strcpy(option->model, argv[3]);
      strcpy(option->mode, argv[4]);
      strcpy(option->n, argv[5]);
      init_bstree(argv[0], option->seqfile, option->model, option->mode);
    } else {
      if (argc == 7) {
	strcpy(option->seqfile, argv[1]);
	strcpy(option->threshold, argv[2]);
	strcpy(option->model, argv[3]);
	strcpy(option->mode, argv[4]);
	strcpy(option->n, argv[5]);
	sprintf(commandString, "cp %s infile", argv[6]);
	if (system(commandString)) {
	  puts("Error in cp");
	  return 1;
	}
	/* Copy sequence file to ``seq'' */
	sprintf(commandString, "cp %s seq", argv[1]);
	if (system(commandString)) {
	  puts("Error in cp");
	  exit(1);
	} 
	/* Convert sequence from ClustalW to Phylip */
	strcpy(commandString, NJMLDIR);
	strcat(commandString, "/clustalx.linux/clustalw -INFILE=seq -CONVERT=PHYLIP -OUTPUT=PHYLIP -OUTFILE=seq2");
	if(system(commandString)) {
	  puts("Error in clustalw");
	  exit(1);
	}
      } else {
	if (argc == 1) { 
	  get_options("njml_plus.ctl", option);
	  init_bstree(argv[0], option->seqfile, option->model, option->mode);
	} else {
	  if 	(argc == 2) { 
	    get_options(argv[1], option);
	    init_bstree(argv[0], option->seqfile, option->model, option->mode);
	  } else {
	    puts("njml_plus <Seq file|Controle file> <auto|Threshod> <JC|K2P||JTT|Dayhoff|Poisson> <A|B|C|E> [n [Initial bootstrap tree]]");
	    return(1);      
	  }
	}
      } 
    }
  }
  system("cp init_nj_treefile njmltree"); /* For indicating a previous
                                             tree in tabletree3
                                             (mltree.c) */
  /* Open likelihood file */
  if ((lfp = fopen("likelihood", "a")) == NULL)
    fprintf(stderr,"%s: can't open %s\n", argv[0], "likelihood");
  do {
    step++;
    printf("*********************************** STEP %d\n", step);

#if 0 /* For test of conbstree */
    return 0;
#endif
    /* Remove an internal branch having the lowest bootstrap value */
    if ((!strcmp(option->model, "JTT"))||
	(!strcmp(option->model, "Dayhoff"))||
	(!strcmp(option->model, "Poisson"))) {
      /*
      puts("*********************************** conbstree_plus");
      */
      strcpy(commandString, NJMLDIR);
      if (!strcmp(option->threshold, "auto")) {
	sprintf(commandString2, "/src/conbstree_plus seq2 infile %s %s %d", option->threshold, option->n, step);
      } else {
	if (!strcmp(option->threshold, "done")) { /* After getting threshold */
	  sprintf(commandString2, "/src/conbstree_plus seq2 infile %s %s %d", option->threshold, option->n, step);
	} else
	  sprintf(commandString2, "/src/conbstree_plus seq2 infile %s %s %d", option->threshold, option->n, step);
      }
      strcat(commandString, commandString2);
      if(system(commandString)) {
	puts("Error in conbstree_plus!");
	printf("Issued command is: %s\n", commandString);
	return 1;
      }
    }
    else if ((!strcmp(option->model, "K2P"))||
	     (!strcmp(option->model, "JC"))) {
      /*
      puts("*********************************** conbstree_plus2");
      */
      strcpy(commandString, NJMLDIR);
      if (!strcmp(option->threshold, "auto")) {
	sprintf(commandString2, "/src/conbstree_plus2 seq2 infile %s %s %d", option->threshold, option->n, step);
      } else {
	if (!strcmp(option->threshold, "done")) { /* After getting threshold */
	  sprintf(commandString2, "/src/conbstree_plus2 seq2 infile %s %s %d", option->threshold, option->n, step);
	} else
	  sprintf(commandString2, "/src/conbstree_plus2 seq2 infile %s %s %d", option->threshold, option->n, step);
      }
      strcat(commandString, commandString2);
      if(system(commandString)) {
	puts("Error in conbstree_plus2!");
	printf("Issued command is: %s\n", commandString);
	return 1;
      }
    }
    else {
      puts("Model must be JTT, Dayhoff or Poisson for Amino accid.; K2P or JC for Nucleotide.");
      return 1;
    }
    if (!strcmp(option->threshold, "auto")) {
      /* Read threshold */
      if ((tfp = fopen("threshold", "r")) == NULL) {
	fprintf(stderr,"%s: can't open %s\n", argv[0], "threshold");
	exit(1);
      }
      fscanf(tfp, "%s", threshold);
      fclose(tfp);
      strcpy(option->threshold, "done"); /* Threshold gotten */
    }
    system("mv treefile infile");
    system("cp infile bstree"); /* For setting bootstrap values */
#if 0
    return; /* For test */
#endif
    
    /* Make all possible bifurcating trees, and get the maximum
       likelihood values */
    if ((!strcmp(option->model, "JTT"))||
	(!strcmp(option->model, "Dayhoff"))||
	(!strcmp(option->model, "Poisson"))) {
#if 0 /* For test of all_topo */
      return 0;
#endif
      if(all_topo(option, lfp)) {
	/* Eigen system error */	
	/* Phb to topology */
	sprintf(commandString, "%s/src/phb2tp %s init_nj_treefile > init_nj_treefile2", NJMLDIR, "seq2");
	if (system(commandString)) {
	  puts("Error in phb2tp");
	  return 1;
	}
	system("cp init_nj_treefile2 njmltree");
	system("echo 'Eigen system error: please try the other models.' > finaltree");
	break;
      } else {
	system("mv treefile infile");
      }
    } else if ((!strcmp(option->model, "K2P"))||
	     (!strcmp(option->model, "JC"))) {
#if 0 /* For test of all_topon */
      return 1;
#endif
      if(all_topon(option, lfp)) {
	/* Eigen system error */
	system("cp init_nj_treefile njmltree");
	system("echo 'Eigen system error: please try the other models.' > finaltree");
	break;
      } else {
	system("mv treefile infile");
      }
    } else {
      puts("Model must be JTT, Dayhoff or Poisson for Amino accid.; K2P or JC for Nucleotide.");
      return 1;
    }
#if 0 /* Test for select_ml */
    return 0;
#endif
    
    /* Select the maximum likelihood topology */
    /* Open a candidate topologies file */
    if ((ifp = fopen("infile", "r")) == NULL)
      fprintf(stderr,"%s: can't open %s\n", argv[0], "infile");
    only_one_tree = select_mltree(ifp, lfp, &mltree);
    fclose(ifp);
    /* Output NJML tree */
    if ((ofp = fopen("treefile", "w")) == NULL)
      fprintf(stderr,"%s: can't open %s\n", argv[0], "treefile");
    fputs(mltree, ofp);
    fputs("\n", ofp);
    fclose(ofp);
    //mltree = NULL;
    //free_cvector(mltree);
    system("mv treefile infile");
    system("cp infile njmltree");
#if 0 /* Test for setbs */
    return 0;
#endif
    if ((!strcmp(option->model, "JTT"))||
	(!strcmp(option->model, "Dayhoff"))||
	(!strcmp(option->model, "Poisson"))) {
      /*
      puts("*********************************** setbs");    
      */
      /* Set bootstrap values the obtained topologies */
      sprintf(commandString, "%s/src/setbs seq2 bstree infile %d", NJMLDIR, step);
      if (system(commandString)) {
	puts("Error in setbs!");
	return 1;
      }
    }
    else if ((!strcmp(option->model, "K2P"))||
	     (!strcmp(option->model, "JC"))) {
      /*
      puts("*********************************** setbsn");    
      */
      /* Set bootstrap values the obtained topologies */
      sprintf(commandString, "%s/src/setbsn seq2 bstree infile %d", NJMLDIR, step);
      if (system(commandString)) {
	puts("Error in setbsn!");
	return 1;
      }
    }
    system("mv treefile infile");
  } while (!only_one_tree);
  fclose(lfp);

  /* Exact branch length estimation for approximation mode */
  if (!strcmp(option->mode, "B")) {
    strcpy(option->mode, "D");
    if ((!strcmp(option->model, "JTT"))||
	(!strcmp(option->model, "Dayhoff"))||
	(!strcmp(option->model, "Poisson")))
      all_topo(option, lfp);
    else if ((!strcmp(option->model, "K2P"))||
	     (!strcmp(option->model, "JC")))
      all_topon(option, lfp);
    else {
      puts("Model must be JTT, Dayhoff or Poisson for Amino accid.; K2P or JC for Nucleotide.");
      return 1;
    }
    system("mv treefile infile");
  }
#if 1
  /* Set bootstrap values the obtained topologies */
  if ((!strcmp(option->model, "JTT"))||
      (!strcmp(option->model, "Dayhoff"))||
      (!strcmp(option->model, "Poisson")))
    {
      sprintf(commandString, "%s/src/make_finaltree2 seq2 bstree finaltree", NJMLDIR);
    } else {
      if ((!strcmp(option->model, "K2P"))||
	  (!strcmp(option->model, "JC"))){
	sprintf(commandString, "%s/src/make_finaltreen2 seq2 bstree finaltree", NJMLDIR);
      }
    }
  if (system(commandString)) {
    printf("Error in %s\n", commandString);
    return 1;
  }
  system("mv treefile finaltree2");
#endif
  printf("Used CPU time: %f in select_mltree + njml\n", (double)clock() / CLOCKS_PER_SEC);
  printf("A final result was output to \"finaltree2.\"\n");
  return 0;
}
  
void itoa(int n, char s[]) {
  int i, sign;
  
  if ((sign = n) < 0)
    n = -n;
  i = 0;
  do {
    s[i++]=n % 10 + '0';
  } while ((n /= 10) > 0);
  if (sign < 0)
    s[i++] = '-';
  s[i] = '\0';
  reverse(s);
}

void reverse(char s[]) {
  int c, i, j;
  
  for (i = 0, j = strlen(s) - 1; i < j; i++, j--){
    c = s[i];
    s[i] = s[j];
    s[j] = c;
  }
}

int all_topon(MyOption *option, FILE *lfp) {
    char commandString[256];
    boolean eigen_system_error=FALSE;
    
    /*
     puts("*********************************** all_topon");
     */
    strcpy(commandString, NJMLDIR);
    if ((!strcmp(option->mode, "A")) || (!strcmp(option->mode, "C")))
        strcat(commandString, "/src/all_topon -A");
    else {
        if ((!strcmp(option->mode, "B")) || (!strcmp(option->mode, "D"))) {
            strcat(commandString, "/src/all_topon");
        } else {
            puts("Mode must be A, B, C, or D (Approximate, Exact or Burst mode)");
            return 1;
        }
    }
    if (!strcmp(option->model, "JC"))
        strcat(commandString, " -p ");
    else {
        if (!strcmp(option->model, "K2P")) {
            strcat(commandString, " -ft ");
            strcat(commandString, option->ts_tv);
            strcat(commandString, " ");
        } else {
            if (!strcmp(option->model, "HKY")) {
                strcat(commandString, " -t ");
                strcat(commandString, option->ts_tv);
                strcat(commandString, " ");
            } else {
                puts("Model must be JC or K2P");
                return 1;
            }
        }
    }
    strcat(commandString, "-I seq2 infile");
    if(system(commandString)) {
        eigen_system_error = TRUE; /* Eigen system error or something wrong */
        fputs("Eigen system error!", lfp);
        return 1;
    }
    return 0;
}

int all_topo(MyOption *option, FILE *lfp) {
    char commandString[256];
    boolean eigen_system_error=FALSE;
    
    /*
     puts("*********************************** all_topo");
     */
    strcpy(commandString, NJMLDIR);
    if ((!strcmp(option->mode, "A")) || (!strcmp(option->mode, "C"))) {
        strcat(commandString, "/src/all_topo -A");
    } else {
        if ((!strcmp(option->mode, "B")) || (!strcmp(option->mode, "D"))) {
            strcat(commandString, "/src/all_topo");
        } else {
            puts("Mode must be A, B, C, or D (Approximate, Exact, or Burst mode)");
            return 1;
        }
    }
    if (!strcmp(option->model, "JTT"))
        strcat(commandString, " -j ");
    else
        if (!strcmp(option->model, "Dayhoff"))
            strcat(commandString, " -d ");
        else if (!strcmp(option->model, "Poisson"))
            strcat(commandString, " -p ");
        else {
            puts("Model must be  JTT|Poisoon|Dayhoff");
            return 1;
        }
    strcat(commandString, "-I seq2 infile");
    printf("\nIssued command is: %s\n\n",commandString);
    if(system(commandString)) {
        eigen_system_error = TRUE; /* Eigen system error */
        fputs("Eigen system error!", lfp);
        return 1;
    }
    return 0;
}

void nuc_mode_a_b(char *model, char *commandString) {
  strcat(commandString, "/clustalx.linux/clustalw -KIMURA=4.0 -BOOTSTRAP=100 -INFILE=seq -BOOTLABELS=node");
  if(system(commandString)) {
    puts("Error in clustalw");
    exit(1);
  }
  system("mv seq.phb infile");
  system("cp infile init_nj_treefile"); /* For Eigen system error */
}

void nuc_mode_c_d(char *model, char *commandString) {
  strcat(commandString, "/clustalx.linux/clustalw -INFILE=seq -CONVERT=PHYLIP -OUTPUT=PHYLIP -OUTFILE=seq2");
  if(system(commandString)) {
    puts("Error in clustalw");
    exit(1);
  }
  if (system("cp seq2 infile")) {
    puts("Error in cp");
    exit(1);
  } 
  /* Bootstrap resampling */
  strcpy(commandString, NJMLDIR);
  strcat(commandString, "/phylip_batch/seqboot");
  if (system(commandString)) {
    puts("Error in seqboot");
    exit(1);
  }
  system("mv outfile infile");
  strcpy(commandString, NJMLDIR);
  strcat(commandString, "/phylip_batch/dnadist2");
  if (!strcmp(model, "JC"))
    strcat(commandString, " JC ");
  else
    if (!strcmp(model, "K2P"))
      strcat(commandString, " K2P ");
  if(system(commandString)) {
    puts("Error in dnadist2");
    exit(1);
  }
  system("mv outfile infile");
  /* Reconstruct an NJ tree */ 
  strcpy(commandString, NJMLDIR);
  strcat(commandString, "/phylip_batch/neighbor");
  if(system(commandString)) {
    puts("Error in neighbor");
    exit(1);
  }
  system("mv treefile infile");
  /* Make a consensus tree */
  sprintf(commandString, "%s/phylip_batch/consense", NJMLDIR);
  if(system(commandString)) {
    puts("Error occurred in consense!"); 
    exit(1);
  }
  system("cp treefile init_nj_treefile"); /* For Eigen system error */
  system("mv treefile infile");
  /* Convert a consensus tree to a bootstrap tree */
  /*
  puts("*********************************** con2phb");
  */
  if (system("rm -f treefile")) {
    puts("Error in rm");
    exit(1);
  }
  sprintf(commandString, "%s/src/con2phb infile > treefile", NJMLDIR);
  if(system(commandString)) {
    puts("Error occurred in con2phb!"); 
    exit(1);
  } 
  system("mv treefile infile");
}

void aa_mode_a_b(char *model, char *commandString) {
  strcat(commandString, "/clustalx.linux/clustalw -KIMURA=4.0 -BOOTSTRAP=100 -INFILE=seq -BOOTLABELS=node");
  if(system(commandString)) {
    puts("Error in clustalw");
    exit(1);
  }
  system("mv seq.phb infile");
  system("cp infile init_nj_treefile"); /* For Eigen system error */
}

void aa_mode_c_d(char *model, char *commandString) {
  strcat(commandString, "/clustalx.linux/clustalw -INFILE=seq -CONVERT=PHYLIP -OUTPUT=PHYLIP -OUTFILE=seq2");
  if(system(commandString)) {
    puts("Error in clustalw");
    exit(1);
  }
  if (system("cp seq2 infile")) {
    puts("Error in cp");
    exit(1);
  } 
  /* Bootstrap resampling */
  strcpy(commandString, NJMLDIR);
  strcat(commandString, "/phylip_batch/seqboot");
  if (system(commandString)) {
    puts("Error in seqboot");
    exit(1);
  }
  system("mv outfile infile");
  strcpy(commandString, NJMLDIR);
  strcat(commandString, "/phylip_batch/protdist2");
  if ((!strcmp(model, "Dayhoff")) || (!strcmp(model, "JTT")))
    strcat(commandString, " Dayhoff ");
  else
      strcat(commandString, " KIMURA ");
  if(system(commandString)) {
    puts("Error in protdist2");
    exit(1);
  }
  system("mv outfile infile");
  /* Reconstruct an NJ tree */ 
  strcpy(commandString, NJMLDIR);
  strcat(commandString, "/phylip_batch/neighbor");
  if(system(commandString)) {
    puts("Error in neighbor");
    exit(1);
  }
  system("mv treefile infile");
  /* Make a consensus tree */
  if(system("/home/oota/paper/1999/phylip_batch/consense")) {
    puts("Error occurred in consense!"); 
    exit(1);
  }
  system("cp treefile init_nj_treefile"); /* For Eigen system error */
  system("mv treefile infile");
  /* Convert a consensus tree to a bootstrap tree */
  /*
  puts("*********************************** con2phb");
  */
  if(system("/home/oota/paper/1999/njml.0.05/con2phb infile > treefile")) {
    puts("Error occurred in con2phb!"); 
    exit(1);
  } 
  system("mv treefile infile");
}

void init_bstree(char *program, char *seq_file_name, char *model, char *mode)
{
  char commandString[256];

  /* An initial bootstrap NJ tree */
  sprintf(commandString, "cp %s seq", seq_file_name);
  if (system(commandString)) {
   puts("Error in cp");
    exit(1);
  } 
  strcpy(commandString, NJMLDIR);
  if ((!strcmp(model, "JC") ||
       !strcmp(model, "K2P")) &&
      (!strcmp(mode, "A") ||
       !strcmp(mode, "B"))) { /* Nucleotide and mode A or B */
    nuc_mode_a_b(model, commandString);
  } else {
    if ((!strcmp(model, "JC") ||
	 !strcmp(model, "K2P")) &&
	(!strcmp(mode, "C") || 
	 !strcmp(mode, "D"))) { /* Nucleotide and mode C or D */
      nuc_mode_c_d(model, commandString);
    } else {
      if (
	  (!strcmp(model, "JTT")     ||
	   !strcmp(model, "Dayhoff") ||
	   !strcmp(model, "Poisson")) &&
	  (!strcmp(mode, "A") ||
	   !strcmp(mode, "B"))) { /* Amino acid and mode A or B */
	    aa_mode_a_b(model, commandString);
      } else {
	if (
	  (!strcmp(model, "JTT")     ||
	   !strcmp(model, "Dayhoff") ||
	   !strcmp(model, "Poisson")) &&
	  (!strcmp(mode, "C") ||
	   !strcmp(mode, "D"))) { /* Amino acid and mode C or D */
	  aa_mode_c_d(model, commandString);
	} else {
	  puts("Model must be JTT, Dayhoff or Poisson for Amino accid.; K2P or JC for Nucleotide, or Burst mode.");
	  exit(1);
	}
      }
    }
  }
  strcpy(commandString, NJMLDIR);
  strcat(commandString, "/clustalx.linux/clustalw -INFILE=seq -CONVERT=PHYLIP -OUTPUT=PHYLIP -OUTFILE=seq2");
  if(system(commandString)) {
    puts("Error in clustalw");
    exit(1);
  }
}

void make_proper_model(char **model) {
  char model2[64];
  int i, len;

  len = strlen(*model);
  len--;
  for (i = 0; i < len; i++) {
    model2[i] = (*model)[i];
  }
  model2[i] = '\0';
  strcpy(*model, model2);
}
    
int get_options (char *ctlf, MyOption *option)
{
   int i, nopt=6, lline=255, t;
   char line[255], *pline, opt[20], comment='*';
   char *optstr[] = {"seqfile","threshold","model", "TS/TV", "mode", "n"};
   FILE  *fctl=fopen (ctlf, "r");
   int noisy=2;

   if (fctl) {
      for (;;) {
         if (fgets (line, lline, fctl) == NULL) break;
         for (i=0,t=0; i<lline&&line[i]; i++)
            if (isalnum(line[i]))  { t=1; break; }
            else if (line[i]==comment) break;
         if (t==0) continue;
         sscanf (line, "%s%*s%d", opt, &t);
         if ((pline=strstr(line, "= "))==NULL) error ("option file.");

         for (i=0; i<nopt; i++) {
            if (strncmp(opt, optstr[i], 8)==0)  {
               if (noisy>2)
                  printf ("\n%3d %15s | %-20s %6d", i+1,optstr[i],opt,t);
               switch (i) {
                  case ( 0): sscanf(pline+2, "%s", option->seqfile);    break;
                  case ( 1): sscanf(pline+2, "%s", option->threshold);    break;
                  case ( 2): sscanf(pline+2, "%s", option->model);    break;
                  case  (3): sscanf(pline+2, "%s", option->ts_tv);    break;
                  case  (4): sscanf(pline+2, "%s", option->mode);    break;
                  case  (5): sscanf(pline+2, "%s", option->n);    break;
               }
               break;
            }
         }
         if (i==nopt)
            { printf ("\nopt %s in %s\n", opt, ctlf);  exit (-1); }
      }
      fclose (fctl);
   }
   else
      if (noisy) printf ("\nno ctl file..");

   return (0);
}

MyOption *new_option() {
  MyOption *option;

  option = (MyOption *) malloc(sizeof(MyOption));
  option->seqfile = new_cvector(64);
  option->threshold = new_cvector(10);
  option->model = new_cvector(10);
  option->ts_tv = new_cvector(10);
  option->mode = new_cvector(1);
  option->n = new_cvector(10);
  return option;
}

void error (char * message)
{ printf("\n%s.\n", message);    exit (-1); }

