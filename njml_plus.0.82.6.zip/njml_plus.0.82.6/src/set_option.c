#include "protml.h"

void set_option() {
  Inlvd_optn  = TRUE;
  Seque_optn  = FALSE;
}
