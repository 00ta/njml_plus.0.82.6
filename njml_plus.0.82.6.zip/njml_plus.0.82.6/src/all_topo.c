/* all_topo generates all possible bifurcating tree topologies from a
   multifurcating tree, and optimizes branch lengths */
/* Nucleotide version: all_topon */
/* March 1, 2000 - Mar 11, 2001 */

/* Modification */
/* tabletree2 is currently used instead of tabletree3; Mar 11, 2001 */
/* Likelihood values, standard errors, and differences to the best are
   recorded in a file "std_err", not in "treefile_test"; Jan 18,
   2001 */
/* Record likelihood values, standard errors, and differences
     to the best ("treefile_test"); Dec 27, 2000 */
/* tabletree2: The third argument bs_for_best returns a bootstap value 
   for the best tree; Dec 18, 2000 */

#define MAIN_MODULE 1
#include "protml.h"

void all_topo(Tree *, cvector, int, FILE *);
void helpinfo();
void usage();
void removeibranch();
void rerootq();
Tree *new_tree();
Infotree *newinfotrees();
Infoaltree *newinfoaltrees();
void getsize(FILE*, int*, int*, char**);
void distance(dmatrix, cmatrix, int, int);
void tranprobmat();
void convfreq(double *);
void lddistance(dmatrix, cmatrix, int, int);
void changedistan(dmatrix, dvector, int);

int main(int argc, char**argv){
  FILE *ifp, *tplfp, *Rtfifp, *Logfp, *Lklfp, *Bs_for_bestfp;
  int i, j, k, buftree, num;
  char *comment, ch;
  boolean num_flag;
  char **cpp;
  extern char *Optargp;  /* pointer to argument of current option */
  extern int Optindex;   /* index of next argument */
  ivector alias;

  if((Prog_name = strrchr(argv[0], DIR_CHAR)) != NULL )
    Prog_name++;
  else
    Prog_name = argv[0];
  
  Relia_optn = FALSE;
  Rrtf_optn  = FALSE;
  Boots_optn = TRUE; /* default with User_optn*/
  Auto_optn  = FALSE;
  Semi_optn  = FALSE;
  User_optn  = FALSE;
  num_flag   = FALSE;
  Numaltree = NUMALTREES;
  Numqltree = NUMQLTREES;
#ifndef NUC
  Jtt_optn   = TRUE;
  Frequ_optn = FALSE;
#else  /* NUC */
  Jtt_optn   = FALSE;
  Frequ_optn = TRUE;
  Tstv_optn  = FALSE;
  AlphaBeta = ALPHABETA;
  AlphaYR   = ALPHAYR;
#endif /* NUC */
  while((ch = mygetopt(argc, argv, SWITCHES)) != -1 ) {
    switch(ch) {
#ifndef NUC
    case 'j': Jtt_optn    = TRUE;
      Dayhf_optn  = FALSE;
      Poisn_optn  = FALSE;
      Rrtf_optn   = FALSE; break;
    case 'd': Dayhf_optn  = TRUE;
      Jtt_optn    = FALSE;
      Poisn_optn  = FALSE;
      Rrtf_optn   = FALSE; break;
    case 'f': Frequ_optn  = TRUE;  break;
    case 'p': Poisn_optn  = TRUE;
      Jtt_optn    = FALSE;
      Dayhf_optn  = FALSE;
      Rrtf_optn   = FALSE; break;
    case 'r': Rrtf_optn   = TRUE;
      Jtt_optn    = FALSE;
      Dayhf_optn  = FALSE;
      Poisn_optn  = FALSE; break;
#else  /* NUC */
    double x;
    case 't': cpp = &Optargp;
      Tstv_optn   = TRUE;
      if (x = strtod(Optargp, cpp)) {
	AlphaBeta = x;
	if (**cpp == ',') {
	  Optargp = ++(*cpp);
	  if (x = strtod(Optargp, cpp)) AlphaYR = x;
	}
      } else {
	Toptim_optn = TRUE;
	if (strchr(Optargp, ',')) {
	  Toptim_optn = 2;
	  AlphaBeta = 1.0;
	  AlphaYR = 1.0;
	}
      }
      break;
    case 'f': Frequ_optn  = FALSE; break;
    case 'p': Poisn_optn  = TRUE;
      Jtt_optn    = FALSE;
      Dayhf_optn  = FALSE;
      Rrtf_optn   = FALSE; break;
    case 'r': Rrtf_optn   = TRUE;
      Poisn_optn  = FALSE; break;
#endif /* NUC */
    case 'F': Logdet_optn = TRUE;  break;
      
    case 'e': Auto_optn   = TRUE;
      User_optn   = FALSE;
      Stard_optn  = FALSE;
      Quick_optn  = FALSE;
      Boots_optn  = FALSE; break;
    case 'u': User_optn   = TRUE;
      Auto_optn   = FALSE;
      Stard_optn  = FALSE;
      Quick_optn  = FALSE; break;
    case 'q': Quick_optn  = TRUE;
      User_optn   = FALSE;
      Stard_optn  = FALSE;
      Auto_optn   = FALSE; break;
    case 'Q': Quick1_optn = TRUE;
      User_optn   = FALSE;
      Stard_optn  = FALSE;
      Auto_optn   = FALSE; break;
    case 's': Stard_optn  = TRUE;
      Quick_optn  = FALSE;
      Quick1_optn = FALSE;
      User_optn   = FALSE;
      Auto_optn   = FALSE; break;
      
    case 'n': cpp = &Optargp;
      num_flag    = TRUE;
      if (i = strtol(Optargp, cpp, 10)) num = i; break;
    case 'b': Boots_optn  = FALSE; break;
    case 'R': Relia_optn  = TRUE;  break;
    case 'T': Triad_optn  = TRUE;  break;
    case 'D': Distn_optn  = TRUE;  break;
    case 'A': Aprox_optn  = TRUE;  break;
    case 'l': Lklhd_optn  = TRUE;  break;
    case 'L': Logfl_optn  = TRUE;  break;
    case 'i': Info_optn   = TRUE;  break;
    case 'm': cpp = &Optargp;
      Multi_optn  = TRUE;
      if (i = strtol(Optargp, cpp, 10)) Numexe = i; break;
    case 'v': Verbs_optn  = TRUE;  break;
    case 'V': Varia_optn  = TRUE;  break;
    case 'w': Write_optn  = TRUE;  break;
    case 'S': Seque_optn  = TRUE;
      Inlvd_optn  = FALSE; break;
    case 'I': Inlvd_optn  = TRUE;
      Seque_optn  = FALSE; break;
#if 1
    case 'z': Debug_optn  = TRUE;  break;
    case 'Z': Debug       = TRUE;  break;
#endif
    case 'C': Ctacit_optn = TRUE;  break;
    case 'h':
    case 'H': helpinfo(); exit(1);
    default : usage(); exit(1);
    }
  }
  if (Auto_optn) {
    if (Optindex + 2 == argc) {
      Auto_optn  = FALSE;
      Semi_optn  = TRUE;
    }
  }
  if (!Auto_optn && !Semi_optn && !User_optn &&
      !Quick_optn && !Quick1_optn && !Stard_optn && !Distn_optn) {
    if (Optindex == argc) {
      helpinfo(); exit(1); /* default  !? */
    } else if (Optindex + 1 == argc) {
      helpinfo(); exit(1); /* default  !? */
    } else if (Optindex + 2 == argc) {
      User_optn  = TRUE; /* default  !? */
    }
  }
  if (num_flag) {
    if (Quick_optn || Quick1_optn) Numqltree = num;
    if (Auto_optn || Semi_optn) Numaltree = num;
  }
  *Modelname = '\0';
#ifndef NUC
  if (Poisn_optn) {
    if (!Frequ_optn) strcat(Modelname, "Poisson");
    else             strcat(Modelname, "Proportional");
  } else if (Rrtf_optn) {
    strcat(Modelname, "Read RTF");
  } else {
    if (Jtt_optn) {
      strcat(Modelname, "JTT");
    } else if (Dayhf_optn) {
      strcat(Modelname, "Dayhoff");
    } else {
      strcat(Modelname, "unknown");
    }
    if (Frequ_optn) strcat(Modelname, "-F");
  }
#else  /* NUC */
    char buf[64];
    if (Poisn_optn) {
        if (!Frequ_optn) strcat(Modelname, "Poisson");
        else             strcat(Modelname, "Proportional");
        AlphaBeta = 1.0;
        AlphaYR = 1.0;
    } else if (Rrtf_optn) {
        strcat(Modelname, "Read RTF");
        if (Frequ_optn) strcat(Modelname, " F");
    } else {
        if (Toptim_optn) {
            strcat(Modelname, "A/B:opt");
            if (Toptim_optn == 2) strcat(Modelname, " Ay/Ar:opt");
        } else {
            sprintf(buf, "A/B:%.2f\0", AlphaBeta);
            strcat(Modelname, buf);
            if (AlphaYR != 1.0) {
                sprintf(buf, " Ay/Ar:%.2f", AlphaYR);
                strcat(Modelname, buf);
            }
        }
        if (Frequ_optn) strcat(Modelname, " F");
    }
#endif /* NUC */
  /*	printf("\"%s\"\n", Modelname); */
  
#ifdef DEBUG
  if (Debug) {
    printf("argc = %d\n",argc);
    for(i = 0; i < argc; i++) printf("argv[%d] = %s\n",i,argv[i]);
    putchar('\n');
    printf("\nOptindex = %d\n",Optindex);
    printf("Optargp = %s\n",Optargp);
  }
#endif
  
  if (Optindex == argc) {
    ifp = stdin;
    tplfp = stdin;
  } else if (Optindex + 1 == argc) {
    if ((ifp = fopen(argv[Optindex++], "r")) == NULL) {
      fprintf(stderr,"%s: can't open %s\n",Prog_name,argv[--Optindex]);
      exit(1);
    } else {
      tplfp = ifp;
    }
  } else if (Optindex + 2 == argc) {
    if ((ifp = fopen(argv[Optindex++], "r")) == NULL) {
      fprintf(stderr,"%s: can't open %s\n",Prog_name,argv[--Optindex]);
      exit(1);
    } else if ((tplfp = fopen(argv[Optindex], "r")) == NULL) {
      if (*argv[Optindex] == '-') {
	tplfp = stdin;
      } else {
	fprintf(stderr,"%s: can't open %s\n",Prog_name,argv[Optindex]);
	exit(1);
      }
    }
  } else {
    fprintf(stderr, "%s: Inconsistent number of operand in command line!\n",
	    Prog_name);
    usage();
    exit(1);
  }
  if (Rrtf_optn) {
    if ((Rtfifp = fopen(RTFINFILE, "r")) == NULL) {
      fprintf(stderr,
	      "%s: can't open RTF file: %s\n",Prog_name,RTFINFILE);
      exit(1);
    }
  }
  if (Logfl_optn) {
    if ((Logfp = fopen(LOGFILE, "w")) == NULL) {
      fprintf(stderr,
	      "%s: can't open log file: %s\n",Prog_name,LOGFILE);
      exit(1);
    }
  }
  if (Lklhd_optn) {
    if ((Lklfp = fopen(LKLFILE, "a")) == NULL) {
      fprintf(stderr,
	      "%s: can't open log likelihood file: %s\n",Prog_name,LKLFILE);
      exit(1);
    }
  }
  
  /* Get size of sequence data */
  getsize(ifp, &Maxspc, &Maxsite, &comment);

  /* Allocate memory space for names of sequence data */
  Identif = (char **)malloc((unsigned)Maxspc * sizeof(char *));
  if (Identif == NULL) maerror("in tree");

  /* Allocate memory space for sequene data */
  Seqchar = new_cmatrix(Maxspc, Maxsite);

  /* Get sequence data */
  /*
  Seque_optn = TRUE;
  Inlvd_optn = FALSE;
  */
  /* Allocate memory space for science names */
  Sciname = (char **)malloc((unsigned)Maxspc * sizeof(char *));
  if (Sciname == NULL) maerror("in prologue, Sciname");
  if (Seque_optn)
    getseqs(ifp, Identif, Seqchar, Maxspc, Maxsite);
  else if (Inlvd_optn)
    /* Get a sequence set in interleaved input format */
    getseqi(ifp, Identif, Seqchar, Maxspc, Maxsite);
  else
    getseq(ifp, Identif, Sciname, Seqchar, Maxspc, Maxsite);

  /* Allocate memory space for a topology represented by a string */
  buftree =  getbuftree(Maxspc, Identif);
  Strtree = new_cvector(buftree);

  /* Some preparations for making trees */  
  getfreqepm(Seqchar, Freqemp, Maxspc, Maxsite);
  alias = new_ivector(Maxsite);
  radixsort_njml(Seqchar, alias, Maxspc, Maxsite, &Numptrn);
  Seqconint = new_imatrix(Maxspc, Numptrn);
  Weight = new_ivector(Numptrn);
  condenceseq(Seqchar, alias, Seqconint, Weight, Maxspc, Maxsite, Numptrn);
  convseq(Seqconint, Maxspc, Numptrn);
  
  Numaltree = 100;
  Maxbrnch = 2 * Maxspc - 3;
  Maxibrnch = Maxspc - 3;
  Maxpair = (Maxspc * (Maxspc - 1)) / 2;

  Numspc = Maxspc;
  Numbrnch = Maxbrnch;
  Numpair = Maxpair;
  Numsite = Maxsite;
  Numibrnch = Numspc - 3;
  Converg = TRUE;
  Numit = 0;
#if 0
  Numtree = 105; /* Upper limit of the number of trees ? */
#endif
  Numtree = 10395; /* Upper limit of the number of trees ? */
  Numaltree = 10395;

  Distanmat = new_dmatrix(Maxspc, Maxspc);
  Distanvec = new_dvector(Maxpair);
  Brnlength = new_dvector(Maxbrnch);  

  Infotrees = (Infotree *) newinfotrees(Numtree, buftree);

  /* Transition matrix */
  if (Frequ_optn) convfreq(Freqemp);
  tranprobmat(); /* Eigen system error is not considered */

  /* Distance matrix */
  if (Logdet_optn) {
    lddistance(Distanmat, Seqchar, Maxspc, Maxsite);
  } else
    distance(Distanmat, Seqchar, Maxspc, Maxsite);
    

#if 1
  if (Triad_optn) tridistance(Distanmat, Seqconint, Weight, Maxspc, Numptrn);
#else
  if (Triad_optn) tridistance2(Distanmat, Seqchar, Maxspc, Maxsite);
#endif
    Debug=TRUE;
    if (Debug) {
        printf("\n");
        for (i = 0; i < Maxspc; i++) {
            for (j = 0; j < Maxspc; j++) {
                printf("%5.1f", Distanmat[i][j]);
            }
            printf("\n");
        }
    }
  changedistan(Distanmat, Distanvec, Maxspc);
    if (Debug) {
        for (k= 0, i = 1; i < Numspc; i++) {
            for (j = 0; j < i; j++, k++)
                printf("Distanvec[%d]: %f\n", k, Distanvec[k]);
        }
    }
  if (!Cnoexe) getproportion(&Proportion, Distanvec, Maxpair);
  Ctree = (Tree *) new_tree(Maxspc, Maxibrnch, Numptrn, Seqconint);
  /* Preparation for reliability mode */
  if (Relia_optn) {
    Relistat = new_ivector(Numibrnch);
    Reliprob = new_dmatrix(Numibrnch, 2);
    Relinum  = new_imatrix(Numibrnch, 2);
    /*
    fprintf(Tplfp, "%d\n", Numtree);
    */
  }
  /* Get a topology */
  getusertree(tplfp, Strtree, buftree);
  if ((Bs_for_bestfp = fopen("bs_for_best", "a")) == NULL)
    fprintf(stderr,"%s: can't open %s\n",Prog_name, "bs_for_best", Bs_for_bestfp);
  all_topo(Ctree, Strtree, buftree, Bs_for_bestfp);
  fclose(Bs_for_bestfp);

  /* Release memory for reliability mode */
  if (Relia_optn) {
    free_ivector(Relistat);
    free_dmatrix(Reliprob);
    free_imatrix(Relinum);
  }
  /* Close option-related files */
  if (tplfp != stdin && tplfp != ifp) fclose(tplfp);
  if (ifp != stdin) fclose(ifp);
  if (Lklhd_optn) fclose(Lklfp);
  if (Logfl_optn) fclose(Logfp);
  if (Rrtf_optn) fclose(Rtfifp);
  printf("Used CPU time: %f in all_topo (or all_topon)\n", (double)clock() / CLOCKS_PER_SEC);
  return 0;
}

void all_topo(Tree *tree, cvector strtree, int buftree, FILE *Bs_for_bestfp) {
  int cnospc, i, j;
  Node *rp, **poolnode, **addposition;
  Infoaddtree *topaddtree, *curp, *insp;
  char *cltree;
  double lkla, *bs_for_best;
  FILE *fp, *std_err_fp;

  bs_for_best = (double *)malloc(sizeof(double));
  Cnotree = 0;
  Poolorder = new_ivector(Maxspc);
  /*
  tree = (Tree *) new_atree(Maxspc, Maxibrnch, Numptrn, Seqconint);
  */
  tree = (Tree *) new_tree(Maxspc, Maxibrnch, Numptrn, Seqconint);
  poolnode = (Node **)malloc((unsigned)Maxspc * sizeof(Node *));
  if (poolnode == NULL) maerror("poolnode.");
  addposition = (Node **)malloc((unsigned)Maxspc * sizeof(Node *));
  if (addposition == NULL) maerror("addposition.");

#ifdef LIGHT
  Lklptrn = new_fmatrix(Numtree, Numptrn);
#else  /* LIGHT */
  Lklptrn = new_dmatrix(Numtree, Numptrn);
  /* Likelihood pattern for each site
     This will be used to compute standard errors */
#endif /* LIGHT */
  /*
  puts(Strtree);
  */
  streeinit_njml(tree, strtree, poolnode, addposition, Poolorder);
  Infoaltrees = (Infoaltree *) newinfoaltrees(Numaltree, buftree);
  Ahead.lklaprox = 0.0;
  Atail.up = &Ahead;
  Ahead2.lklaprox = 0.0;
  Atail2.up = &Ahead2;
  /* If root has more than three nodes */
  if (addposition[3] == NULL)
    autoconstruction_njml(tree, 3, poolnode, addposition, Poolorder, buftree);
  else
    wedge_njml(tree, 3, poolnode, addposition, Poolorder, addposition[3], buftree);
  /* Limit the number of displaying topologies */
  if (Cnotree < Numaltree) Numaltree = Cnotree;
  /* Store candidate topologies in odrder of ML */
  if ((fp = fopen("treefile", "w")) == NULL)
    fprintf(stderr,"%s: can't open %s\n", "treefile", "all_topo");
  if (Aprox_optn) {
    tablealtree_njml(Numaltree, fp);
  } else {
    tablealtree_njml2(Numaltree, fp);
  }
  fclose(fp);
  Numtree = Numaltree;
#if 0
  if (!Aprox_optn && Numtree > 1) {
#endif
  if (Numtree > 1) {
    if (Boots_optn && Verbs_optn) fputs(" bootstrap", stderr);
#if 0
    /* For test of Lklptrn */
    for (i = 0; i < Cnotree; i++)
      for (j = 0; j < Numptrn; j++)
	printf("%f\n", Lklptrn[i][j]);
#endif
    /* Record likelihood values, standard errors, and differences
       to the best */
    if ((std_err_fp = fopen("std_err", "a")) == NULL)
      fprintf(stderr,"%s: can't open %s\n", "std_err", "all_topo(n)");
    if (Boots_optn) bootstrap(Infotrees, Lklptrn);
    /*
    tabletree(Infotrees, Lklptrn);
    */
    tabletree2(Infotrees, Lklptrn, bs_for_best);
    /*
    tabletree3(Infotrees, Lklptrn, bs_for_best, std_err_fp);
    */
    fclose(std_err_fp);
    printf("Test: A bootstrap value for the best tree: %f\n", *bs_for_best);
    fprintf(Bs_for_bestfp,"%f\n", *bs_for_best);
    if (Info_optn) tableinfo(Infotrees);
  }
#ifdef LIGHT
  free_fmatrix(Lklptrn);
#else  /* LIGHT */
  free_dmatrix(Lklptrn);
#endif /* LIGHT */
}

void
helpinfo()
{
  printf("Not available now.\n"); 
}

void
usage()
{
  printf("Not available now.\n"); 
}
