/*
 * altree.c   Adachi, J.   1994.01.07
 * Copyright (C) 1992, 1993 J. Adachi & M. Hasegawa, All rights reserved.
 */

/* Modified by Satoshi OOta   May 9, 2000 */

#include "protml.h"

int get_bs(char **);
double get_distance(char **);
void remove_bs(cvector, cvector, int);
void get_open_par(char **, int *, int *, char **);
void get_distance2(char **, int *, int *, char **);
void get_bs2(char **, int *, int *, char **);
void get_others(char **, int *, int *, char **);
void set_strtree(char **cp, char **np);
void set_strtree2(char **, char **);
void get_strtree(int *, int *, char **);
void renumber(Tree *);
void autoconstruction_njml();

Tree *
new_atree(maxspc, maxibrnch, numptrn, seqconint)
int maxspc, maxibrnch, numptrn;
imatrix seqconint;
{
	int n, i;
	Tree *tr;
	Node *dp, *up;

	tr = (Tree *) malloc(sizeof(Tree));
	if (tr == NULL) maerror("tr in new_atree().");
	tr->ebrnchp  = (Node **) malloc((unsigned)maxspc * sizeof(Node *));
	if (tr->ebrnchp == NULL) maerror("ebrnchp in new_atree().");
	tr->ibrnchp  = (Node **) malloc((unsigned)maxibrnch * sizeof(Node *));
	if (tr->ibrnchp == NULL) maerror("ibrnchp in new_atree().");
	for (n = 0; n < maxspc; n++) {
		dp = (Node *) malloc(sizeof(Node));
		if (dp == NULL) maerror("dp in new_atree().");
		up = (Node *) malloc(sizeof(Node));
		if (up == NULL) maerror("up in new_atree().");
		dp->isop = NULL;
		up->isop = NULL;
		dp->kinp = up;
		up->kinp = dp;
		dp->descen = TRUE;
		up->descen = FALSE;
		dp->number = n;
		up->number = n;
		dp->length = 0.0;
		up->length = 0.0;
		dp->lklhdl = 0.0;
		up->lklhdl = 0.0;
		dp->paths = new_ivector(maxspc);
		up->paths = dp->paths;
		for (i = 0; i < maxspc; i++) dp->paths[i] = 0;
		dp->paths[n] = 1;
		dp->eprob = seqconint[n];
		dp->iprob = NULL;
		up->eprob = NULL;
		up->iprob = new_dmatrix(numptrn, Tpmradix);
		tr->ebrnchp[n] = dp;
	}
	tr->rootp = NULL;
	return tr;
} /*_ new_atree */


Node *
new_dnode()
{
	Node *dp;
	int i;

	dp = (Node *) malloc(sizeof(Node));
	if (dp == NULL) maerror("dp in new_dnode().");
	dp->isop = NULL;
	dp->kinp = NULL;
	dp->descen = TRUE;
	dp->number = Maxbrnch;
	dp->length = 0.0;
	dp->lklhdl = 0.0;
	dp->paths = new_ivector(Maxspc);
	for (i = 0; i < Maxspc; i++) dp->paths[i] = 0;
	dp->eprob = NULL;
	dp->iprob = new_dmatrix(Numptrn, Tpmradix);
	return dp;
} /*_ new_dnode */


Node *
new_anode()
{
	Node *ap;

	ap = (Node *) malloc(sizeof(Node));
	if (ap == NULL) maerror("ap in new_anode().");
	ap->isop = NULL;
	ap->kinp = NULL;
	ap->descen = FALSE;
	ap->number = Maxbrnch;
	ap->length = 0.0;
	ap->lklhdl = 0.0;
	ap->paths = NULL;
	ap->eprob = NULL;
	ap->iprob = new_dmatrix(Numptrn, Tpmradix);
	return ap;
} /*_ new_anode */


Node ***
new_nodematrix(nrow, ncol)
int nrow;
int ncol;
/* memory allocate a node matrix */
{
	int i;
	Node ***m;

	m = (Node ***) malloc((unsigned)nrow * sizeof(Node **));
	if (m == NULL) maerror("1 in nodematrix().");
	*m = (Node **) malloc((unsigned)(nrow * ncol) * sizeof(Node *));
	if (*m == NULL) maerror("2 in nodematrix().");
	for (i = 1; i < nrow; i++) m[i] = m[i-1] + ncol;
	return m;
}


void
free_nodematrix(m)
Node ***m;
{
	free((char *) *m);
	free((char *) m);
}


void 
aproxlkl(tr)
Tree *tr;
{
	int i, k;
	Node *cp, *rp;
	double sumlk, lklhd, log_sumlk;
	dmatrix prob1, prob2, prob3;

	cp = rp = tr->rootp;
	do {
		cp = cp->isop->kinp;
		if (cp->isop == NULL) { /* external node */
			cp = cp->kinp; /* not descen */
			partelkl(cp);
		} else { /* internal node */
			if (!cp->descen) {
				prodpart(cp->kinp->isop);
				partilkl(cp);
			}
		}
	} while (cp != rp);

	lklhd = 0.0;
	if (cp->isop->isop->isop == cp) { /* binary tree */
		prob1 = cp->iprob;
		prob2 = cp->isop->iprob;
		prob3 = cp->isop->isop->iprob;
		for (k = 0; k < Numptrn; k++) {
			sumlk = 0.0;
			for (i = 0; i < Tpmradix; i++)
				sumlk += Freqtpm[i] * prob1[k][i] * prob2[k][i] * prob3[k][i];
			log_sumlk = log(sumlk);
			Alklptrn[k] = log_sumlk; /* Likelihood at a site */
		/*	printf("%3d%23.20f%10.3f%4d\n", k,sumlk,log(sumlk),Weight[k]); */
			lklhd += log_sumlk * Weight[k];
		}
	} else { /* multiway tree */
		prodpart(cp->isop);
		prob1 = cp->iprob;
		prob2 = cp->isop->iprob;
		for (k = 0; k < Numptrn; k++) {
			sumlk = 0.0;
			for (i = 0; i < Tpmradix; i++)
				sumlk += Freqtpm[i] * prob1[k][i] * prob2[k][i];
		/*	printf("%3d%23.20f%10.3f%4d\n", k,sumlk,log(sumlk),Weight[k]); */
			lklhd += log(sumlk) * Weight[k];
		}
	}
	tr->lklhd = lklhd;
	return;
} /*_ aproxlkl */


void
praproxlkl(tr)
Tree *tr;
{
	printf("%.1f\t%.1f\t%d\t",tr->lklhd,tr->rssleast,Cnotree+1); /* offset */
} /*_ praproxlkl */


void
aproxtree(tr, ntr)
Tree *tr;
int ntr;
{
	double lkl, rss;
	Infoaltree *cp, *bp, *op;
	static double minrss, maxrss, sumrss;
	static long num;

	pathing(tr);
	lslength(tr, Distanvec, Numspc);
	rss = tr->rssleast;
	if (ntr < Numaltree || ntr < 105) {
		if (ntr == 0) {
				minrss = rss;
				maxrss = rss;
				sumrss = 0.0;
				num = 1;
		} else {
			if (rss < minrss)
				minrss = rss;
			if (rss > maxrss)
				maxrss = rss;
			sumrss += rss;
			num++;
		}
	} else {
		if (rss < minrss)
			minrss = rss;
		if (rss > maxrss)
			maxrss = rss;
		sumrss += rss;
		num++;
		if (rss > ((sumrss/num - minrss)*RSRATE + minrss))
			return;
#if 0
		printf("%.1f\t%.1f\t", minrss, sumrss/num);
#endif
	}
	aproxlkl(tr);
	if (Aprox_optn) praproxlkl(tr);
	if (Aprox_optn) putctopology(tr);
	lkl = tr->lklhd;
	if (ntr < Numaltree) {
		Infoaltrees[ntr].lklaprox = lkl;
		strctree(tr, Infoaltrees[ntr].ltplgy);
		op = &Infoaltrees[ntr];
		if (Info_optn) printf("%.1f\t%d\t%s\n", op->lklaprox, ntr, op->ltplgy);
		for (bp = &Atail, cp = bp->up; lkl > cp->lklaprox; bp = cp, cp = cp->up)
			;
		op->up = cp;
		bp->up = op;
	} else if (lkl > Atail.up->lklaprox) {
		op = Atail.up;
		Atail.up = op->up;
		op->lklaprox = lkl;
		op->rss = rss;
		strctree(tr, op->ltplgy);
		if (Info_optn) printf("%.1f\t%d\t%s\n", op->lklaprox, ntr, op->ltplgy);
		for (bp = &Atail, cp = bp->up; lkl > cp->lklaprox; bp = cp, cp = cp->up)
			;
		op->up = cp;
		bp->up = op;
	}
/*	if (ntr % 10000 == 0) putctopology(tr); */
} /*_ aproxtree */

void exact_njml(tr, ntr, buftree)
Tree *tr;
int ntr;
int buftree;
{
        int i, j;
	double lkl, rss;
	Infoaltree *cp, *bp, *op;
	static double minrss, maxrss, sumrss;
	static long num;
	Node *rp;
	cvector strbstree;
	boolean tmp_aprox_optn=TRUE;

	pathing(tr);
	if(lslength(tr, Distanvec, Maxspc))
	  tmp_aprox_optn = 0;
	rss = tr->rssleast;
	if (ntr < Numaltree || ntr < 105) {
		if (ntr == 0) {
				minrss = rss;
				maxrss = rss;
				sumrss = 0.0;
				num = 1;
		} else {
			if (rss < minrss)
				minrss = rss;
			if (rss > maxrss)
				maxrss = rss;
			sumrss += rss;
			num++;
		}
	} else {
		if (rss < minrss)
			minrss = rss;
		if (rss > maxrss)
			maxrss = rss;
		sumrss += rss;
		num++;
		if (rss > ((sumrss/num - minrss)*RSRATE + minrss))
			return;
#if 0
		printf("%.1f\t%.1f\t", minrss, sumrss/num);
#endif
	}
	/*
	Infotrees = (Infotree *) newinfotrees(Numtree, buftree);
	*/
#ifdef NUC
	if (Toptim_optn && Cnotree == 0) optimtpm();
#endif /* NUC */
	if (Aprox_optn && tmp_aprox_optn) {
	  aproxlkl(tr);
	  praproxlkl(tr);
	  putctopology(tr);
	  mlvalue(tr, rp, Infotrees);
	} else {
	  /*
	  print_ibranch_number(tr);
	  */
	  renumber(tr);
	  /*
	  printf("%s\n", fputcphylogeny2(tr));
	  */
	  if (!Ctacit_optn) printf("#%d\n", Cnotree + 1);
	  /* Compute reliability on each branch */ 
	  if (Relia_optn) {
	    Epsilon = REPSILON;
	    reliabranch(tr);
	    Epsilon = EPSILON;
	  } else {
	    initpartlkl(tr);
	    rp = (Node *)mlikelihood_njml(tr);
	    mlvalue(tr, rp, Infotrees);
	  }
	  /*
	  printf("tr->lklhd = %f\n", tr->lklhd); 
	  printf("Converg = %d\n", Converg); 
	  */
	  prtopology(tr);
#ifdef BDATE
	  branchdate(tr);
#endif /* BDATE */
#ifdef PTNLKL
	  patternlklhd(tr);
#endif /* PTNLKL */
	  tmp_aprox_optn = TRUE;
	}
	lkl = tr->lklhd;
	if (ntr < Numaltree) {
	  Infoaltrees[ntr].lklaprox = lkl;  /* In the exact likelihood mode,
					       lklaprox will have an exact
					       likelihood value */
	  Infoaltrees[ntr].varilkl = tr->varilkl;
	  strctree(tr, Infoaltrees[ntr].ltplgy);
	  op = &Infoaltrees[ntr];
	  if (Info_optn) printf("%.1f\t%d\t%s\n", op->lklaprox, ntr, op->ltplgy);
	  for (bp = &Atail, cp = bp->up; lkl > cp->lklaprox; bp = cp, cp = cp->up)
	    ;
	  op->up = cp;
	  bp->up = op;
	} else if (lkl > Atail.up->lklaprox) {
	  op = Atail.up;
	  Atail.up = op->up;
	  op->lklaprox = lkl;
	  op->rss = rss;
	  strctree(tr, op->ltplgy);
	  if (Info_optn) printf("%.1f\t%d\t%s\n", op->lklaprox, ntr, op->ltplgy);
	  for (bp = &Atail, cp = bp->up; lkl > cp->lklaprox; bp = cp, cp = cp->up)
	    ;
	  op->up = cp;
	  bp->up = op;
	}

	/*	if (ntr % 10000 == 0) putctopology(tr); */
} /*_ exact_njml */


void autoconstruction();

void 
wedge(tr, onode, poolnode, addposition, poolorder, op)
Tree *tr;
int onode;
Node **poolnode, **addposition;
ivector poolorder;
Node *op;
{
	Node *cp, *dp;
	int i, istart;
	/* Set current node */
	cp = poolnode[onode];
	if (addposition[onode] != NULL) { /* internal node */
		if (cp->isop != NULL) { /* binary tree */
			dp = op->kinp;
			op->kinp = cp->isop;
			cp->isop->kinp = op;
			dp->kinp = cp->isop->isop;
			cp->isop->isop->kinp = dp;
			op->paths = cp->isop->paths;
			cp->isop->isop->paths = dp->paths;
			for (istart = onode + 1; istart < Numspc; istart++) {
				if (poolorder[onode] != poolorder[istart])
					break;
			}
			for (i = istart; i < Numspc; i++) {
				if (op == addposition[i])
					addposition[i] = dp->kinp;
			}
		} else { /* multiway tree */
			cp->isop = op->isop;
			op->isop = cp;
			dp = op->kinp;
		}
	} else { /* root */
		dp = cp->isop->kinp;
		if (op == tr->rootp)
			tr->rootp = dp;
		dp->isop = op->isop;
		op->isop->isop->isop = dp;
		op->isop = cp;
		cp->isop->isop = op;
	}
	if (onode < Numspc - 1) {
/*		printf("%3d%3d%3d%3d ",
			onode,dp->number,cp->kinp->number,cp->isop->number);
		putctopology(tr); */
		if (addposition[onode + 1] == NULL)
			autoconstruction(tr, onode + 1, poolnode, addposition, poolorder);
		else
			wedge(tr, onode+1, poolnode, addposition, poolorder, addposition[onode+1]);
	} else if (onode = Numspc - 1) {
	/*	Numibrnch = Maxibrnch;
		Numbrnch = Maxbrnch; */
		aproxtree(tr, Cnotree);
		Cnotree++;
	}
	if (addposition[onode] != NULL) { /* internal node */
		if (op->isop != cp) { /* binary tree */
			for (i = istart; i < Numspc; i++) {
				if (dp->kinp == addposition[i])
					addposition[i] = op;
			}
			cp->isop->kinp = NULL;
			cp->isop->isop->kinp = NULL;
			op->kinp = dp;
			dp->kinp = op;
			op->paths = dp->paths;
		} else { /* multiway tree */
			op->isop = cp->isop;
			cp->isop = NULL;
		}
	} else { /* root */
		if (dp == tr->rootp)
			tr->rootp = op;
		dp->isop->isop->isop = op;
		op->isop = dp->isop;
		cp->isop->isop = cp;
		dp->isop = NULL;
	}
	if (op->kinp->isop == NULL) {
		return;
	} else {
		cp = op->kinp->isop;
		while (cp != op->kinp) {
			wedge(tr, onode, poolnode, addposition, poolorder,  cp);
			cp = cp->isop;
		}
	}
} /*_ wedge */

void 
wedge_njml(tr, onode, poolnode, addposition, poolorder, op, buftree)
Tree *tr;
int onode;
Node **poolnode, **addposition;
ivector poolorder;
Node *op;
int buftree;
{
  Node *cp, *dp;
  int i, istart;
  FILE *finalfp;

  /* Set current node */
  cp = poolnode[onode];
  if (addposition[onode] != NULL) { /* internal node */
    if (cp->isop != NULL) { /* binary tree */
      /* Insert cp (an internal branch) between nodes cp and dp */
      dp = op->kinp;
      op->kinp = cp->isop;
      cp->isop->kinp = op;
      dp->kinp = cp->isop->isop;
      cp->isop->isop->kinp = dp;
      op->paths = cp->isop->paths;
      cp->isop->isop->paths = dp->paths;
      for (istart = onode + 1; istart < Numspc; istart++) {
	if (poolorder[onode] != poolorder[istart])
	  break;
      }
      for (i = istart; i < Numspc; i++) {
	if (op == addposition[i])
	  addposition[i] = dp->kinp;
      }
    } else { /* multiway tree */
      /* Make a multifurcating node */
      cp->isop = op->isop;
      op->isop = cp;
      dp = op->kinp;
    }
  } else { /* root */
    /* Make a multifurcating node */
    dp = cp->isop->kinp;
    if (op == tr->rootp)
      tr->rootp = dp;
    dp->isop = op->isop;
    op->isop->isop->isop = dp;
    op->isop = cp;
    cp->isop->isop = op;
  }
  if (onode < Numspc - 1) {
    /*		printf("%3d%3d%3d%3d ",
		onode,dp->number,cp->kinp->number,cp->isop->number);
		putctopology(tr); */
    if (addposition[onode + 1] == NULL)
      /* No more adding point here; move the other node */
      autoconstruction_njml(tr, onode + 1, poolnode, addposition, poolorder, buftree);
    else
      wedge_njml(tr, onode+1, poolnode, addposition, poolorder, addposition[onode+1], buftree);
  } else if (onode = Numspc - 1) {
    /*	Numibrnch = Maxibrnch;
	Numbrnch = Maxbrnch; */
    Alklptrn = Lklptrn[Cnotree];
    exact_njml(tr, Cnotree, buftree);

    if ((finalfp = fopen("finaltree", "w")) == NULL)
      fprintf(stderr,"%s: can't open %s\n", "wedge_njml", "finaltree");    
#if 1 /* Make bootstrap tree */
    setbs2("bstree", tr, buftree);
#endif
    fputcphylogeny(finalfp, tr);
    fclose(finalfp);
#if 1
    putchar('\n');
    puts("Tree with lengths and bootstrap values"); 
    puts((char *)fputcphylogeny3(tr));
    putchar('\n');
#endif
    strcpy(Infotrees[Cnotree].tree_phb, (char *)fputcphylogeny3(tr));
#if 0 /* For internal branch reliability (under construction) */
    if ((finalfp = fopen("finaltree3", "w")) == NULL)
      fprintf(stderr,"%s: can't open %s\n", "wedge_njml", "finaltree");    
    fputcphylogeny4(finalfp, tr);
    fclose(finalfp);
#endif
    Cnotree++;
  }
  if (addposition[onode] != NULL) { /* internal node */
    if (op->isop != cp) { /* binary tree */
      for (i = istart; i < Numspc; i++) {
	if (dp->kinp == addposition[i])
	  addposition[i] = op;
      }
      cp->isop->kinp = NULL;
      cp->isop->isop->kinp = NULL;
      op->kinp = dp;
      dp->kinp = op;
      op->paths = dp->paths;
    } else { /* multiway tree */
      op->isop = cp->isop;
      cp->isop = NULL;
    }
  } else { /* root */
    if (dp == tr->rootp)
      tr->rootp = op;
    dp->isop->isop->isop = op;
    op->isop = dp->isop;
    cp->isop->isop = cp;
    dp->isop = NULL;
  }
  if (op->kinp->isop == NULL) {
    return;
  } else {
    cp = op->kinp->isop;
    while (cp != op->kinp) {
      wedge_njml(tr, onode, poolnode, addposition, poolorder,  cp, buftree);
      cp = cp->isop;
    }
  }
} /*_ wedge_njml */



void 
autoconstruction(tr, onode, poolnode, addposition, poolorder)
Tree *tr;
int onode;
Node **poolnode, **addposition;
ivector poolorder;
{
	Node *cp;

	cp = tr->rootp;
	do {
		cp = cp->isop;
		wedge(tr, onode, poolnode, addposition, poolorder, cp);
	} while (cp != tr->rootp);} /*_ autoconstruction */

void autoconstruction_njml(tr, onode, poolnode, addposition, poolorder, buftree)
Tree *tr;
int onode;
Node **poolnode, **addposition;
ivector poolorder;
int buftree;
{
	Node *cp;

	cp = tr->rootp;
	do {
		cp = cp->isop;
		wedge_njml(tr, onode, poolnode, addposition, poolorder, cp, buftree);
	} while (cp != tr->rootp);
} /*_ autoconstruction_njml */



Node *
inbranode(tr, chpp, nenode, numorder, poolnode2)
Tree *tr;
char **chpp;
int *nenode;
int numorder;
Node ***poolnode2;
{
	Node *xp, *yp, *np;
	int i, j, n, dvg;
	char ident[MAXWORD];
	char *idp;

	numorder++;
	(*chpp)++;
	if (**chpp == '{') { /* internal node of binary tree */
		if (Debug) printf("inbranode: %c\n", **chpp);
		xp = inbranode(tr, chpp, nenode, numorder, poolnode2); /* first node */
		dvg = 0;
		for (n = 0; poolnode2[numorder][n] != NULL; n++)
			;
		while (**chpp != '}') { /* second node and others */
			if (**chpp == '\0') {
				fputs("ERROR constrained tree, in internalnode 1\n", stderr);
				fputs(*chpp, stderr); fputc('\n', stderr);
				exit(1);
			}
			np = inbranode(tr, chpp, nenode, numorder, poolnode2);
			np->isop = new_dnode(); /* New descendant node */
			np->isop->isop = new_anode(); /* New ancestoral node */
			np->isop->isop->isop = np; /* Close a node */
			poolnode2[numorder][n + dvg] = np; /* Set poolnode */
			np->isop->kinp = xp; /* add position */
			dvg++;
		}
		poolnode2[numorder][n + dvg] = NULL; /* Indicate the
							end of poolnode */
		(*chpp)++;
		if (dvg < 1) {
			fputs("ERROR constrained tree, in internalnode 2\n", stderr);
			fputs(*chpp, stderr); fputc('\n', stderr);
			exit(1);
		}
		(*nenode)++;
		return xp;
	} else if  (**chpp == '(') { /* internal node of multiway tree */
		xp = inbranode(tr, chpp, nenode, numorder, poolnode2); /* first node */
		dvg = 0;
		for (n = 0; poolnode2[numorder][n] != NULL; n++)
			;
		if (**chpp != ')') { /* second node */
			if (**chpp == '\0') {
				fputs("ERROR constrained tree, in internalnode 3\n", stderr);
				fputs(*chpp, stderr); fputc('\n', stderr);
				exit(1);
			}
			np = inbranode(tr, chpp, nenode, numorder, poolnode2);
			np->isop = new_dnode();
			np->isop->isop = new_anode();
			np->isop->isop->isop = np;
			poolnode2[numorder][n + dvg] = np;
			np->isop->kinp = xp; /* add position */
			dvg++;
		}
		while (**chpp != ')') { /* third node and others */
			if (**chpp == '\0') {
				fputs("ERROR constrained tree, in internalnode 4\n", stderr);
				fputs(*chpp, stderr); fputc('\n', stderr);
				exit(1);
			}
			yp = np;
			np = inbranode(tr, chpp, nenode, numorder, poolnode2);
			np->isop = NULL;
			poolnode2[numorder][n + dvg] = np;
			np->kinp->isop = yp; /* add position (kinp) */
			dvg++;
		}
		poolnode2[numorder][n + dvg] = NULL;
		(*chpp)++;
		if (dvg < 1) {
			fputs("ERROR constrained tree, in internalnode 5\n", stderr);
			fputs(*chpp, stderr); fputc('\n', stderr);
			exit(1);
		}
		(*nenode)++;
		return xp;

	} else if (isalnum(**chpp)) { /* external node */
		if (Debug) printf("internal: %c\n", **chpp);
		for (idp = ident;
			**chpp != ',' && **chpp != '}' && **chpp != ')' && **chpp != '\0';
			(*chpp)++) {
			*idp++ = **chpp;
			if (Debug) putchar(**chpp);
		}
		*idp = '\0';
		if (Debug) putchar('\n');
		for (i = 0; i < Numspc; i++) {
			/* puts(Identif[i]); */
			if (!strcmp(ident, Identif[i])) {
				for (j = 0; j < Numspc; j++)
					tr->ebrnchp[i]->paths[j] = 0;
				tr->ebrnchp[i]->paths[i] = 1;
				if (Debug) {
					for (j = 0; j < Numspc; j++)
						printf("%2d",tr->ebrnchp[i]->paths[j]);
					putchar('\n');
				}
				return tr->ebrnchp[i]->kinp;
			}
		}
		fputs("ERROR constrained tree, in internalnode 6\n", stderr);
		fputs(*chpp, stderr); fputc('\n', stderr);
		fputs(ident, stderr); fputc('\n', stderr);
		exit(1);
	} else {
		fputs("ERROR constrained tree, in internalnode 7\n", stderr);
		fputs(*chpp, stderr); fputc('\n', stderr);
		exit(1);
	}
	return NULL;
} /*_ inbranode */


Node *
inbranode_njml(tr, chpp, nenode, numorder, poolnode2, max_del_num)
Tree *tr;
char **chpp;
int *nenode;
int numorder;
Node ***poolnode2;
int *max_del_num;
{
  Node *xp, *yp, *np;
  int i, j, n, dvg;
  char ident[MAXWORD];
  char *idp;
  
  numorder++; /* Depth of the tree */
  (*chpp)++;
  if (**chpp == '(') { /* internal node of binary tree */
    if (Debug) printf("inbranode_njml: %c\n", **chpp);
    xp = inbranode_njml(tr, chpp, nenode, numorder, poolnode2, max_del_num); /* first node */
    dvg = 0;
    for (n = 0; poolnode2[numorder][n] != NULL; n++)
      ;
    if (dvg >= (*max_del_num + 1)) {
      if (**chpp != ')') { /* second node */
	if (**chpp == '\0') {
	  fputs("ERROR constrained tree, in internalnode 3\n", stderr);
	  fputs(*chpp, stderr); fputc('\n', stderr);
	  exit(1);
	}
	np = inbranode_njml(tr, chpp, nenode, numorder, poolnode2, max_del_num);
	np->isop = new_dnode();
	np->isop->isop = new_anode();
	np->isop->isop->isop = np;
	poolnode2[numorder][n + dvg] = np;
	np->isop->kinp = xp; /* add position */
	dvg++;
      }
    }
    while (**chpp != ')') { /* second node and others */
      if (**chpp == '\0') {
	fputs("ERROR constrained tree, in internalnode 1\n", stderr);
	fputs(*chpp, stderr); fputc('\n', stderr);
	exit(1);
      }
      if (dvg >= (*max_del_num + 1)) {
	if (**chpp == '\0') {
	  fputs("ERROR constrained tree, in internalnode 4\n", stderr);
	  fputs(*chpp, stderr); fputc('\n', stderr);
	  exit(1);
	}
	yp = np;
	np = inbranode_njml(tr, chpp, nenode, numorder, poolnode2, max_del_num);
	np->isop = NULL;
	poolnode2[numorder][n + dvg] = np;
	np->kinp->isop = yp; /* add position (kinp) */
	dvg++;
      } else {
	np = inbranode_njml(tr, chpp, nenode, numorder, poolnode2, max_del_num);
	np->isop = new_dnode(); /* New descendant node */
	np->isop->isop = new_anode(); /* New ancestoral node */
	np->isop->isop->isop = np; /* Close a node */
	poolnode2[numorder][n + dvg] = np; /* Set poolnode */
	np->isop->kinp = xp; /* add position */
	dvg++;
      }	
    }
    *max_del_num = *max_del_num - dvg;
    (*chpp)++;
    /* Get bootstrap value */
    if (isalnum(**chpp)) {
      get_bs(chpp);
      get_distance(chpp);
    }
    /*
    printf("%s\n", *chpp);
    */
    
    poolnode2[numorder][n + dvg] = NULL; /* Indicate the
					    end of poolnode */
    if (dvg < 1) {
      fputs("ERROR constrained tree, in internalnode 2\n", stderr);
      fputs(*chpp, stderr); fputc('\n', stderr);
      exit(1);
    }
    (*nenode)++;
    return xp;
  } else if (isalnum(**chpp)) { /* external node */
    if (Debug) printf("internal: %c\n", **chpp);
    for (idp = ident;
	 **chpp != ',' && **chpp != '}' && **chpp != ')' && **chpp != ':' 
	   && **chpp != '\0';
	 (*chpp)++) {
      *idp++ = **chpp;
      if (Debug) putchar(**chpp);
    }
    *idp = '\0';
    /* Get bootstrap value */
    if (**chpp == ':')
      get_distance(chpp);
    if (Debug) putchar('\n');
    for (i = 0; i < Numspc; i++) {
      /* puts(Identif[i]); */
      if (!strcmp(ident, Identif[i])) {
	for (j = 0; j < Numspc; j++)
	  tr->ebrnchp[i]->paths[j] = 0;
	tr->ebrnchp[i]->paths[i] = 1;
	if (Debug) {
	  for (j = 0; j < Numspc; j++)
	    printf("%2d",tr->ebrnchp[i]->paths[j]);
	  putchar('\n');
	}
	return tr->ebrnchp[i]->kinp;
      }
    }
    fputs("ERROR constrained tree, in internalnode 6\n", stderr);
    fputs(*chpp, stderr); fputc('\n', stderr);
    fputs(ident, stderr); fputc('\n', stderr);
    exit(1);
  } else {
    fputs("ERROR constrained tree, in internalnode 7\n", stderr);
    fputs(*chpp, stderr); fputc('\n', stderr);
    exit(1);
  }
  return NULL;
} /*_ inbranode_njml */


void
streeinit(tr, strtree, poolnode, addposition, poolorder)
Tree *tr;
cvector strtree;
Node **poolnode, **addposition;
ivector poolorder;
{
	char *chp;
	int i, j, k, nenode, ninode, dvg;
	int numorder;
	Node *sp0, *sp1, *sp2, *np;
	Node ***poolnode2;

	poolnode2 = new_nodematrix(Numspc, Numspc);
	nenode = 0;
	numorder = 0;
	/* Initialize poolnodes */
	for (i = 0; i < Numspc; i++) {
		poolnode2[i][0] = NULL;
		poolnode[i] = NULL;
		addposition[i] = NULL;
		poolorder[i] = 0;
	}

	/* Start to read strtree */
	chp = strtree;
	if (*chp == '{') { /* binary */
		sp0 = inbranode(tr, &chp, &nenode, numorder, poolnode2);
		sp1 = inbranode(tr, &chp, &nenode, numorder, poolnode2);
		sp2 = inbranode(tr, &chp, &nenode, numorder, poolnode2);
		sp0->isop = sp1;
		sp1->isop = sp2;
		sp2->isop = sp0;
		tr->rootp = sp2;
		dvg = 0;
		while (*chp != '}') { /* fourth node and others */
			np = inbranode(tr, &chp, &nenode, numorder, poolnode2);
			np->isop = new_dnode();
			np->isop->kinp = new_anode();
			np->isop->kinp->paths = np->isop->paths;
			np->isop->isop = np;
			np->isop->kinp->kinp = np->isop;
			poolnode2[0][dvg] = np;
			dvg++;
		}
		poolnode2[0][dvg] = NULL;
	} else if (*chp == '(') { /* multiway */
		sp0 = inbranode(tr, &chp, &nenode, numorder, poolnode2);
		sp1 = inbranode(tr, &chp, &nenode, numorder, poolnode2);
		sp2 = inbranode(tr, &chp, &nenode, numorder, poolnode2);
		/* Make a center of a tree */
		sp0->isop = sp1;
		sp1->isop = sp2;
		sp2->isop = sp0;
		tr->rootp = sp2;
		dvg = 0;
		while (*chp != ')') { /* fourth node and others */
			np = inbranode(tr, &chp, &nenode, numorder, poolnode2);
			np->isop = NULL;
			poolnode2[0][dvg] = np;
			np->kinp->isop = sp2; /* add position (kinp) */
			dvg++;
		}
		poolnode2[0][dvg] = NULL;
	} else {
		fputs("ERROR constrained tree, in streeinit\n", stderr);
		fputs(strtree, stderr); fputc('\n', stderr);
		exit(1);
	}
	if (Debug_optn) {
		putchar('\n');
		printf("    %4d%4d%4d\n", sp0->number, sp1->number, sp2->number);
		for (i = 0; i < Numspc; i++) {
			printf("%4d", i);
			if (poolnode2[i][0] != NULL) {
				for (j = 0; j < Numspc; j++) {
					if (poolnode2[i][j] != NULL)
						printf("%4d", poolnode2[i][j]->number);
					else
						break;
				} putchar('\n');
			} else {
				printf(" nul\n");
			}
		}
	}

	poolnode[0] = sp0;
	poolnode[1] = sp1;
	poolnode[2] = sp2;
	addposition[0] = NULL;
	addposition[1] = NULL;
	addposition[2] = NULL;
	for (k = 3, ninode = 0, i = 0; i < Numspc; i++) {
		for (j = 0; j < Numspc && poolnode2[i][j] != NULL; j++) {
			poolorder[k] = i;
			poolnode[k] = poolnode2[i][j];
			if (poolnode[k]->isop != NULL) { /* binary tree '(' */
				poolnode[k]->isop->number = ninode;
				if (i == 0) { /* root */
					addposition[k] = NULL;
				} else { /* not root */
					addposition[k] = poolnode[k]->isop->kinp;
					poolnode[k]->isop->kinp = NULL;
				}
				tr->ibrnchp[ninode] = poolnode[k]->isop;
				ninode++;
			} else { /* multiway tree '{' */
				addposition[k] = poolnode[k]->kinp->isop;
				poolnode[k]->kinp->isop = NULL;
			}
			k++;
		}
	}
	Numibrnch = ninode;
	Numbrnch = Numspc + ninode;

	if (Debug_optn) {
		putchar('\n');
		for (i = 0; i < k; i++) {
			printf("%4d ", i);
			fputid(stdout, Identif[poolnode[i]->kinp->number], 10);
			printf("%4d", poolnode[i]->kinp->number);
			printf("%4d", poolnode[i]->number);
			if (addposition[i] != NULL) {
				printf("%4d", addposition[i]->kinp->number);
				printf("%4d", addposition[i]->number);
			} else {
				fputs(" nul", stdout);
				fputs(" nul", stdout);
			}
			printf(" %4d ", poolorder[i]);
			if (poolnode[i]->isop != NULL) {
				np = poolnode[i];
				while((np = np->isop) != poolnode[i]) {
					printf("%4d", np->number);
				}
			} putchar('\n');
		}
		printf("Numbrnch =%4d\n", Numbrnch);
		printf("Numibrnch =%4d\n", Numibrnch);
	}
	free_nodematrix(poolnode2);
} /*_ streeinit */

/* Prepare internal nodes and branches */
void
streeinit_njml(tr, strtree, poolnode, addposition, poolorder, max_del_num)
     Tree *tr;
     cvector strtree;
     Node **poolnode, **addposition;
     ivector poolorder;
     int *max_del_num;
{
  char *chp;
  int i, j, k, nenode, ninode, dvg;
  int numorder;
  Node *sp0, *sp1, *sp2, *np;
  Node ***poolnode2;

  poolnode2 = new_nodematrix(Numspc, Numspc);
  /* poolnode2 is a node matrix */
  nenode = 0;
  numorder = 0;
  /* Initialize poolnodes */
  for (i = 0; i < Numspc; i++) {
    poolnode2[i][0] = NULL;
    poolnode[i] = NULL;
    addposition[i] = NULL;
    poolorder[i] = 0;
  }
  
  /* Start to read strtree */
  chp = strtree;
  if (*chp == '(') { /* binary */
    sp0 = inbranode_njml(tr, &chp, &nenode, numorder, poolnode2, max_del_num);
    sp1 = inbranode_njml(tr, &chp, &nenode, numorder, poolnode2, max_del_num);
    sp2 = inbranode_njml(tr, &chp, &nenode, numorder, poolnode2, max_del_num);
    /* Connect three subtrees */
    sp0->isop = sp1;
    sp1->isop = sp2;
    sp2->isop = sp0;
    tr->rootp = sp2;
    /* Pool the fourth node and others */
    dvg = 0;
    while (*chp != ')') { /* fourth node and others */
      if (dvg >= *max_del_num) {
	np = inbranode_njml(tr, &chp, &nenode, numorder, poolnode2, max_del_num);
	np->isop = NULL;
	poolnode2[0][dvg] = np;
	np->kinp->isop = sp2; /* add position (kinp) */
      } else {
	np = inbranode_njml(tr, &chp, &nenode, numorder, poolnode2, max_del_num);
	np->isop = new_dnode(); /* New descendant node */
	np->isop->kinp = new_anode(); /* New ancestral node */
	np->isop->kinp->paths = np->isop->paths;
	np->isop->isop = np; /* Close the nodes */
	np->isop->kinp->kinp = np->isop;
	/* Pool an internal node (internal branch) */
	poolnode2[0][dvg] = np;
      }
      dvg++;
    }
    *max_del_num = *max_del_num - dvg;
    /* Set the end of poolnode matrix */
    poolnode2[0][dvg] = NULL; /* 0 indicates root */
  } else {
    fputs("ERROR constrained tree, in streeinit_njml\n", stderr);
    fputs(strtree, stderr); fputc('\n', stderr);
    exit(1);
  }
  if (Debug_optn) {
    putchar('\n');
    printf("    %4d%4d%4d\n", sp0->number, sp1->number, sp2->number);
    for (i = 0; i < Numspc; i++) {
      printf("%4d", i);
      /* The first one is null? */
      if (poolnode2[i][0] != NULL) {
	for (j = 0; j < Numspc; j++) {
	  if (poolnode2[i][j] != NULL)
	    printf("%4d", poolnode2[i][j]->number);
	  else
	    break;
	} putchar('\n');
      } else {
	printf(" nul\n");
      }
    }
  }
  
  /* Pool the first, send, and third nodes */ 
  poolnode[0] = sp0;
  poolnode[1] = sp1;
  poolnode[2] = sp2;
  /* The first three nodes should have no adding point */
  addposition[0] = NULL;
  addposition[1] = NULL;
  addposition[2] = NULL;
  /* k: The number of internal nodes */
  for (k = 3, ninode = 0, i = 0; i < Numspc; i++) {
    for (j = 0; j < Numspc && poolnode2[i][j] != NULL; j++) {
      poolorder[k] = i;
      /* Pool the fourth and later nodes */
      poolnode[k] = poolnode2[i][j];
      /* Insert internal branches */
      if (poolnode[k]->isop != NULL) { /* binary tree '(' */
	poolnode[k]->isop->number = ninode;
	if (i == 0) { /* root */
	  /* For root no adding position */
	  addposition[k] = NULL;
	} else { /* not root */
	  addposition[k] = poolnode[k]->isop->kinp;
	  poolnode[k]->isop->kinp = NULL;
	}
	tr->ibrnchp[ninode] = poolnode[k]->isop;
	ninode++;
      } else { /* multiway tree '{' */
	/* There is no internal branch in this case */
	addposition[k] = poolnode[k]->kinp->isop;
	poolnode[k]->kinp->isop = NULL;
      }
      k++;
    }
  }
  Numibrnch = ninode;
  Numbrnch = Numspc + ninode;
  
  if (Debug_optn) {
    putchar('\n');
    for (i = 0; i < k; i++) {
      printf("%4d ", i);
      fputid(stdout, Identif[poolnode[i]->kinp->number], 10);
      printf("%4d", poolnode[i]->kinp->number);
      printf("%4d", poolnode[i]->number);
      if (addposition[i] != NULL) {
	printf("%4d", addposition[i]->kinp->number);
	printf("%4d", addposition[i]->number);
      } else {
	fputs(" nul", stdout);
	fputs(" nul", stdout);
      }
      printf(" %4d ", poolorder[i]);
      if (poolnode[i]->isop != NULL) {
	np = poolnode[i];
	while((np = np->isop) != poolnode[i]) {
	  printf("%4d", np->number);
	}
      } putchar('\n');
    }
    printf("Numbrnch =%4d\n", Numbrnch);
    printf("Numibrnch =%4d\n", Numibrnch);
  }
  free_nodematrix(poolnode2); /* The node matrix is no longer used */
} /*_ streeinit_njml */


void
atreeinit(tr, poolnode, addposition, poolorder)
Tree *tr;
Node **poolnode, **addposition;
ivector poolorder;
{
	char *chp;
	char linebuf[BUFLINE];
	int i, j, k, nenode, ninode, dvg, numorder, mini;
	double dis, mindis;
	Node *sp0, *sp1, *sp2, *np;
	Node ***poolnode2;

	mindis = fabs(Distanmat[0][1] - Distanmat[Numspc-1][1]);
	mini = 1;
	for ( i = 2; i < Numspc - 1; i++) {
		dis = fabs(Distanmat[0][i] - Distanmat[Numspc-1][i]);
		if (dis < mindis) {
			mindis = dis;
			mini = i;
		}
	}

	poolnode2 = new_nodematrix(Numspc, Numspc);
	nenode = 0;
	numorder = 0;
	for (i = 0; i < Numspc; i++) {
		poolnode2[i][0] = NULL;
		poolnode[i] = NULL;
		addposition[i] = NULL;
		poolorder[i] = 0;
	}

	linebuf[0] = ',';
	strcpy(linebuf+1, Identif[0]);
	chp = linebuf;
	sp0 = inbranode(tr, &chp, &nenode, numorder, poolnode2);
	strcpy(linebuf+1, Identif[mini]);
	chp = linebuf;
	sp1 = inbranode(tr, &chp, &nenode, numorder, poolnode2);
	strcpy(linebuf+1, Identif[Numspc-1]);
	chp = linebuf;
	sp2 = inbranode(tr, &chp, &nenode, numorder, poolnode2);
	sp0->isop = sp1;
	sp1->isop = sp2;
	sp2->isop = sp0;
	tr->rootp = sp2;
	dvg = 0;
	for ( i = 1; i < Numspc - 1; i++) {
		if (i != mini) {
			strcpy(linebuf+1, Identif[i]);
			chp = linebuf;
			np = inbranode(tr, &chp, &nenode, numorder, poolnode2);
			np->isop = new_dnode();
			np->isop->kinp = new_anode();
			np->isop->kinp->paths = np->isop->paths;
			np->isop->isop = np;
			np->isop->kinp->kinp = np->isop;
			poolnode2[0][dvg] = np;
			dvg++;
		}
	}
	poolnode2[0][dvg] = NULL;

	if (Debug_optn) {
		putchar('\n');
		printf("%4d%4d%4d\n", sp0->number, sp1->number, sp2->number);
		for (j = 0; j < Numspc && poolnode2[0][j] != NULL; j++)
			printf("%4d", poolnode2[0][j]->number);
		putchar('\n');
	}

	poolnode[0] = sp0;
	poolnode[1] = sp1;
	poolnode[2] = sp2;
	addposition[0] = NULL;
	addposition[1] = NULL;
	addposition[2] = NULL;
	k = 3;
	ninode = 0;
	for (j = 0; j < Numspc && poolnode2[0][j] != NULL; j++) {
		poolorder[k] = 0;
		poolnode[k] = poolnode2[0][j];
		poolnode[k]->isop->number = ninode;
		addposition[k] = NULL;
		tr->ibrnchp[ninode] = poolnode[k]->isop;
		ninode++;
		k++;
	}
	Numbrnch = ninode;

	if (Debug_optn) {
		putchar('\n');
		for (i = 0; i < k; i++) {
			printf("%4d ", i);
			fputid(stdout, Identif[poolnode[i]->kinp->number], 10);
			printf("%4d", poolnode[i]->kinp->number);
			printf("%4d", poolnode[i]->number);
			if (addposition[i] != NULL) {
				printf("%4d", addposition[i]->kinp->number);
				printf("%4d", addposition[i]->number);
			} else {
				fputs(" nul", stdout);
				fputs(" nul", stdout);
			}
			printf(" %4d ", poolorder[i]);
			if (poolnode[i]->isop != NULL) {
				np = poolnode[i];
				while((np = np->isop) != poolnode[i]) {
					printf("%4d", np->number);
				}
			} putchar('\n');
		}
		printf("Numbrnch =%4d\n", Numbrnch);
	}
	free_nodematrix(poolnode2);
} /*_ atreeinit */


void
tablealtree(numaltree)
int numaltree;
{
	Infoaltree *cp, **info;
	int i;

	info = (Infoaltree **)malloc((unsigned)numaltree * sizeof(Infoaltree *));
	if (info == NULL) maerror("in tablealtree().");
	for (cp = Atail.up, i = numaltree; cp != &Ahead; cp = cp->up) {
		info[--i] = cp;
	/*	printf("%.1f %s\n", cp->lklaprox, cp->ltplgy); */
	}
	printf("%d / %d \"%s\"", numaltree, Cnotree, Modelname);
	printf(" approx ln L %.1f", info[0]->lklaprox);
	printf(" ... %.1f", info[numaltree-1]->lklaprox);
	printf(" diff %.1f\n", info[0]->lklaprox - info[numaltree-1]->lklaprox);
	for (i = 0; i < numaltree; i++) {
	  if (Info_optn ) printf("%.1f ", info[i]->lklaprox);
	  fputs(info[i]->ltplgy, stdout);
	  fputs(";\n", stdout);
	}
} /*_ tablealtree */

void
tablealtree_njml(numaltree, fp)
int numaltree;
FILE *fp;
/* For the exact likelihood mode */
{
	Infoaltree *cp, **info;
	int i;
	char buf[5000]; /* Ad hoc !*/

	info = (Infoaltree **)malloc((unsigned)numaltree * sizeof(Infoaltree *));
	if (info == NULL) maerror("in tablealtree_njml().");
	for (cp = Atail.up, i = numaltree; cp != &Ahead; cp = cp->up) {
		info[--i] = cp;
	/*	printf("%.1f %s\n", cp->lklaprox, cp->ltplgy); */
	}
	printf("%d / %d \"%s\"", numaltree, Cnotree, Modelname);
	printf(" approx ln L %.1f", info[0]->lklaprox);
	printf(" ... %.1f", info[numaltree-1]->lklaprox);
	printf(" diff %.1f\n", info[0]->lklaprox - info[numaltree-1]->lklaprox);
	for (i = 0; i < numaltree; i++) {
		if (Info_optn ) printf("%.1f ", info[i]->lklaprox);
		fputs(info[i]->ltplgy, stdout);
		fputs(";", stdout);
		printf("likelihood=%.1f", info[i]->lklaprox);
		fputs("\n", stdout);
	}
	sprintf(buf, "%d / %d \"%s\"", numaltree, Cnotree, Modelname);
	fputs(buf, fp);
	sprintf(buf, " approx ln L %.1f", info[0]->lklaprox);
	fputs(buf, fp);
	sprintf(buf, " ... %.1f", info[numaltree-1]->lklaprox);
	fputs(buf, fp);
	sprintf(buf, " diff %.1f\n", info[0]->lklaprox - info[numaltree-1]->lklaprox);
	fputs(buf, fp);
	for (i = 0; i < numaltree; i++) {
		sprintf(buf, "%s", info[i]->ltplgy);
		fputs(buf, fp);
		sprintf(buf, ";");
		fputs(buf, fp);
		if (1) {
		  sprintf(buf, "likelihood=%.1f", info[i]->lklaprox);
		  fputs(buf, fp);
		}
		fputs("\n", fp);
	}
} /*_ tablealtree_njml */

void
tablealtree_njml2(numaltree, fp)
int numaltree;
FILE *fp;
/* For the exact likelihood mode */
{
	Infoaltree *cp, **info;
	int i;
	char buf[5000]; /* Ad hoc !*/

	info = (Infoaltree **)malloc((unsigned)numaltree * sizeof(Infoaltree *));
	if (info == NULL) maerror("in tablealtree_njml().");
	for (cp = Atail.up, i = numaltree; cp != &Ahead; cp = cp->up) {
		info[--i] = cp;
	/*	printf("%.1f %s\n", cp->lklaprox, cp->ltplgy); */
	}
	printf("%d / %d \"%s\"", numaltree, Cnotree, Modelname);
	printf(" exact ln L %.1f", info[0]->lklaprox);
	printf(" ... %.1f", info[numaltree-1]->lklaprox);
	printf(" diff %.1f\n", info[0]->lklaprox - info[numaltree-1]->lklaprox);
	for (i = 0; i < numaltree; i++) {
		if (Info_optn ) printf("%.1f ", info[i]->lklaprox);
		fputs(info[i]->ltplgy, stdout);
		fputs(";\n", stdout);
	}
	sprintf(buf, "%d / %d \"%s\"", numaltree, Cnotree, Modelname);
	fputs(buf, fp);
	sprintf(buf, " exact ln L %.1f", info[0]->lklaprox);
	fputs(buf, fp);
	sprintf(buf, " ... %.1f", info[numaltree-1]->lklaprox);
	fputs(buf, fp);
	sprintf(buf, " diff %.1f\n", info[0]->lklaprox - info[numaltree-1]->lklaprox);
	fputs(buf, fp);
	for (i = 0; i < numaltree; i++) {
		sprintf(buf, "%s", info[i]->ltplgy);
		fputs(buf, fp);
		sprintf(buf, ";");
		fputs(buf, fp);
		if (1) {
		  sprintf(buf, " %.1f ", info[i]->lklaprox); 
		  fputs(buf, fp);
		  fputs("+-", fp);
		  sprintf(buf, " %.1f ", sqrt(info[i]->varilkl)); 
		  fputs(buf, fp);
		}
		fputs("\n", fp);
	}
} /*_ tablealtree_njml2 */

int get_bs(char **cp) {
  char bs[6]; /* Bootstrap value must be up to 999,999 */
  int i;

  for (i = 0; **cp != ':'; (*cp)++, i++) {
    bs[i] = **cp;
  }
  bs[i] = '\0';
  return atoi(bs);
}

double get_distance(char **cp) {
  char length[9]; /* Length must be presented up to by 8 digits */
  int i;
  
  (*cp)++; /* Skip ':' */
  for (i = 0; (**cp != ',') && (**cp != ')' ); (*cp)++, i++) {
    /* Get distance */
    length[i] = **cp;
  }
  length[i] = '\0';
  return atof(length);
}

void renumber(Tree *tr) {
  int i;

  for (i = 0; i < Maxibrnch; i++)
    tr->ibrnchp[i]->kinp->number = tr->ibrnchp[i]->number;
}



