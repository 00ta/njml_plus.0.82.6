#define MAIN_MODULE 1
#include "protml.h"

void getbstree(FILE *, cvector, int);
void get_strtree(int *, int *, char **);
void set_strtree(char **, char **);
void constructbstree(Tree*, cvector);
double get_distance(char **);
int get_bsvalue(char **);
Node *internalnode_bs(Tree*, char**, int*);
void set_option();
void pass_carriage_return(char **);
void resultbstree(Tree*);
void traverse(Tree*);
void print_bootstrap(Tree*);
void remove_low_bootstrap_branch(Tree *, int);
void remove_lowest_bootstrap_branch(Tree *);
void remove_lowbs_branches(Tree *);
void chk_bs(Tree *, Node *, int *);
Node *removeibranch2(Tree *, Node *);
void remove_lowest_bootstrap_branch2(Tree *);
void node_number(Tree *);
void game_tree(Tree *, FILE *);

int main(int argc, char**argv){
  FILE *ifp, *ifp2, *ofp, *ofp2, *tplfp;
  int buftree, i, j, k;
  char *comment;
  ivector alias;
  cmatrix seqchar2;

  /* Open files for sequence data and  topologies */
  if ((ifp = fopen(argv[1], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n",argv[0],argv[1]);
  if ((tplfp = fopen(argv[2], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n",argv[0],argv[2]);
  
  /* Get size of sequence data */
  getsize(ifp, &Maxspc, &Maxsite, &comment);

  /* Allocate memory space for names of sequence data */
  Identif = (char **)malloc((unsigned)Maxspc * sizeof(char *));
  if (Identif == NULL) maerror("in tree");

  /* Allocate memory space for sequene data */
  Seqchar = new_cmatrix(Maxspc, Maxsite);   /* Conventional sequence format */ 
  /* Character-based sequence format */ 
  seqchar2 = new_cmatrix(Maxspc, Maxsite);

  /* Get sequence data */
  /*
  getseqs(ifp, Identif, Seqchar, Maxspc, Maxsite);
  */
  /* Get a sequence set in interleaved input format */
  getseqi(ifp, Identif, Seqchar, Maxspc, Maxsite);
  if ((ifp2 = fopen(argv[1], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n",argv[0],argv[1]);
/* Get size of sequence data */
  getsize(ifp2, &Maxspc, &Maxsite, &comment);
  getseqi2(ifp2, Identif, seqchar2, Maxspc, Maxsite);
  fclose(ifp2);

  /* Allocate memory space for a topology represented by a string */
  buftree =  getbuftree(Maxspc, Identif);
  Strtree = new_cvector(buftree);

  /* Some preparations for making trees */  
  getfreqepm(Seqchar, Freqemp, Maxspc, Maxsite);
  alias = new_ivector(Maxsite);
  radixsort_njml(Seqchar, alias, Maxspc, Maxsite, &Numptrn);
  Seqconint = new_imatrix(Maxspc, Numptrn);
  Weight = new_ivector(Numptrn);
  condenceseq(Seqchar, alias, Seqconint, Weight, Maxspc, Maxsite, Numptrn);
  convseq(Seqconint, Maxspc, Numptrn);
  
  Maxbrnch = 2 * Maxspc - 3;
  Maxibrnch = Maxspc - 3;
  Maxpair = (Maxspc * (Maxspc - 1)) / 2;

  Numspc = Maxspc;
  Numbrnch = Maxbrnch;
  Numpair = Maxpair;
  Numsite = Maxsite;
  Numibrnch = Numspc - 3;
  Converg = TRUE;
  Numit = 0;

  Ctree = (Tree *) new_tree(Maxspc, Maxibrnch, Numptrn, Seqconint);

  /* Get a topology */
  getbstree(tplfp, Strtree, buftree);
  puts(Strtree);
  constructbstree(Ctree, Strtree);
  node_number(Ctree);
  if ((ofp = fopen("game_tree", "w")) == NULL)
    fprintf(stderr,"%s: can't open %s\n","make_games_file","game_tree");    
  game_tree(Ctree, ofp);
  fclose(ofp);

  if ((ofp2 = fopen("game_seq", "w")) == NULL)
    fprintf(stderr,"%s: can't open %s\n","make_games_file","game_seq");  
  for (i = 0; i < Maxspc; i++) {
    fprintf(ofp2, Identif[i]);
    for (k = 0; k < 10-strlen(Identif[i]); k++)
      fputc(' ', ofp2);
    for (j = 0; j < Maxsite; j++)
      fputc(seqchar2[i][j], ofp);
    fputc('\n', ofp2);
  }
  fclose(ofp2);
  return 0;
}

Node *
internalnode_bs(tr, chpp, ninode)
Tree *tr;    /* Tree */
char **chpp; /* Pointer to strtree */
int *ninode; /* Internal branch number */
{
	Node *xp, *np, *rp;
	int i, j, dvg, bootstrap;
	double distance;
	char ident[MAXWORD];
	char *idp;

	(*chpp)++;
	if (**chpp == '(') {
		if (Debug) printf("external: %c\n", **chpp);
		xp = internalnode_bs(tr, chpp, ninode);
		xp->isop = xp;
		dvg = 1;
		while (**chpp != ')') {
			if (**chpp == '\0') {
				fputs("ERROR users tree, in internalnode_bs 1\n", stderr);
				fputs(*chpp, stderr); fputc('\n', stderr);
				exit(1);
			}
			dvg++;
			np = internalnode_bs(tr, chpp, ninode);
			np->isop = xp->isop;
			xp->isop = np; 
			xp = np;
		}
		bootstrap = get_bsvalue(chpp);
		distance = get_distance(chpp);
		/*
		printf("%d\n", bootstrap);
		printf("%f\n", distance(chpp));
		*/
		if (dvg < 2) {
			fputs("ERROR users tree, in internalnode_bs 2\n", stderr);
			fputs(*chpp, stderr); fputc('\n', stderr);
			exit(1);
		}
		/* Make an internal branch (node): rp */
		rp = tr->ibrnchp[*ninode];
		rp->isop = xp->isop;
		xp->isop = rp;
		/* Bootstrap values must be the same
		   in either directions */
		rp->bootstrap = bootstrap;
		rp->kinp->bootstrap = bootstrap;
		/* Distances must be the same
		   in either directions */
		rp->length = distance;
		rp->kinp->length = distance;
		/* Set path to OTU */
		/* Initialize paths */
		for (j = 0; j < Numspc; j++)
			rp->paths[j] = 0;
		xp = rp->isop;
		/* Sync all paths of internal nodes */
		while (xp != rp) {
			for (j = 0; j < Numspc; j++) {
				if (xp->paths[j] == 1)
					rp->paths[j] = 1;
			}
			xp = xp->isop;
		}
		if (Debug) {
			for (j = 0; j < Numspc; j++) printf("%2d",rp->paths[j]);
			putchar('\n');
		}

		(*ninode)++;
		return rp->kinp;
	} else if (isalnum(**chpp)) {
		if (Debug) printf("internal: %c\n", **chpp);
		for (idp = ident; **chpp != ':' && **chpp != '\0'; (*chpp)++) {
			*idp++ = **chpp;
			if (Debug) putchar(**chpp);
		}
		switch(**chpp) { 
		case ':':
		  distance = get_distance(chpp);
		  /*
		  printf("%f\n", distance);
		  */
		  *idp = '\0';
		  if (Debug) putchar('\n');
		  /* if (**chpp == ',') (*chpp)++; */
		  /* puts(ident); */
		  for (i = 0; i < Numspc; i++) {
		    /* puts(Identif[i]); */
		    if (!strcmp(ident, Identif[i])) {
		      if (Debug) {
			for (j = 0; j < Numspc; j++)
			  printf("%2d",tr->ebrnchp[i]->paths[j]);
			putchar('\n');
		      }
		      /* Distances must be the same
			 in either directions */
		      tr->ebrnchp[i]->length = distance;
		      tr->ebrnchp[i]->kinp->length = distance;
		      return tr->ebrnchp[i]->kinp;
		    }
		  }
		case '\0':
		  fputs("ERROR users tree, in internalnode_bs 3\n", stderr);
		  fputs(*chpp, stderr); fputc('\n', stderr);
		  fprintf(stderr, "abnormal identifier(name): %s\n", ident);
		  return NULL;
		default:
		  fputs("ERROR users tree, in internalnode_bs 4\n", stderr);
		  fputs(*chpp, stderr); fputc('\n', stderr);
		  return NULL;
		}
	}
} /*_ internalnode_bs */

void node_number(Tree *tr) {
  Node *cp, *rp, *rp2;

  int wk_inum = Numspc;
  
  cp = rp = tr->rootp;
  do {
    cp = cp->isop->kinp;
    if (cp->isop == NULL) { /* external node */
      cp->inum = cp->number + 1;
      cp = cp->kinp;
    } else { /* internal node */
      rp2 = cp;
      cp->isop->inum = cp->inum;
      cp = cp->isop;
      while (cp != rp2) {
	cp->isop->inum = cp->inum;
	cp = cp->isop;
      }
      if (cp->inum == 0) {
	wk_inum++;
	cp->inum = wk_inum;
      }
      rp2 = cp;
      cp->isop->inum = cp->inum;
      cp = cp->isop;
      while (cp != rp2) {
	cp->isop->inum = cp->inum;
	cp = cp->isop;
      }
    }
  } while (cp != rp);
}

void
getbstree(ifp, strtree, buftree)
FILE *ifp;
cvector strtree;
int buftree;
{
	char line[BUFLINE];
	char *cp, *np;
	int par1, par2, bra1, bra2;
	dvector *branchlens, *bsvalues;

	if (Debug) printf("buftree = %5d\n", buftree);
	par1 = 0; par2 = 0;
	bra1 = 0; bra2 = 0;
	np = strtree;
	strtree[buftree - 1] = '\0';
	while (fgets(line, BUFLINE, ifp) != NULL) {
	  for (cp = line; (*cp != ';') && (*cp != '\n') && (*cp != (int) NULL);) {
	    set_strtree(&cp, &np);
	  }
	  switch(*cp) { 
	  case ';':
	    set_strtree(&cp, &np);
	    get_strtree(&par1, &par2, &np);
	    return;
	  case '\n':
	    pass_carriage_return(&cp);
	    break;
	  case '\0':
	    break;
	  default:
	    fputs("Something wrong, in getbstree\n", stderr);
	  }
	}
} /*_ getbstree*/

void get_strtree(int *par1, int *par2, char **np) {
  **np = '\0';
}

void set_strtree(char **cp, char **np) {
  **np = **cp;
  (*cp)++;
  (*np)++;
}

int get_bsvalue(char **cp) {
  char bs[6]; /* Bootstrap value must be up to 999,999 */
  int i;

  (*cp)++; /* Skip ')' */
  for (i = 0; **cp != ':'; (*cp)++, i++) {
    bs[i] = **cp;
  }
  bs[i] = '\0';
  return atoi(bs);
}

void pass_carriage_return(char **cp) {
  (*cp)++;
}
  
void print_bootstrap(Tree *tr) {
  int i;

  for (i = 0; i < Numibrnch; i++) {
    printf("ibrnchp[%d]->bootstrap = %d\n", i, tr->ibrnchp[i]->bootstrap);
  }
}

void remove_low_bootstrap_branch(Tree *tr, int min_bootstrap) {
  int i;

  for (i = 0; i < Numibrnch; i++) {
    if (tr->ibrnchp[i]->bootstrap < min_bootstrap) {
      removeibranch(tr, i);
      rerootq(tr, Numspc);
    }
  }
}

void
constructbstree(tr, strtree)
Tree *tr;
cvector strtree;
{
	char *chp;
	int ninode;
	int dvg;
	Node *xp, *np;

	ninode = 0;
	chp = strtree;
	/* puts(chp); */
	if (*chp == '(') {
		if (Debug) printf("roottre0: %c\n", *chp);
		xp = internalnode_bs(tr, &chp, &ninode);
		xp->isop = xp;
		dvg = 1;
		while (*chp != ')') {
			if (*chp == '\0') {
				fprintf(stderr, "ERROR user tree, in constructtree 1\n");
				fputs(strtree, stderr);
				putc('\n', stderr);
				exit(1);
			}
			dvg++;
			if (Debug) printf("roottre1: %c\n", *chp);
			np = internalnode_bs(tr, &chp, &ninode);
			np->isop = xp->isop;
			xp->isop = np; 
			xp = np;
		}
		if (dvg < 2) {
			fputs("ERROR users tree, in constructtree 2\n", stderr);
			fputs(strtree, stderr);
			putc('\n', stderr);
			exit(1);
		}
		tr->rootp = xp;
		Numibrnch = ninode;
		Numbrnch = Numspc + ninode;
	} else {
		fprintf(stderr, "ERROR users tree, in constructtree 3\n");
		fputs(strtree, stderr);
		putc('\n', stderr);
		exit(1);
	}
} /*_ constructtree */

double get_distance(char **cp) {
  char length[9]; /* Length must be presented up to by 8 digits */
  int i;
  
  (*cp)++; /* Skip ':' */
  for (i = 0; (**cp != ',') && (**cp != ')' ); (*cp)++, i++) {
    /* Get distance */
    length[i] = **cp;
  }
  length[i] = '\0';
  return atof(length);
}

void
game_tree(Tree *tr, FILE *ofp)
{
	int i, n, ne;
	Node *ep, *ip, *np;

	fprintf(ofp, "%3d sequences\n", Numspc);
	for (n = 0; n < Numspc; n++) {
	  fprintf(ofp, "%d %s\n", n+1, Identif[n]);
	}
	for (n = 0; n < Numspc; n++) {
			ip = tr->ebrnchp[n];
			fprintf(ofp, "%3d and %3d", ip->inum, ip->kinp->inum); 
#if 0
			fprintf(ofp, "        %6d", ip->length);
#endif
			fputc('\n', ofp);
	}
	for (n = 0; n < Numibrnch; n++) {
			ip = tr->ibrnchp[n];
			fprintf(ofp, "%3d and %3d", ip->inum, ip->kinp->inum); 
#if 0
			fprintf(ofp, "        %6d", ip->length);
#endif
			fputc('\n', ofp);
	}
} /*_gametree */
