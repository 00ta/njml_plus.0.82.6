/* July 28 - March 7, 2000 */

#include "protml.h"

void getbstree(FILE *, cvector, int);
void get_strtree(int *, int *, char **);
void set_strtree(char **, char **);
void constructbstree(Tree*, cvector);
void constructtree2(Tree*, cvector);
double setbs_get_distance(char **);
int setbs_get_bs(char **);
Node *internalnode_bs(Tree*, char**, int*);
Node *internalnode2(Tree*, char**, int*);
void set_option();
void pass_carriage_return(char **);
void resultbstree(Tree*);
void traverse(Tree*);
void print_bootstrap(Tree*);
void remove_low_bootstrap_branch(Tree *, int);
void remove_lowest_bootstrap_branch(Tree *);
void setbs(Tree*, Tree*);
void setbs2(char*, Tree*, int);
Tree *new_tree();
void rerootq();
void pathing();
char *fputcphylogeny3();
void getusertree();

void setbs2(char *filename, Tree *njmltree, int buftree){
  FILE *ifp, *tmpfp;
  Tree *tree1, *tree2;

  /* Get a topology 1 (bootstrap initial nj tree) */
  tree1 = (Tree *) new_tree(Maxspc, Maxibrnch, Numptrn, Seqconint);
  if ((ifp = fopen(filename, "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n", "setbs2", filename);
  getbstree(ifp, Strtree, buftree);
  /*
  printf("%s\n", Strtree);
  */
  constructbstree(tree1, Strtree);
  rerootq(tree1, Numspc);
  pathing(tree1);
  /*
  prtopology(tree1);
  printf("%s\n", fputcphylogeny3(tree1));
  */
  /*
  for (i = 0; i < Maxibrnch; i++) {
    for (j = 0; j < Maxspc; j++) {
      printf("tree1->ibrnchp[%d]->paths[%d] = %d\n", i, j,
	     tree1->ibrnchp[i]->paths[j]);
    }
    printf("\n");
  }
  */
  /* Get a topology 2 */
  /* Copy tree */
#if 0  /* I should write this but tedious; Instead, I write njmltree into a file and read to construct tree2 */
  copy_tree(njmltree, tree2);
#endif
  tree2 = (Tree *) new_tree(Maxspc, Maxibrnch, Numptrn, Seqconint);
  /* Write njml tree */
  if ((tmpfp = fopen("njmltree.tmp", "w")) == NULL)
    fprintf(stderr,"%s: can't open %s\n", "setbs2", "njmltree.tmp");    
  fprintf(tmpfp, "%s\n", fputcphylogeny3(njmltree));
  fclose(tmpfp);  
  /* Read njml tree */
  if ((tmpfp = fopen("njmltree.tmp", "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n", "setbs2", "njmltree.tmp");    
  getusertree(tmpfp, Strtree, buftree);
  fclose(tmpfp);  
  /* Construct tree 2 */
  constructbstree(tree2, Strtree);  
  /*
  tree2 = njmltree;  This will overide the original tree
  */
  rerootq(tree2, Numspc);
  pathing(tree2);
  /*
  prtopology(tree2);
  */
  /*
  for (i = 0; i < Maxibrnch; i++) {
    for (j = 0; j < Maxspc; j++) {
      printf("tree2->ibrnchp[%d]->paths[%d] = %d\n", i, j,
	     tree2->ibrnchp[i]->paths[j]);
    }
    printf("\n");
  }
  */
  setbs(tree1, tree2);
  fclose(ifp);

  /* Display Tree with lengths and bootstrap values */
  putchar('\n');
  puts("Tree with lengths and bootstrap values"); 
  puts((char *)fputcphylogeny3(tree2));
  putchar('\n');

  /* The above line does not work for exact mode. I'don't know why... */
  free_tree(tree1, Maxspc, Maxibrnch);
  free_tree(tree2, Maxspc, Maxibrnch);
}

Node *
internalnode_bs(tr, chpp, ninode)
Tree *tr;    /* Tree */
char **chpp; /* Pointer to strtree */
int *ninode; /* Internal branch number */
{
	Node *xp, *np, *rp;
	int i, j, dvg, bootstrap;
	double distance;
	char ident[MAXWORD];
	char *idp;

	(*chpp)++;
	if (**chpp == '(') {
		if (Debug) printf("external: %c\n", **chpp);
		xp = internalnode_bs(tr, chpp, ninode);
		xp->isop = xp;
		dvg = 1;
		while (**chpp != ')') {
			if (**chpp == '\0') {
				fputs("ERROR users tree, in internalnode_bs 1\n", stderr);
				fputs(*chpp, stderr); fputc('\n', stderr);
				exit(1);
			}
			dvg++;
			np = internalnode_bs(tr, chpp, ninode);
			np->isop = xp->isop;
			xp->isop = np; 
			xp = np;
		}
		bootstrap = setbs_get_bs(chpp);
		/*
		printf("bootstrap = %d\n", bootstrap);
		*/
		distance = setbs_get_distance(chpp);
		/*
		printf("%d\n", bootstrap);
		printf("%f\n", distance(chpp));
		*/
		if (dvg < 2) {
			fputs("ERROR users tree, in internalnode_bs 2\n", stderr);
			fputs(*chpp, stderr); fputc('\n', stderr);
			exit(1);
		}
		/* Make an internal branch (node): rp */
		rp = tr->ibrnchp[*ninode];
		rp->isop = xp->isop;
		xp->isop = rp;
		/* Bootstrap values must be the same
		   in either directions */
		rp->bootstrap = bootstrap;
		rp->kinp->bootstrap = bootstrap;
		/* Distances must be the same
		   in either directions */
		rp->length = distance;
		rp->kinp->length = distance;
		/* Set path to OTU */
		/* Initialize paths */
		for (j = 0; j < Numspc; j++)
			rp->paths[j] = 0;
		xp = rp->isop;
		/* Sync all paths of internal nodes */
		while (xp != rp) {
			for (j = 0; j < Numspc; j++) {
				if (xp->paths[j] == 1)
					rp->paths[j] = 1;
			}
			xp = xp->isop;
		}
		if (Debug) {
			for (j = 0; j < Numspc; j++) printf("%2d",rp->paths[j]);
			putchar('\n');
		}

		(*ninode)++;
		return rp->kinp;
	} else if (isalnum(**chpp)) {
		if (Debug) printf("internal: %c\n", **chpp);
		for (idp = ident; **chpp != ':' && **chpp != '\0'; (*chpp)++) {
			*idp++ = **chpp;
			if (Debug) putchar(**chpp);
		}
		switch(**chpp) { 
		case ':':
		  distance = setbs_get_distance(chpp);
		  /*
		  printf("%f\n", distance);
		  */
		  *idp = '\0';
		  if (Debug) putchar('\n');
		  /* if (**chpp == ',') (*chpp)++; */
		  /* puts(ident); */
		  for (i = 0; i < Numspc; i++) {
		    /* puts(Identif[i]); */
		    if (!strcmp(ident, Identif[i])) {
		      if (Debug) {
			for (j = 0; j < Numspc; j++)
			  printf("%2d",tr->ebrnchp[i]->paths[j]);
			putchar('\n');
		      }
		      /* Distances must be the same
			 in either directions */
		      tr->ebrnchp[i]->length = distance;
		      tr->ebrnchp[i]->kinp->length = distance;
		      return tr->ebrnchp[i]->kinp;
		    }
		  }
		case '\0':
		  fputs("ERROR users tree, in internalnode_bs 3\n", stderr);
		  fputs(*chpp, stderr); fputc('\n', stderr);
		  fprintf(stderr, "abnormal identifier(name): %s\n", ident);
		  return NULL;
		default:
		  fputs("ERROR users tree, in internalnode_bs 4\n", stderr);
		  fputs(*chpp, stderr); fputc('\n', stderr);
		  return NULL;
		}
	}
    return 0;
} /*_ internalnode_bs */

Node *
internalnode2(tr, chpp, ninode)
Tree *tr;    /* Tree */
char **chpp; /* Pointer to strtree */
int *ninode; /* Internal branch number */
{
	Node *xp, *np, *rp;
	int i, j, dvg, bootstrap;
	double distance;
	char ident[MAXWORD];
	char *idp;

	(*chpp)++;
	if (**chpp == '(') {
		if (Debug) printf("external: %c\n", **chpp);
		xp = internalnode2(tr, chpp, ninode);
		xp->isop = xp;
		dvg = 1;
		while (**chpp != ')') {
			if (**chpp == '\0') {
				fputs("ERROR users tree, in internalnode2 1\n", stderr);
				fputs(*chpp, stderr); fputc('\n', stderr);
				exit(1);
			}
			dvg++;
			np = internalnode2(tr, chpp, ninode);
			np->isop = xp->isop;
			xp->isop = np; 
			xp = np;
		}
		distance = setbs_get_distance(chpp);
		if (dvg < 2) {
			fputs("ERROR users tree, in internalnode2 2\n", stderr);
			fputs(*chpp, stderr); fputc('\n', stderr);
			exit(1);
		}
		/* Make an internal branch (node): rp */
		rp = tr->ibrnchp[*ninode];
		rp->isop = xp->isop;
		xp->isop = rp;
		/* Distances must be the same
		   in either directions */
		rp->length = distance;
		rp->kinp->length = distance;
		/* Set path to OTU */
		/* Initialize paths */
		for (j = 0; j < Numspc; j++)
			rp->paths[j] = 0;
		xp = rp->isop;
		/* Sync all paths of internal nodes */
		while (xp != rp) {
			for (j = 0; j < Numspc; j++) {
				if (xp->paths[j] == 1)
					rp->paths[j] = 1;
			}
			xp = xp->isop;
		}
		if (Debug) {
			for (j = 0; j < Numspc; j++) printf("%2d",rp->paths[j]);
			putchar('\n');
		}

		(*ninode)++;
		return rp->kinp;
	} else if (isalnum(**chpp)) {
		if (Debug) printf("internal: %c\n", **chpp);
		for (idp = ident; **chpp != ':' && **chpp != '\0'; (*chpp)++) {
			*idp++ = **chpp;
			if (Debug) putchar(**chpp);
		}
		switch(**chpp) { 
		case ':':
		  distance = setbs_get_distance(chpp);
		  /*
		  printf("%f\n", distance);
		  */
		  *idp = '\0';
		  if (Debug) putchar('\n');
		  /* if (**chpp == ',') (*chpp)++; */
		  /* puts(ident); */
		  for (i = 0; i < Numspc; i++) {
		    /* puts(Identif[i]); */
		    if (!strcmp(ident, Identif[i])) {
		      if (Debug) {
			for (j = 0; j < Numspc; j++)
			  printf("%2d",tr->ebrnchp[i]->paths[j]);
			putchar('\n');
		      }
		      /* Distances must be the same
			 in either directions */
		      tr->ebrnchp[i]->length = distance;
		      tr->ebrnchp[i]->kinp->length = distance;
		      return tr->ebrnchp[i]->kinp;
		    }
		  }
		case '\0':
		  fputs("ERROR users tree, in internalnode2 3\n", stderr);
		  fputs(*chpp, stderr); fputc('\n', stderr);
		  fprintf(stderr, "abnormal identifier(name): %s\n", ident);
		  return NULL;
		default:
		  fputs("ERROR users tree, in internalnode2 4\n", stderr);
		  fputs(*chpp, stderr); fputc('\n', stderr);
		  return NULL;
		}
	}
    return 0;
} /*_ internalnode2 */


void
constructbstree(tr, strtree)
Tree *tr;
cvector strtree;
{
	char *chp;
	int ninode;
	int dvg;
	Node *xp, *np;

	ninode = 0;
	chp = strtree;
	/* puts(chp); */
	if (*chp == '(') {
		if (Debug) printf("roottre0: %c\n", *chp);
		xp = internalnode_bs(tr, &chp, &ninode);
		xp->isop = xp;
		dvg = 1;
		while (*chp != ')') {
			if (*chp == '\0') {
				fprintf(stderr, "ERROR user tree, in constructtree 1\n");
				fputs(strtree, stderr);
				putc('\n', stderr);
				exit(1);
			}
			dvg++;
			if (Debug) printf("roottre1: %c\n", *chp);
			np = internalnode_bs(tr, &chp, &ninode);
			np->isop = xp->isop;
			xp->isop = np; 
			xp = np;
		}
		if (dvg < 2) {
			fputs("ERROR users tree, in constructtree 2\n", stderr);
			fputs(strtree, stderr);
			putc('\n', stderr);
			exit(1);
		}
		tr->rootp = xp;
		Numibrnch = ninode;
		Numbrnch = Numspc + ninode;
	} else {
		fprintf(stderr, "ERROR users tree, in constructtree 3\n");
		fputs(strtree, stderr);
		putc('\n', stderr);
		exit(1);
	}
} /*_ constructtree */

void
constructtree2(tr, strtree)
Tree *tr;
cvector strtree;
{
	char *chp;
	int ninode;
	int dvg;
	Node *xp, *np;

	ninode = 0;
	chp = strtree;
	/* puts(chp); */
	if (*chp == '(') {
		if (Debug) printf("roottre0: %c\n", *chp);
		xp = internalnode2(tr, &chp, &ninode);
		xp->isop = xp;
		dvg = 1;
		while (*chp != ')') {
			if (*chp == '\0') {
				fprintf(stderr, "ERROR user tree, in constructtree 1\n");
				fputs(strtree, stderr);
				putc('\n', stderr);
				exit(1);
			}
			dvg++;
			if (Debug) printf("roottre1: %c\n", *chp);
			np = internalnode2(tr, &chp, &ninode);
			np->isop = xp->isop;
			xp->isop = np; 
			xp = np;
		}
		if (dvg < 2) {
			fputs("ERROR users tree, in constructtree 2\n", stderr);
			fputs(strtree, stderr);
			putc('\n', stderr);
			exit(1);
		}
		tr->rootp = xp;
		Numibrnch = ninode;
		Numbrnch = Numspc + ninode;
	} else {
		fprintf(stderr, "ERROR users tree, in constructtree 3\n");
		fputs(strtree, stderr);
		putc('\n', stderr);
		exit(1);
	}
} /*_ constructtree2 */


void
getbstree(ifp, strtree, buftree)
FILE *ifp;
cvector strtree;
int buftree;
{
	char line[BUFLINE];
	char *cp, *np;
	int par1, par2, bra1, bra2;

	if (Debug) printf("buftree = %5d\n", buftree);
	par1 = 0; par2 = 0;
	bra1 = 0; bra2 = 0;
	np = strtree;
	strtree[buftree - 1] = '\0';
	while (fgets(line, BUFLINE, ifp) != NULL) {
	  for (cp = line; (*cp != ';') && (*cp != '\n') && (*cp != NULL);) {
	    set_strtree(&cp, &np);
	  }
	  switch(*cp) { 
	  case ';':
	    set_strtree(&cp, &np);
	    get_strtree(&par1, &par2, &np);
	    return;
	  case '\n':
	    pass_carriage_return(&cp);
	    break;
	  case '\0':
	    break;
	  default:
	    fputs("Something wrong, in setbs2\n", stderr);
	  }
	}
} /*_ getbstree*/

void get_strtree(int *par1, int *par2, char **np) {
  **np = '\0';
}

void set_strtree(char **cp, char **np) {
  **np = **cp;
  (*cp)++;
  (*np)++;
}

void pass_carriage_return(char **cp) {
  (*cp)++;
}
  
void print_bootstrap(Tree *tr) {
  int i;

  for (i = 0; i < Numibrnch; i++) {
    printf("ibrnchp[%d]->bootstrap = %d\n", i, tr->ibrnchp[i]->bootstrap);
  }
}

void remove_low_bootstrap_branch(Tree *tr, int min_bootstrap) {
  int i;

  for (i = 0; i < Numibrnch; i++) {
    if (tr->ibrnchp[i]->bootstrap < min_bootstrap) {
      removeibranch(tr, i);
      rerootq(tr, Numspc);
    }
  }
}

void remove_lowest_bootstrap_branch(Tree *tr) {
  int i, j, current_bootstrap;
  /* Remove a branch having the lowest bootstrap value */
  current_bootstrap = tr->ibrnchp[i]->bootstrap;
  j = i;
  for (i = 1; i < Numibrnch; i++) {
    if (tr->ibrnchp[i]->bootstrap < current_bootstrap) {
      current_bootstrap = tr->ibrnchp[i]->bootstrap;
      j = i;
    }
  }
  removeibranch(tr, j);
  rerootq(tr, Numspc);
}

void setbs(Tree *tree1, Tree *tree2) {
  int i, j, k, l, m; 

  for (i = 0; i < Maxibrnch; i++) {
    for (j = 0; j < Maxibrnch; j++) {
      k = 0;
      while (k < Maxspc) {
	if (tree1->ibrnchp[j]->paths[k] != tree2->ibrnchp[i]->paths[k])
	  break;
	else
	  k++;
      }
      if (k == Maxspc) {
	/* Copy boot strap values */

	/* Check paths */
	/*
	printf("Copy BV:\n\n");
	for (m = 0; m < Maxspc; m++) {
	  printf("%d ", tree1->ibrnchp[j]->paths[m]);
	}
	putchar('\n');
	for (m = 0; m < Maxspc; m++) {
	  printf("%d ", tree2->ibrnchp[i]->paths[m]);
	}
	putchar('\n');
	putchar('\n');
	*/
	tree2->ibrnchp[i]->bootstrap = tree1->ibrnchp[j]->bootstrap;
	tree2->ibrnchp[i]->kinp->bootstrap = tree1->ibrnchp[j]->bootstrap;
	break;
      }
    }
    if (j == Maxibrnch) {

      /* Check paths */
      /*
      printf("Set 9999:\n\n");
      for (m = 0; m < Maxspc; m++) {
	printf("%d ", tree1->ibrnchp[j-1]->paths[m]);
      }
      putchar('\n');
      for (m = 0; m < Maxspc; m++) {
	printf("%d ", tree2->ibrnchp[i]->paths[m]);
      }
      putchar('\n');
      putchar('\n');
      */
      tree2->ibrnchp[i]->bootstrap = 9999;
      tree2->ibrnchp[i]->kinp->bootstrap = 9999;
    }
  }
}
    
int setbs_get_bs(char **cp) {
  char bs[12]; /* Bootstrap value must be up to 999,999 */
  int i;

  (*cp)++; /* Skip ')' */
  for (i = 0; **cp != ':'; (*cp)++, i++) {
    bs[i] = **cp;
  }
  bs[i] = '\0';
  return atoi(bs);
}

double setbs_get_distance(char **cp) {
  char length[12]; /* Length must be presented up to by 12 digits */
  int i;

  if ((**cp) == ')')
    (*cp)++; /* Skip ')' */
  (*cp)++; /* Skip ':' */
  for (i = 0; (**cp != ',') && (**cp != ')' ); (*cp)++, i++) {
    /* Get distance */
    length[i] = **cp;
  }
  length[i] = '\0';
  return atof(length);
}
	
