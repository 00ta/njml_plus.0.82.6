/*
  Check results of computer run times
  Format: tmp: <run times>
  Return averages and variances 
 */

#define MAIN_MODULE 1
#include "protml.h"

void get_average(FILE *, int *, float *);
void get_variance(FILE *, float, float *);

int main(int argc, char *argv[])
{
  FILE *ifp;
  int numdata;
  float ave, var;

  if (argc != 2) {
    puts("result <Result file>");
    return 1;
  }

  /* Open a results file */ 
  if ((ifp = fopen(argv[1], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n", "result", argv[1]);
  get_average(ifp, &numdata, &ave);
  fclose(ifp);
  /* Open a results file */ 
  if ((ifp = fopen(argv[1], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n", "result", argv[1]);
  get_variance(ifp, ave, &var);
  fclose(ifp);

  printf("# of data = %d\n", numdata);
  printf("Average = %f\n", ave);
  printf("Variance = %f\n", var);

  return 0;

}
  
void get_average(FILE *ifp, int *numdata, float *ave) {
  char line[BUFLINE], s1[BUFLINE], s2[BUFLINE];
  float time, sum;

  *numdata = 0;
  sum = 0;
  for (; ;) {
    if (fgets(line, BUFLINE, ifp) == NULL)
      break;
    sscanf(line, "%s %s", s1, s2);
    time = atof(s2);
    (*numdata)++;
    sum = sum + time;
  }
  *ave = sum / (float)*numdata;
}

void get_variance(FILE *ifp, float ave, float *var) {
  char line[BUFLINE], s1[BUFLINE], s2[BUFLINE];
  int numdata;
  float time, sum;

  numdata = 0;
  sum = 0;
  for (; ;) {
    if (fgets(line, BUFLINE, ifp) == NULL)
      break;
    sscanf(line, "%s %s", s1, s2);
    time = atof(s2);
    sum = sum + (time - ave) * (time - ave);
    numdata++;
  }
  *var = sum / (float)numdata;
}
