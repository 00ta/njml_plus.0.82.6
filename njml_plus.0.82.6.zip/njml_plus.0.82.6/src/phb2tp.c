/* Feb 26 - Sep 24, 2000 */
/* phb2tp converts a phb file to a topology file */

#define MAIN_MODULE 1
#include "protml.h"

void getbstree(FILE *, cvector, int);
void get_open_par(char **, int *, int *, char**);
void remove_distance(char **, int *, int *, char**);
void remove_bs(char **, int *, int *, char**);
void set_strtree(char **, char **);
void set_strtree2(char **, char **);
void get_others(char **cp, int *, int *, char **np);
void get_strtree(int *, int *, char **);

int main(argc, argv)
int argc;
char **argv;
{
  FILE *ifp, *tplfp;
  int buftree;
  char *comment;
  ivector alias;

  /* Open files for sequence data and  topologies */
  if ((ifp = fopen(argv[1], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n",argv[0],argv[1]);
  if ((tplfp = fopen(argv[2], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n",argv[0],argv[2]);
  
  /* Get size of sequence data */
  getsize(ifp, &Maxspc, &Maxsite, &comment);

  /* Allocate memory space for names of sequence data */
  Identif = (char **)malloc((unsigned)Maxspc * sizeof(char *));
  if (Identif == NULL) maerror("in tree");

  /* Allocate memory space for sequene data */
  Seqchar = new_cmatrix(Maxspc, Maxsite);

  /* Get sequence data */
  /*
  getseqs(ifp, Identif, Seqchar, Maxspc, Maxsite);
  */
  getseqi(ifp, Identif, Seqchar, Maxspc, Maxsite);

  /* Allocate memory space for a topology represented by a string */
  buftree =  getbuftree(Maxspc, Identif) + 50000;  /* ad hoc! */
  Strtree = new_cvector(buftree);
  /* Some preparations for making trees */  
  getfreqepm(Seqchar, Freqemp, Maxspc, Maxsite);
  alias = new_ivector(Maxsite);
  radixsort_njml(Seqchar, alias, Maxspc, Maxsite, &Numptrn);
  Seqconint = new_imatrix(Maxspc, Numptrn);
  Weight = new_ivector(Numptrn);
  condenceseq(Seqchar, alias, Seqconint, Weight, Maxspc, Maxsite, Numptrn);
  convseq(Seqconint, Maxspc, Numptrn);
  
  Maxbrnch = 2 * Maxspc - 3;
  Maxibrnch = Maxspc - 3;
  Maxpair = (Maxspc * (Maxspc - 1)) / 2;

  Numspc = Maxspc;
  Numbrnch = Maxbrnch;
  Numpair = Maxpair;
  Numsite = Maxsite;
  Numibrnch = Numspc - 3;
  Converg = TRUE;
  Numit = 0;

  Ctree = (Tree *) new_tree(Maxspc, Maxibrnch, Numptrn, Seqconint);

  /* Get a topology */
  getbstree(tplfp, Strtree, buftree);
  /*
  printf("%s\n", Strtree);
  */
  puts(Strtree);

  return 0;
}

void
getbstree(ifp, strtree, buftree)
FILE *ifp;
cvector strtree;
int buftree;
{
	char line[BUFLINE];
	char *cp; /* Input chars */
	char *np, *nnp; /* String Stree (Strtree) */
	char *bs; /* Bootstrap values */
	char *ds; /* Distances */
	int par1, par2, bra1, bra2;
	dvector *branchlens, *bsvalues;
	cvector strtree_work;

	if (Debug) printf("buftree = %5d\n", buftree);
	par1 = 0; par2 = 0;
	bra1 = 0; bra2 = 0;
	strtree_work = new_cvector(buftree);
	np = strtree_work;
	strtree_work[buftree - 1] = '\0';
	while (fgets(line, BUFLINE, ifp) != NULL) {
	  for (cp = line; (*cp != ';') && (*cp != '\n'); ) {
	    if (*cp != '\n') {
	      *np = *cp;
	      np++;
	    }
	    cp++;
	  }
	}
	*np = ';';
	np++;
	get_strtree(&par1, &par2, &np);

	nnp = strtree;
	strtree[buftree - 1] = '\0';	
	for (cp = strtree_work; *cp != ';'; ) {
	  get_open_par(&cp, &par1, &par2, &nnp);
	}
	get_strtree(&par1, &par2, &nnp);
	return;
} /*_ getbstree*/

void get_open_par(char **cp, int *par1, int *par2, char **np) {
    (*par1)++;
    set_strtree(cp, np);
    switch(**cp) { 
    case ':':
      remove_distance(cp, par1, par2, np);
      break;
    case ')':
      remove_bs(cp, par1, par2, np);
      break;
    case '(':
      get_open_par(cp, par1, par2, np);
      break;
    case '\n':
      break;
    default:
      get_others(cp, par1, par2, np);
      break;
    }
}

void remove_distance(char **cp, int *par1, int *par2, char **np) {
    for (; (**cp != ',') && (**cp != ')' ); (*cp)++) {
      /* Get distance */
    }
    if (**cp == ')' )
          (*par2)++;
    switch(**cp) { 
    case ')':
      remove_bs(cp, par1, par2, np);
      break;
    case '\n':
      break;
    default:
      get_others(cp, par1, par2, np);
      break;
    }
}

void remove_bs(char **cp, int *par1, int *par2, char **np) {
  set_strtree(cp, np);
  for (; (**cp != ':') && (**cp != ';'); (*cp)++) {
    /* Get bootstrap value */
  }
    switch(**cp) { 
    case ':':
      remove_distance(cp, par1, par2, np);
      break;
    case ';':
      set_strtree2(cp, np);
      break;
    case '\n':
      break;
    default:
      get_others(cp, par1, par2, np);
      break;
    }
}

void get_others(char **cp, int *par1, int *par2, char **np) {
    set_strtree(cp, np);
    switch(**cp) { 
    case ':':
      remove_distance(cp, par1, par2, np);
      break;
    case ')':
      remove_bs(cp, par1, par2, np);
      break;
    case '(':
      get_open_par(cp, par1, par2, np);
      break;
    case '\n':
      break;
    default:
      get_others(cp, par1, par2, np);
      break;
    }
}

void set_strtree(char **cp, char **np) {
  **np = **cp;
  (*cp)++;
  (*np)++;
}

void set_strtree2(char **cp, char **np) {
  **np = **cp;
  (*np)++;
}

void get_strtree(int *par1, int *par2, char **np) {
  **np = '\0';
}


