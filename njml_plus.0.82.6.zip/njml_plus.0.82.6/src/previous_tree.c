/* Jan 20 - Feb 2, 2001 */

#include "protml.h"
#include "tools.h"
#define NS            1000
#define NBRANCH       (NS*2-2)
#define NCODE         64
#define boolean int

int ReadaTreeN2();

struct CommonInfo {
   char *z[2*NS-1], spname[NS][10], daafile[96];
   int ns,ls,npatt,*fpatt,np,ntime,ncode,clock,rooted,model,icode,cleandata;
   int seqtype, *pose;
   double kappa, omega, alpha, pi[64],*rates, *chunk, daa[20*20];
}  com;
struct TREEB {
   int nbranch, nnode, origin, branches[NBRANCH][2];
}  tree;
struct TREEN {
   int father, nson, sons[3], ibranch;
   double branch, divtime, omega, *lkl, daa[20*20];
}  nodes[2*NS-1];

extern char BASEs[],GenetCode[][64];

char treef[64];

boolean previous_tree(char *, char *, int);

boolean previous_tree(char *ctree, char *pretree, int numspc)
{
   int i,j,ntree, k,*nib, parti2B[NS], nsame, IBsame[NS],nIBsame[NS], lparti=0;
   char *partition, outf[32]="dT";
   FILE *ftree, *fout=(FILE*)fopen(outf,"w");
   double psame, mp, vp;

   com.ns = numspc;
   ntree = 2;
   if ((ftree=fopen (pretree,"r"))==NULL) error ("Tree file not found.");
   if(fout==NULL) error("outfile creation error");
   if(ntree<2) error("ntree");

   k = 1;

   lparti=(com.ns-1)*com.ns*sizeof(char);
   i=(k==1?2:ntree)*lparti;
   /*
   printf("\n%d bytes of space requested.\n", i);
   */
   partition=(char*)malloc(i);
   nib=(int*)malloc(ntree*sizeof(int));
   if (partition==NULL || nib==NULL) error("out of memory");

   ReadaTreeN2(ctree, &k, 1, numspc);
   nib[0]=tree.nbranch-com.ns;
   if (nib[0]==0) error("1st tree is a star tree..");
   BranchPartition (partition, parti2B);
   fputs ("Comparing the first tree with the others\nFirst tree:\n",fout);
   OutaTreeN(fout,0,0);  FPN(fout);  OutaTreeB(fout);  FPN(fout); 
   fputs ("\nInternal branches in the first tree:\n",fout);
   FOR(i,nib[0]) { 
     k=parti2B[i];
     fprintf(fout,"%3d (%2d..%-2d): ( ",
	     i+1,tree.branches[k][0]+1,tree.branches[k][1]+1);
     /*
     FOR(j,com.ns)
     */
     for (j=0; j < com.ns; j++)
       if(partition[i*com.ns+j])
	 fprintf(fout,"%d ",j+1);
     fputs(")\n",fout);
   }
   if(nodes[tree.origin].nson<=2) 
     fputs("\nRooted tree, results may not be correct.\n",fout);
   fputs("\nCorrect internal branches compared with the 1st tree:\n",fout);
   FOR(k,nib[0]) nIBsame[k]=0;
   for (i=1,mp=vp=0; i<ntree; i++,FPN(fout)) {
     ReadaTreeN (ftree, &k, 1); 
     nib[1]=tree.nbranch-com.ns;
     BranchPartition (partition+lparti, parti2B);
     nsame=NSameBranch (partition,partition+lparti, nib[0],nib[1],IBsame);

     psame=nsame/(double)nib[0];
     FOR(k,nib[0]) nIBsame[k]+=IBsame[k];
     fprintf(fout,"1 vs. %3d: %4d: ", i+1,nsame);
     FOR(k,nib[0]) if(IBsame[k]) fprintf(fout," %2d", k+1);
     /*
     printf("1 vs. %5d: %6d/%d  %10.4f\n", i+1,nsame,nib[0],psame);
     */
     vp += square(psame - mp)*(i-1.)/i;
     mp=(mp*(i-1.) + psame)/i;
   }
   vp=(ntree<=2 ? 0 : sqrt(vp/((ntree-1-1)*(ntree-1.))));
   fprintf(fout,"\nmean and S.E. of proportion of identical partitions\n");
   fprintf(fout,"between the 1st and all the other %d trees ", ntree-1);
   fprintf(fout,"(ignore these if not revelant):\n %.4f +- %.4f\n", mp, vp);
   fprintf(fout,"\nNumbers of times, out of %d, ", ntree-1);
   fprintf(fout,"interior branches of tree 1 are present");
   fputs("\n(This may be bootstrap support for nodes in tree 1)\n",fout);
   FOR(k,nib[0]) { 
     i=tree.branches[parti2B[k]][0]+1;  j=tree.branches[parti2B[k]][1]+1; 
     fprintf(fout,"%3d (%2d..%-2d): %6d (%5.1f%%)\n",
	     k+1,i,j,nIBsame[k],nIBsame[k]*100./(ntree-1.));
   }
   /*
   printf("\nResults in file %s\n", outf);
   */
   free(partition);  free(nib);  fclose(ftree);  fclose(fout);
   if (psame == 1.0)
     return 1;
   else
     return 0;
}

