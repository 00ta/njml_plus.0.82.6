#define MAIN_MODULE 1
#include "protml.h"

void getbstree(FILE *, cvector, int);
void get_strtree(int *, int *, char **);
void set_strtree(char **, char **);
void constructbstree(Tree*, cvector);
double get_distance(char **);
int get_bsvalue(char **);
Node *internalnode_bs(Tree*, char**, int*);
void set_option();
void pass_carriage_return(char **);
void resultbstree(Tree*);
void traverse(Tree*);
void print_bootstrap(Tree*);
void remove_low_bootstrap_branch(Tree *, int);
void remove_lowest_bootstrap_branch(Tree *);
void remove_lowbs_branches(Tree *);
void chk_bs(Tree *, Node *, int *);
Node *removeibranch2(Tree *, Node *);
void remove_lowest_bootstrap_branch2(Tree *);
void node_number(Tree *);
void game_tree(Tree *, FILE *);

int main(int argc, char**argv){
  FILE *ifp, *ofp1, *ofp2;
  int buftree, i, j, k;
  char *comment,c;
  ivector alias;
  cmatrix seqchar2;

  /* Open files for sequence data and  topologies */
  if ((ifp = fopen(argv[2], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n",argv[0], "init_nj_treefile2");
  if ((ofp1 = fopen("init_nj_treefile3", "w")) == NULL)
    fprintf(stderr,"%s: can't open %s\n",argv[0], "init_nj_treefile3");
  fprintf(ofp1," %s 1\n", argv[1]);
  c = fgetc(ifp);
  while ((c != EOF) && (c != ';')) {
    fputc(c, ofp1);
    c = fgetc(ifp);
  }  
  if (c == ';') {
    fputs(";\n", ofp1);
  }
  fclose(ifp);
  fclose(ofp1);

  if ((ofp2 = fopen("pamp.ctl", "w")) == NULL)
    fprintf(stderr,"%s: can't open %s\n",argv[0], "pamp.ctl");
  fputc('\n', ofp2);
  fprintf(ofp2,"    seqfile = %s * sequence data file name\n", argv[3]);  
  fprintf(ofp2,"    outfile = mp        * main result file\n");  
  fprintf(ofp2,"   treefile = %s  * tree structure file name\n", "init_nj_treefile3");
  fputc('\n', ofp2);
  fprintf(ofp2,"    seqtype = 2  * 0:nucleotides; 2:amino acids, 3:binary\n");
  fprintf(ofp2,"      ncatG = 8  * # of categories in the dG model of rates\n");
  fprintf(ofp2,"      nhomo = 0  * nonhomogeneous in calcualting P for branch\n");
  fclose(ofp2);
  return (0);
}

