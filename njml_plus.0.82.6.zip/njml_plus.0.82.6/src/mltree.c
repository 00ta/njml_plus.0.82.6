//
//  mltree.c
//  conbstree_plus
//
//  Created by Satoshi Oota on 3/27/14.
//  Copyright (c) 2014 Satoshi Oota. All rights reserved.
//

/*
 * mltree.c   Adachi, J.   1994.04.28
 * Copyright (C) 1992, 1993 J. Adachi & M. Hasegawa, All rights reserved.
 */

/* Modified by S. OOta      Mar 16, 2000 - Feb 2, 2001 */

/* Modification */
/* In tabletree3 previous_tree has a problem if sepecies names are
 non-number. So it was eliminated in ad hoc; Feb 2, 2001 */
/* In tabletree3 a previous tree (a tree in the previous step) is
 indicated; Jan 21, 2001 */
/* In tabletree3 likelihood values, standard errors, and differences
 to the best are written; Jan 18, 2001 */
/* tabletree2: The third argument bs_for_best returns a bootstap value
 for the best tree; Dec 18, 2000 */
/* Numibrnch was changed to Maxibrnch in int pathing(Tree*); Oct 14, 2000 */
/* Numibrnch was changed to Maxibrnch in int lslength(Tree*, dvector, int); Oct 10, 2000 */

#include "protml.h"
#define GAME_TEST 1

Tree *
new_tree(maxspc, maxibrnch, numptrn, seqconint)
int maxspc, maxibrnch, numptrn;
imatrix seqconint;
{
	int n, i;
	Tree *tr;
	Node *dp, *up;
    
	tr = (Tree *) malloc(sizeof(Tree));
	if (tr == NULL) maerror("tr in new_tree().");
        tr->ebrnchp = (Node **) malloc((unsigned)maxspc * sizeof(Node *));
        if (tr->ebrnchp == NULL) maerror("ebrnchp in new_tree().");
            tr->ibrnchp = (Node **) malloc((unsigned)maxibrnch * sizeof(Node *));
            if (tr->ibrnchp == NULL) maerror("ibrnchp in new_tree().");
                tr->bturn = new_ivector(maxspc);
                for (n = 0; n < maxspc; n++) {
                    tr->bturn[n] = n;
                    dp = (Node *) malloc(sizeof(Node));
                    if (dp == NULL) maerror("dp in new_tree().");
                    up = (Node *) malloc(sizeof(Node));
                    if (up == NULL) maerror("up in new_tree().");
                    dp->isop = NULL;
                    up->isop = NULL;
                    dp->kinp = up;
                    up->kinp = dp;
                    dp->descen = TRUE;
                    up->descen = FALSE;
                    dp->number = n;
                    up->number = n;
#if GAME_TEST
                    dp->inum = 0;
                    up->inum = 0;
#endif
                    dp->length = 0.0;
                    up->length = 0.0;
                    dp->lklhdl = 0.0;
                    up->lklhdl = 0.0;
                    dp->paths = new_ivector(maxspc);
                    up->paths = dp->paths;
                    for (i = 0; i < maxspc; i++) dp->paths[i] = 0;
                    dp->paths[n] = 1;
                    dp->eprob = seqconint[n];
                    up->eprob = NULL;
                    dp->iprob = NULL;
                    up->iprob = new_dmatrix(numptrn, Tpmradix);
                    tr->ebrnchp[n] = dp;
                }
	for (n = 0; n < maxibrnch; n++) {
		dp = (Node *) malloc(sizeof(Node));
		if (dp == NULL) maerror("dp in new_tree().");
		up = (Node *) malloc(sizeof(Node));
		if (up == NULL) maerror("up in new_tree().");
		dp->isop = NULL;
		up->isop = NULL;
		dp->kinp = up;
		up->kinp = dp;
		dp->descen = TRUE;
		up->descen = FALSE;
		dp->number = n;
		up->number = n;
#if GAME_TEST
		dp->inum = 0;
		up->inum = 0;
#endif
		dp->length = 0.0;
		up->length = 0.0;
		dp->lklhdl = 0.0;
		up->lklhdl = 0.0;
		dp->bootstrap = 0;
		up->bootstrap = 0;
		dp->step = 0;
		up->step = 0;
		dp->paths = new_ivector(maxspc);
		up->paths = dp->paths;
		for (i = 0; i < maxspc; i++) dp->paths[i] = 0;
		dp->eprob = NULL;
		up->eprob = NULL;
		dp->iprob = new_dmatrix(numptrn, Tpmradix);
		up->iprob = new_dmatrix(numptrn, Tpmradix);
		tr->ibrnchp[n] = dp;
	}
	tr->rootp = NULL;
    
	return tr;
} /*_ new_tree */


int
getbuftree(numspc, identif)
int numspc;
cmatrix identif;
{
	int i, buf;
    
	buf = numspc * 3 - 3;
	for (i = 0; i < numspc; i++)
		buf += strlen(identif[i]);
        buf += (2 * numspc - 3) * 10; /* Branch length: up to 10 characters */
        buf += (numspc - 3) * 10; /* Bootstrap value: up to 10 characters */
        return buf;
} /*_ getbuftree */


void
changedistan(distanmat, distanvec, numspc)
dmatrix distanmat;
dvector distanvec;
int numspc;
{
	int i, j, k;
    
    Debug=TRUE;
    if (Debug) {
        printf("\n");
        for (i = 0; i < numspc; i++) {
            for (j = 0; j < numspc; j++) {
                printf("%5.1f", distanmat[i][j]);
            }
            printf("\n");
        }
    }
	for (k = 0, i = 1; i < numspc; i++) {
		for (j = 0; j < i; j++, k++) {
			distanvec[k] = distanmat[i][j];
            Debug=TRUE;
            if (Debug) {
                printf("distanmat[%d][%d]: %5.1f\n", i, j, distanmat[i][j]);
            }
        }
	}
}


void
getproportion(proportion, distanvec, maxpair)
double *proportion;
dvector distanvec;
int maxpair;
{
	int i;
	double maxdis;
    
	maxdis = 0.0;
	for (i = 0; i < maxpair; i++) {
		if (distanvec[i] > maxdis) {
			maxdis = distanvec[i];
		}
	}
	*proportion = (double)MAXCOLUMN / (maxdis * 3.0);
	if (*proportion > 1.0) *proportion = 1.0;
        if (Debug) printf("Proportion: %.5f   maxdis: %.5f\n", *proportion,maxdis);
            } /* getproportion */


Infotree *
newinfotrees(numtree, buftree)
int numtree;
int buftree;
{
	int i;
	Infotree *info;
	cvector m;
    
	info = (Infotree *) malloc((unsigned)numtree * sizeof(Infotree));
	if (info == NULL) maerror("in newinfotrees().");
        m = (cvector) malloc((unsigned)(numtree * buftree) * sizeof(char));
        if (m == NULL) maerror("2 in newinfotrees().");
            for (i = 0; i < numtree; i++, m+=buftree)
                info[i].ltplgy = m; /* Memory address */
                m = (cvector) malloc((unsigned)(numtree * buftree) * sizeof(char));
                for (i = 0; i < numtree; i++, m+=buftree)
                    info[i].tree_phb = m; /* Memory address */
                    
                    return info;
} /*_ newinfotrees */


Infoaltree *
newinfoaltrees(numaltree, buftree)
int numaltree;
int buftree;
{
	int i;
	Infoaltree *info;
	cvector m;
    
	info = (Infoaltree *) malloc((unsigned)numaltree * sizeof(Infoaltree));
	if (info == NULL) maerror("in newinfoaltrees().");
        m = (cvector) malloc((unsigned)(numaltree * buftree) * sizeof(char));
        if (m == NULL) maerror("2 in newinfoaltrees().");
            for (i = 0; i < numaltree; i++, m+=buftree)
                info[i].ltplgy = m;
                
                return info;
} /*_ newinfoaltrees */


void
getnumtree(ifp, numtree)
FILE *ifp;
int *numtree;
{
	char *cp;
	char line[BUFLINE];
    
	while (fgets(line, BUFLINE, ifp) != NULL) {
		/* fputs(line, ofp); */
		if (sscanf(line, "%d", numtree) == 1) {
			if (Verbs_optn && User_optn && !Aprox_optn)
				fprintf(stderr," %d trees  ", *numtree); /* stdout */
			return;
		} else {
			if (*line == '#')
				continue;
			for (cp = line; isspace(*cp) && *cp != '\0'; cp++)
                if (*cp != '\0') {
                    fputs(line, stderr);
                    fprintf(stderr,
                            "\nCan't read number of user trees, bad format.\n");
                    exit(1);
                } else {
                    continue;
                }
		}
	}
	fprintf(stderr, "\nCan't read number of user trees.\n");
	exit(1);
} /*_ getnumtree */


void
getusertree(ifp, strtree, buftree)
FILE *ifp;
cvector strtree;
int buftree;
{
	char line[BUFLINE];
	char *cp, *np;
	int par1, par2, bra1, bra2;
    
	if (Debug) printf("buftree = %5d\n", buftree);
        par1 = 0; par2 = 0;
        bra1 = 0; bra2 = 0;
        np = strtree;
        strtree[buftree - 1] = '\0';
        while (fgets(line, BUFLINE, ifp) != NULL) {
            for (cp = line; *cp != '\0'; cp++) {
                if (!isspace(*cp)) {
                    if (*cp == ';') {
                        if (np == strtree)
                            break; /* !? */
                        *np = '\0';
                        if (Debug) putchar('\n');
                        if (par1 != par2) {
                            fprintf(stderr, "Irregular parenthesis \"()\" number.\n");
                            fputs(strtree, stderr);
                            putc('\n', stderr);
                            exit(1);
                        }
                        return;
                    }
                    *np++ = *cp;
                    if (*cp == '(') par1++;
                    if (*cp == ')') par2++;
                    if (*cp == '{') bra1++;
                    if (*cp == '}') bra2++;
                    if (par1 == par2 && bra1 == bra2) {
                        *np = '\0';
                        return; /* !? */
                    }
                    if (np > (strtree + buftree - 2)) {
                        fprintf(stderr, "Too long, users tree.\n");
                        fprintf(stderr, "You may forget tree delimiter \";\".\n");
                        fputs(strtree, stderr);
                        putc('\n', stderr);
                        exit(1);
                    }
                    if (Debug) putchar(*cp);
                    
                }
            }
        }
	fprintf(stderr, "Can't read users trees of input file.\n");
	exit(1);
} /*_ getusertree */


Node *
internalnode(tr, chpp, ninode)
Tree *tr;    /* Tree */
char **chpp; /* Pointer to strtree */
int *ninode; /* Internal branch number */
{
	Node *xp, *np, *rp;
	int i, j, dvg;
	char ident[MAXWORD];
	char *idp;
    
	(*chpp)++;
	if (**chpp == '(') {
		if (Debug) printf("external: %c\n", **chpp);
		xp = internalnode(tr, chpp, ninode);
		xp->isop = xp;
		dvg = 1;
		while (**chpp != ')') {
			if (**chpp == '\0') {
				fputs("ERROR users tree, in internalnode 1\n", stderr);
				fputs(*chpp, stderr); fputc('\n', stderr);
				exit(1);
			}
			dvg++;
			np = internalnode(tr, chpp, ninode);
			np->isop = xp->isop;
			xp->isop = np;
			xp = np;
		}
		(*chpp)++;
		if (dvg < 2) {
			fputs("ERROR users tree, in internalnode 2\n", stderr);
			fputs(*chpp, stderr); fputc('\n', stderr);
			exit(1);
		}
		rp = tr->ibrnchp[*ninode];
		rp->isop = xp->isop;
		xp->isop = rp;
        
		/* Initialize paths of Node ibrnchp */
		for (j = 0; j < Numspc; j++)
			rp->paths[j] = 0;
		xp = rp->isop;
		/* Sync all paths of the internal nodes */
		while (xp != rp) {
			for (j = 0; j < Numspc; j++) {
				if (xp->paths[j] == 1)
					rp->paths[j] = 1;
			}
			xp = xp->isop;
		}
		if (Debug) {
			for (j = 0; j < Numspc; j++) printf("%2d",rp->paths[j]);
			putchar('\n');
		}
        
		(*ninode)++;
		return rp->kinp;
	} else if (isalnum(**chpp)) {
		if (Debug) printf("internal: %c\n", **chpp);
		for (idp = ident; **chpp != ',' && **chpp != ')' && **chpp != '\0'; (*chpp)++) {
			*idp++ = **chpp;
			if (Debug) putchar(**chpp);
		}
		*idp = '\0';
		if (Debug) putchar('\n');
		/* if (**chpp == ',') (*chpp)++; */
		/* puts(ident); */
		for (i = 0; i < Numspc; i++) {
			/* puts(Identif[i]); */
			if (!strcmp(ident, Identif[i])) {
				if (Debug) {
					for (j = 0; j < Numspc; j++)
						printf("%2d",tr->ebrnchp[i]->paths[j]);
					putchar('\n');
				}
				return tr->ebrnchp[i]->kinp;
			}
		}
		fputs("ERROR users tree, in internalnode 3\n", stderr);
		fputs(*chpp, stderr); fputc('\n', stderr);
		fprintf(stderr, "abnormal identifier(name): %s\n", ident);
		exit(1);
	} else {
		fputs("ERROR users tree, in internalnode 4\n", stderr);
		fputs(*chpp, stderr); fputc('\n', stderr);
		exit(1);
	}
	return NULL;
} /*_ internalnode */


void
constructtree(tr, strtree)
Tree *tr;
cvector strtree;
{
	char *chp;
	int ninode;
	int dvg;
	Node *xp, *np;
    
	ninode = 0;
	chp = strtree;
	/* puts(chp); */
	if (*chp == '(') {
		if (Debug) printf("roottre0: %c\n", *chp);
		xp = internalnode(tr, &chp, &ninode);
		xp->isop = xp;
		dvg = 1;
		while (*chp != ')') {
			if (*chp == '\0') {
				fprintf(stderr, "ERROR user tree, in constructtree 1\n");
				fputs(strtree, stderr);
				putc('\n', stderr);
				exit(1);
			}
			dvg++;
			if (Debug) printf("roottre1: %c\n", *chp);
			np = internalnode(tr, &chp, &ninode);
			np->isop = xp->isop;
			xp->isop = np;
			xp = np;
		}
		if (dvg < 2) {
			fputs("ERROR users tree, in constructtree 2\n", stderr);
			fputs(strtree, stderr);
			putc('\n', stderr);
			exit(1);
		}
		tr->rootp = xp;
		Numibrnch = ninode;
		Numbrnch = Numspc + ninode;
	} else {
		fprintf(stderr, "ERROR users tree, in constructtree 3\n");
		fputs(strtree, stderr);
		putc('\n', stderr);
		exit(1);
	}
} /*_ constructtree */


void
prcurtree(tr)
Tree *tr;
{
	Node *dp, *up, *cp;
	int i, j;
	double sum;
    
    /*	printf("\nStructure of Tree\n"); */
	printf("\n%4s%5s%5s%5s%7s%7s%37s\n",
           "num","kinp","isop","isop","descen","length", "namesp");
	for (i = 0; i < Numspc; i++) {
		dp = tr->ebrnchp[i];
		up = dp->kinp;
		printf("%4d", dp->number);
		printf("%5d", up->number);
		if (dp->isop == NULL) printf("%5s", "null");
		else                  printf("%5d", dp->isop->number);
		if (up->isop == NULL) printf("%5s", "null");
		else                  printf("%5d", up->isop->number);
		printf("%3d", dp->descen);
		printf("%3d", up->descen);
		printf("%8.3f", dp->length);
		printf("%8.3f", up->length);
		printf("%5d%5d", dp->eprob[0],dp->eprob[Numptrn-1]);
		for (sum = 0.0, j = 0; j < Tpmradix; j++) sum += up->iprob[0][j];
		printf("%5.0f", sum * 1000.0);
		for (sum = 0.0, j = 0; j < Tpmradix; j++) sum += up->iprob[Numptrn-1][j];
		printf("%5.0f", sum * 1000.0);
		printf("   %s", Identif[dp->number]);
		putchar('\n');
	}
	for (i = 0; i < Numibrnch; i++) {
		dp = tr->ibrnchp[i];
		up = dp->kinp;
		printf("%4d", dp->number);
		printf("%5d", up->number);
		if (dp->isop == NULL) printf("%5s", "null");
		else                  printf("%5d", dp->isop->number);
		if (up->isop == NULL) printf("%5s", "null");
		else                  printf("%5d", up->isop->number);
		printf("%3d", dp->descen);
		printf("%3d", up->descen);
		printf("%8.3f", dp->length);
		printf("%8.3f", up->length);
		for (sum = 0.0, j = 0; j < Tpmradix; j++) sum += dp->iprob[0][j];
		printf("%5.0f", sum * 1000.0);
		for (sum = 0.0, j = 0; j < Tpmradix; j++) sum += dp->iprob[Numptrn-1][j];
		printf("%5.0f", sum * 1000.0);
		for (sum = 0.0, j = 0; j < Tpmradix; j++) sum += up->iprob[0][j];
		printf("%5.0f", sum * 1000.0);
		for (sum = 0.0, j = 0; j < Tpmradix; j++) sum += up->iprob[Numptrn-1][j];
		printf("%5.0f", sum * 1000.0);
		for (cp = dp->isop; cp != dp; cp = cp->isop) {
			printf("%5d", cp->number);
		}
		putchar('\n');
	}
    dp = tr->rootp->isop;
    printf("%4d", dp->number);
    for (cp = dp->isop; cp != dp; cp = cp->isop) {
        printf("%5d", cp->number);
    }
    putchar('\n');
} /*_ prcurtree */


void
pathing(tr)
Tree *tr;
{
	int i, j;
	Node *rp, *cp, *xp;
#if 0
	for (i = 0; i < Numibrnch; i++) { /* !? */
#endif
        for (i = 0; i < Maxibrnch; i++) { /* !? */
            for (j = 0; j < Numspc; j++) {
                if (tr->ibrnchp[i]->paths == NULL) {
                    printf("%d %d\n", tr->ibrnchp[i]->number,
                           tr->ibrnchp[i]->kinp->number);
                    prcurtree(tr);
                    exit(1);
                }
                tr->ibrnchp[i]->paths[j] = 0;
            }
        }
        rp = tr->rootp;
        cp = rp;
        do {
            if (cp->kinp->isop != NULL) {
                if (cp->descen) {
                    /*	printf("pathing: %4d\n", cp->number); */
                    for (xp = cp->isop; xp != cp; xp = xp->isop) {
                        for (i = 0; i < Numspc; i++) {
                            if (xp->kinp->paths[i])
                                cp->paths[i] = 1;
                        }
                    }
                }
                cp = cp->kinp->isop;
            } else {
                cp = cp->isop;
            }
        } while (cp != rp);
        /* */
        if (Debug_optn) {
            putchar('\n');
            for (i = 0; i < Maxibrnch; i++) {
                for (j = 0; j < Numspc; j++)
                    printf("%2d", tr->ibrnchp[i]->paths[j]);
                putchar('\n');
            }
        }
        /* */
    } /*_ pathing */
    
    
#if 0
    static void
    leastsquares(am, ym)
    dmatrix am;
    dvector ym;
    {
        int i, j, k;
        double pivot, element;
        dmatrix im;
        
        im = new_dmatrix(Numbrnch, Numbrnch);
        for (i = 0; i < Numbrnch; i++) {
            for (j = 0; j < Numbrnch; j++)
                im[i][j] = 0.0;
            im[i][i] = 1.0;
        }
        for (k = 0; k < Numbrnch; k++) {
            pivot = am[k][k];
            ym[k] /= pivot;
            for (j = 0; j < Numbrnch; j++) {
                am[k][j] /= pivot;
                im[k][j] /= pivot;
            }
            for (i = 0; i < Numbrnch; i++) {
                if (k != i) {
                    element = am[i][k];
                    ym[i] -= element * ym[k];
                    for (j = 0; j < Numbrnch; j++) {
                        am[i][j] -= element * am[k][j];
                        im[i][j] -= element * im[k][j];
                    }
                }
            }
        }
        /*
         putchar('\n');
         for (i = 0; i < Numbrnch; i++) {
         for (j = 0; j < Numbrnch; j++)
         printf("%10.6f", im[i][j]);
         putchar('\n');
         }
         */
        free_dmatrix(im);
    } /*_ leastsquares */
#endif
    
    
    static int
    luequation(amat, yvec, size)
    dmatrix amat;
    dvector yvec;
    int size;
    {
        /* SOLVE THE LINEAR SET OF EQUATIONS ON LU DECOMPOSITION */
        double eps = 1.0e-20; /* ! */
        int i, j, k, l, maxi, idx;
        double sum, tmp, maxb, aw;
        dvector wk;
        ivector index;
        
        wk = new_dvector(size);
        index = new_ivector(size);
        aw = 1.0;
        for (i = 0; i < size; i++) {
            maxb = 0.0;
            for (j = 0; j < size; j++) {
                if (fabs(amat[i][j]) > maxb)
                    maxb = fabs(amat[i][j]);
            }
#if 1
            if (maxb == 0.0) {
                fprintf(stderr, "luequation: singular matrix\n");
                return 1;
            }
#endif
            wk[i] = 1.0 / maxb;
        }
        for (j = 0; j < size; j++) {
            for (i = 0; i < j; i++) {
                sum = amat[i][j];
                for (k = 0; k < i; k++)
                    sum -= amat[i][k] * amat[k][j];
                amat[i][j] = sum;
            }
            maxb = 0.0;
            for (i = j; i < size; i++) {
                sum = amat[i][j];
                for (k = 0; k < j; k++)
                    sum -= amat[i][k] * amat[k][j];
                amat[i][j] = sum;
                tmp = wk[i] * fabs(sum);
                if (tmp >= maxb) {
                    maxb = tmp;
                    maxi = i;
                }
            }
            if (j != maxi) {
                for (k = 0; k < size; k++) {
                    tmp = amat[maxi][k];
                    amat[maxi][k] = amat[j][k];
                    amat[j][k] = tmp;
                }
                aw = -aw;
                wk[maxi] = wk[j];
            }
            index[j] = maxi;
            if (amat[j][j] == 0.0)
                amat[j][j] = eps;
            if (j != size - 1) {
                tmp = 1.0 / amat[j][j];
                for (i = j + 1; i < size; i++)
                    amat[i][j] *= tmp;
            }
        }
        
        l = -1;
        for (i = 0; i < size; i++) {
            idx = index[i];
            sum = yvec[idx];
            yvec[idx] = yvec[i];
            if (l != -1) {
                for (j = l; j < i; j++)
                    sum -= amat[i][j] * yvec[j];
            } else if (sum != 0.0)
                l = i;
            yvec[i] = sum;
        }
        for (i = size - 1; i >= 0; i--) {
            sum = yvec[i];
            for (j = i + 1; j < size; j++)
                sum -= amat[i][j] * yvec[j];
            yvec[i] = sum / amat[i][i];
        }
        free_ivector(index);
        free_dvector(wk);
        return 0;
    } /*_ luequation */
    
    
    int
    lslength(tr, distanvec, numspc) /* Compute least square branch lengths */
    Tree *tr;
    dvector distanvec;
    int numspc;
    {
        int i, i1, j, j1, j2, k, numibrnch, numbrnch, numpair;
        double sum, leng, alllen, rss;
        ivector pths;
        dmatrix atmt, atamt;
        Node **ebp, **ibp;
        
        Debug = TRUE;
        if (Debug) printf("numspc = %d\n", numspc);
        
        numibrnch = Maxibrnch;
        /*
         numibrnch = Numibrnch;
         */
        
        numbrnch = numspc + numibrnch;
        numpair = (numspc * (numspc - 1)) / 2;
        atmt = new_dmatrix(numbrnch, numpair);
        atamt = new_dmatrix(numbrnch, numbrnch);
        ebp = tr->ebrnchp;
        ibp = tr->ibrnchp;
        if (Debug) {
            putchar('\n');
            for (i = 0; i < numspc; i++) {
                for (j = 0; j < numspc; j++) printf("%2d",ebp[i]->paths[j]);
                putchar('\n');
            }
            for (i = 0; i < numibrnch; i++) {
                for (j = 0; j < numspc; j++) printf("%2d",ibp[i]->paths[j]);
                putchar('\n');
            }
        }
        
        for (i = 0; i < numspc; i++) {
            for (j1 = 1, j = 0; j1 < numspc; j1++) {
                if (j1 == i) {
                    for (j2 = 0; j2 < j1; j2++, j++) {
                        atmt[i][j] = 1.0;
                    }
                } else {
                    for (j2 = 0; j2 < j1; j2++, j++) {
                        if (j2 == i)
                            atmt[i][j] = 1.0;
                        else
                            atmt[i][j] = 0.0;
                    }
                }
            }
        }
        for (i1 = 0, i = numspc; i1 < numibrnch; i1++, i++) {
            pths = ibp[i1]->paths;
            for (j1 = 1, j = 0; j1 < numspc; j1++) {
                for (j2 = 0; j2 < j1; j2++, j++) {
                    if (pths[j1] != pths[j2])
                        atmt[i][j] = 1.0;
                    else
                        atmt[i][j] = 0.0;
                }
            }
        }
        
        if (Debug) {
            putchar('\n');
            for (i = 0; i < numpair; i++) {
                for (j = 0; j < numbrnch; j++)
                    printf("%2.0f",atmt[j][i]); /* Path */
                printf("%6.1f\n",distanvec[i]);
            }
        }
        Debug = FALSE;
#ifdef DIST
		putchar('\n');
		for (i = 0; i < numpair; i++)
			printf("%5.1f",distanvec[i]);
		putchar('\n');
#endif
        for (i = 0; i < numbrnch; i++) {
            for (j = 0; j <= i; j++) {
                for (k = 0, sum = 0.0; k < numpair; k++)
                    sum += atmt[i][k] * atmt[j][k];
                atamt[i][j] = sum;
                atamt[j][i] = sum;
            }
        }
        for (i = 0; i < numbrnch; i++) {
            for (k = 0, sum = 0.0; k < numpair; k++)
                sum += atmt[i][k] * distanvec[k];
            Brnlength[i] = sum;
        }
#if 0
        putchar('\n');
        for (i = 0; i < numbrnch; i++) {
            for (j = 0; j < numbrnch; j++)
                printf("%5.1f", atamt[i][j]);
            printf("%7.3f",Brnlength[i]);
            putchar('\n');
        }
#endif
#if 1
        if(luequation(atamt, Brnlength, numbrnch)) {
            puts("luequation return 1");
            return 1;
        }
#endif
#if 0
        putchar('\n');
        for (i = 0; i < numbrnch; i++) {
            for (j = 0; j < numbrnch; j++)
                printf("%5.1f", atamt[i][j]);
            printf("%7.3f",Brnlength[i]);
            putchar('\n');
        }
#endif
        if (Debug) {
            for (i = 0; i < numbrnch; i++) {
                printf("%7.3f",Brnlength[i]);
            } putchar('\n');
        }
        for (i = 0, rss = 0.0; i < numpair; i++) {
            sum = distanvec[i];
            for (j = 0; j < numbrnch; j++) {
                if (atmt[j][i] == 1.0 && Brnlength[j] > 0.0)
                    sum -= Brnlength[j];
            }
            rss += sum * sum;
        }
        tr->rssleast = sqrt(rss); /* divided by the number of pairs ? */
        /* A residual value is computed here */
        Debug=TRUE;
        if (Debug) {
            for (i=0; i<numbrnch; i++) {
                printf("Brnlength[%d]: %f\n", i, Brnlength[i]);
            }
        }
        boolean Debug2=FALSE;
        if (Debug2) {
            for (i=0; i<numbrnch; i++) {
                Brnlength[i]=0.001;
            }
        }
        alllen = 0.0;
        for (i = 0; i < numspc; i++) {
            leng = Brnlength[i];
            /*	if (leng > 0.0) */
			alllen += leng;
            if (leng < MINARC) leng = MINARC;
            if (leng > MAXARC) leng = MAXARC;
            ebp[i]->length = leng;
            ebp[i]->kinp->length = leng;
            Brnlength[i] = leng;
        }
        for (i = 0, j = numspc; i < numibrnch; i++, j++) {
            leng = Brnlength[j];
            /*	if (leng > 0.0) */
			alllen += leng;
            if (leng < MINARC) leng = MINARC;
            if (leng > MAXARC) leng = MAXARC;
            ibp[i]->length = leng;
            ibp[i]->kinp->length = leng;
            Brnlength[j] = leng;
        }
        tr->tblength = alllen;
        free_dmatrix(atmt);
        free_dmatrix(atamt);
        return 0;
    } /*_ lslength */
    
    
    void
    resulttree(tr)
    Tree *tr;
    {
        int i, n, ne;
        Node *ep, *ip;
        
        printf("\nNo.%-3d", Cnotree + 1); /* offset */
        printf("%9s%7s%6s", "num","length","S.E.");
        printf("%8s%7s%6s", "num","length","S.E.");
        if (Info_optn) printf("%14s", "Likelihood");
        putchar('\n');
#if 0
        for (i = 0; i < 28; i++) putchar('-');
        for (i = 0; i <  5; i++) putchar(' ');
        for (i = 0; i < 16; i++) putchar('-'); putchar('\n');
#endif
        for (n = 0; n < Numspc; n++) {
            ep = tr->ebrnchp[n];
            ne = ep->number;
            fputid(stdout, Identif[ne], 10);
            fputs("  ", stdout);
            printf("%3d", ne + 1); /* offset */
            if (ep->length == MINARC)
                printf("%7s", "min");
            else if (ep->length == MAXARC)
                printf("%7s", "max");
            else
                printf("%7.2f", ep->length);
            printf("%6.2f", sqrt(ep->kinp->lklhdl));
            if (n < Numibrnch) {
                ip = tr->ibrnchp[n];
                printf("%8d", n + 1 + Numspc); /* offset */
                if (ip->length == MINARC)
                    printf("%7s", "min");
                else if (ip->length == MAXARC)
                    printf("%7s", "max");
                else
                    printf("%7.2f", ip->length);
                printf("%6.2f", sqrt(ip->kinp->lklhdl));
                /*	if (Info_optn) printf("%14.3f", ip->lklhdl); */
                putchar('\n');
            } else {
                if (n == Numspc - 3) {
                    if (!Converg)
                        printf("%36s%s\n", "", "non convergence!");
                    else if (Converg == 2)
                        printf("%6s%s\n", "", "just before convergence");
                    else
                        printf("%6s%2d\n", "", Numit);
                } else if (n == Numspc - 2) {
                    printf("%10s%11.2f +- %.2f\n", "ln L:",
                           tr->lklhd, sqrt(tr->varilkl));
                } else if (n == Numspc - 1) {
                    printf("%10s%11.2f\n", "AIC :",tr->aic);
                } else {
                    putchar('\n');
                }
            }
        }
    } /*_ resulttree */
    
    void
    resultbstree(tr)
    Tree *tr;
    {
        int i, n, ne;
        Node *ep, *ip;
        
        printf("\nNo.%-3d", Cnotree + 1); /* offset */
        /*
         printf("%9s%7s%6s", "num","length","S.E.");
         printf("%8s%7s%6s", "num","length","S.E.");
         */
        printf("%9s", "num");
        printf("%8s", "num");
        printf("%10s", "bootstrap");
        if (Info_optn) printf("%14s", "Likelihood");
        putchar('\n');
#if 0
        for (i = 0; i < 28; i++) putchar('-');
        for (i = 0; i <  5; i++) putchar(' ');
        for (i = 0; i < 16; i++) putchar('-'); putchar('\n');
#endif
        for (n = 0; n < Numspc; n++) {
            ep = tr->ebrnchp[n];
            ne = ep->number;
            fputid(stdout, Identif[ne], 10);
            fputs("  ", stdout);
            printf("%3d", ne + 1); /* offset */
            /*
             if (ep->length == MINARC)
             printf("%7s", "min");
             else if (ep->length == MAXARC)
             printf("%7s", "max");
             else
             printf("%7.2f", ep->length);
             printf("%6.2f", sqrt(ep->kinp->lklhdl));
             */
            if (n < Numibrnch) {
                ip = tr->ibrnchp[n];
                printf("%8d", n + 1 + Numspc); /* offset */
                /*
                 if (ip->length == MINARC)
                 printf("%7s", "min");
                 else if (ip->length == MAXARC)
                 printf("%7s", "max");
                 else
                 printf("%7.2f", ip->length);
                 printf("%6.2f", sqrt(ip->kinp->lklhdl));
                 */
                printf("%6d", ip->bootstrap);
                /*	if (Info_optn) printf("%14.3f", ip->lklhdl); */
                putchar('\n');
            } else {
                /*
                 if (n == Numspc - 3) {
                 if (!Converg)
                 printf("%36s%s\n", "", "non convergence!");
                 else if (Converg == 2)
                 printf("%6s%s\n", "", "just before convergence");
                 else
                 printf("%6s%2d\n", "", Numit);
                 } else if (n == Numspc - 2) {
                 printf("%10s%11.2f +- %.2f\n", "ln L:",
                 tr->lklhd, sqrt(tr->varilkl));
                 } else if (n == Numspc - 1) {
                 printf("%10s%11.2f\n", "AIC :",tr->aic);
                 } else {
                 putchar('\n');
                 }
                 */
                putchar('\n');
            }
        }
    } /*_ resultbstree */
    
    void
    resultbstree2(FILE *fout, Tree *tr)
    {
        int i, n, ne;
        Node *ep, *ip;
        
        printf("\nNo.%-3d", Cnotree + 1); /* offset */
        /*
         printf("%9s%7s%6s", "num","length","S.E.");
         printf("%8s%7s%6s", "num","length","S.E.");
         */
        printf("%9s", "num");
        printf("%8s", "num");
        printf("%10s", "bootstrap");
        if (Info_optn) printf("%14s", "Likelihood");
        putchar('\n');
#if 0
        for (i = 0; i < 28; i++) putchar('-');
        for (i = 0; i <  5; i++) putchar(' ');
        for (i = 0; i < 16; i++) putchar('-'); putchar('\n');
#endif
        for (n = 0; n < Numspc; n++) {
            ep = tr->ebrnchp[n];
            ne = ep->number;
            fputid(stdout, Identif[ne], 10);
            fputs("  ", stdout);
            printf("%3d", ne + 1); /* offset */
            /*
             if (ep->length == MINARC)
             printf("%7s", "min");
             else if (ep->length == MAXARC)
             printf("%7s", "max");
             else
             printf("%7.2f", ep->length);
             printf("%6.2f", sqrt(ep->kinp->lklhdl));
             */
            if (n < Numibrnch) {
                ip = tr->ibrnchp[n];
                printf("%8d", n + 1 + Numspc); /* offset */
                /*
                 if (ip->length == MINARC)
                 printf("%7s", "min");
                 else if (ip->length == MAXARC)
                 printf("%7s", "max");
                 else
                 printf("%7.2f", ip->length);
                 printf("%6.2f", sqrt(ip->kinp->lklhdl));
                 */
                printf("%6d", ip->bootstrap);
                putchar('\n');
                /*	if (Info_optn) printf("%14.3f", ip->lklhdl); */
                if (n == (Numibrnch - 1))
                    fprintf(fout,
                            "%6d\n", ip->bootstrap);
                else
                    fprintf(fout,
                            "%6d\t", ip->bootstrap);
            } else {
                /*
                 if (n == Numspc - 3) {
                 if (!Converg)
                 printf("%36s%s\n", "", "non convergence!");
                 else if (Converg == 2)
                 printf("%6s%s\n", "", "just before convergence");
                 else
                 printf("%6s%2d\n", "", Numit);
                 } else if (n == Numspc - 2) {
                 printf("%10s%11.2f +- %.2f\n", "ln L:",
                 tr->lklhd, sqrt(tr->varilkl));
                 } else if (n == Numspc - 1) {
                 printf("%10s%11.2f\n", "AIC :",tr->aic);
                 } else {
                 putchar('\n');
                 }
                 */
                putchar('\n');
            }
        }
    } /*_ resultbstree2 */
    
    
    void
    bootstrap(infotrs, lklptrn)
    Infotree *infotrs;
#ifdef LIGHT
    fmatrix lklptrn;
#else  /* LIGHT */
    dmatrix lklptrn;
#endif /* LIGHT */
    {
        int i, j, k, n, imax, lklmaxtree, nsite, nptrn, same, allsame;
        double lklmax, coefrand;
        ivector addweight;
        dvector boots;
        
        addweight = new_ivector(Numsite);
        for ( j = 0, k = 0; k < Numptrn; k++ ) {
            for ( i = 0, imax = Weight[k]; i < imax; i++ )
                addweight[j++] = k;
        }
        if (j != Numsite) {
            fputs("ERROR in bootstrap(), sum Weight != Numsite\n", stderr);
            exit(1);
        }
        
        coefrand = (double)Numsite / ((double)RANDOM_MAX + 1.0);
        boots = new_dvector(Numtree);
        allsame = 0;
        for (n = 0; n < Numtree; n++)
            infotrs[n].bsprob = 0;
        for (i = 0; i < NUMBOOTS; i++) {
            for (n = 0; n < Numtree; n++)
                boots[n] = 0.0;
            for (k = 0; k < Numsite; k++) {
                nsite = (int)( coefrand * (double)rand() ); /* RANDOM */
                nptrn = addweight[nsite];
                for (n = 0; n < Numtree; n++)
#ifdef LIGHT
                    boots[n] += (double)lklptrn[n][nptrn];
#else  /* LIGHT */
				boots[n] += lklptrn[n][nptrn];
#endif /* LIGHT */
            }
            lklmaxtree = 0;
            lklmax = boots[0];
            same = 0;
            for (n = 1; n < Numtree; n++) {
                if (boots[n] >= lklmax) {
                    if (boots[n] > lklmax) {
                        lklmaxtree = n;
                        lklmax = boots[n];
                        same = 0;
                    } else {
                        same++;
                    }
                }
            }
            allsame += same;
            infotrs[lklmaxtree].bsprob++;
            if (Debug_optn && i < 10)
                printf("%3d%4d%10.2f%6d%6d\n", i, lklmaxtree, lklmax, nptrn, nsite);
        }
        if (allsame > 0)
            printf("\nsame bootstrap likelihood occured %d times\n", allsame);
        free_dvector(boots);
        free_ivector(addweight);
    } /*_ bootstrap */
    
    
    void
    tabletree(infotrs, lklptrn)
    Infotree *infotrs;
#ifdef LIGHT
    fmatrix lklptrn;
#else  /* LIGHT */
    dmatrix lklptrn;
#endif /* LIGHT */
    {
        int i, k, maxi, n;
        double ldiff, suml1, suml2, sdlkl, nn1;
        Infotree *info;
#ifdef LIGHT
        fvector mlklptrn, alklptrn;
#else  /* LIGHT */
        dvector mlklptrn, alklptrn;
#endif /* LIGHT */
        
        maxi = 52;
        printf("\n%s %s \"%s\"", Prog_name, VERSION, Modelname);
        printf("  %d trees  %d OTUs %d sites\n\n", Numtree, Numspc, Numsite);
        printf("%4s%9s%11s%6s%6s%6s%10s",
               "Tree","ln L","Diff ln L","S.E.","#Para","AIC","Diff AIC");
        if (Boots_optn) printf("%8s", "Boot P");
        putchar('\n');
        for (i = 0; i < maxi; i++) putchar('-');
        if (Boots_optn) { for (i = 0; i < 8; i++) putchar('-'); }
        putchar('\n');
        mlklptrn = lklptrn[Maxlkltree]; /* Likelihood pattern of the maximum
                                         liklihood tree */
        nn1 = (double)(Numsite / (Numsite-1));
        for (n = 0; n < Numtree; n++) {
            info = &infotrs[n];
            alklptrn = lklptrn[n];
#if 0
            printf("Maxlkl = %f\n", Maxlkl);
#endif
            
            printf("%-4d%11.1f%8.1f", n+1, info->lklhd, info->lklhd - Maxlkl); /* offset */
#if 0 /* For accurate display */
            printf("%-4d%11.4f%8.4f", n+1, info->lklhd, info->lklhd - Maxlkl); /* offset */
#endif
            if(n == Maxlkltree) {
                fputs(" <-best",stdout);
            } else {
                for (suml1 = suml2 = 0.0, k = 0; k < Numptrn; k++) {
                    ldiff = alklptrn[k] - mlklptrn[k];
                    suml1 += ldiff * Weight[k];
                    suml2 += ldiff * ldiff * Weight[k];
                }
                suml1 /= Numsite;
                sdlkl = sqrt( nn1 * (suml2 - suml1*suml1*Numsite) );
                printf("%7.1f", sdlkl);
#if 0
                for (suml2 = 0.0, k = 0; k < Numptrn; k++) {
                    ldiff = alklptrn[k] - mlklptrn[k] - suml1;
                    suml2 += ldiff * ldiff * Weight[k];
                }
                sdlkl = sqrt( nn1 * suml2 );
                printf("%7.1f", sdlkl);
#endif
            }
            printf("%5d%10.1f%7.1f", info->npara, info->aic, info->aic - Minaic);
            if (Boots_optn)
                printf("%8.4f", (float) info->bsprob / NUMBOOTS);
            putchar('\n');
        }
    } /*_ tabletree */
    
    void
    tabletree2(infotrs, lklptrn, bs_for_best)
    Infotree *infotrs;
#ifdef LIGHT
    fmatrix lklptrn;
#else  /* LIGHT */
    dmatrix lklptrn;
#endif /* LIGHT */
    double *bs_for_best; /* Bootstrap value for the best tree */
    {
        int i, k, maxi, n;
        double ldiff, suml1, suml2, sdlkl, nn1;
        Infotree *info;
#ifdef LIGHT
        fvector mlklptrn, alklptrn;
#else  /* LIGHT */
        dvector mlklptrn, alklptrn;
#endif /* LIGHT */
        
        maxi = 52;
        printf("\n%s %s \"%s\"", Prog_name, VERSION, Modelname);
        printf("  %d trees  %d OTUs %d sites\n\n", Numtree, Numspc, Numsite);
        printf("%4s%9s%11s%6s%6s%6s%10s",
               "Tree","ln L","Diff ln L","S.E.","#Para","AIC","Diff AIC");
        if (Boots_optn) printf("%8s", "Boot P");
        putchar('\n');
        for (i = 0; i < maxi; i++) putchar('-');
        if (Boots_optn) { for (i = 0; i < 8; i++) putchar('-'); }
        putchar('\n');
        mlklptrn = lklptrn[Maxlkltree]; /* Likelihood pattern of the maximum
                                         liklihood tree */
        nn1 = (double)(Numsite / (Numsite-1));
        for (n = 0; n < Numtree; n++) {
            info = &infotrs[n];
            alklptrn = lklptrn[n];
#if 0
            printf("Maxlkl = %f\n", Maxlkl);
#endif
            
            printf("%-4d%11.1f%8.1f", n+1, info->lklhd, info->lklhd - Maxlkl); /* offset */
#if 0 /* For accurate display */
            printf("%-4d%11.4f%8.4f", n+1, info->lklhd, info->lklhd - Maxlkl); /* offset */
#endif
            if(n == Maxlkltree) {
                fputs(" <-best",stdout);
            } else {
                for (suml1 = suml2 = 0.0, k = 0; k < Numptrn; k++) {
                    ldiff = alklptrn[k] - mlklptrn[k];
                    suml1 += ldiff * Weight[k];
                    suml2 += ldiff * ldiff * Weight[k];
                }
                suml1 /= Numsite;
                sdlkl = sqrt( nn1 * (suml2 - suml1*suml1*Numsite) );
                printf("%7.1f", sdlkl);
#if 0
                for (suml2 = 0.0, k = 0; k < Numptrn; k++) {
                    ldiff = alklptrn[k] - mlklptrn[k] - suml1;
                    suml2 += ldiff * ldiff * Weight[k];
                }
                sdlkl = sqrt( nn1 * suml2 );
                printf("%7.1f", sdlkl);
#endif
            }
            printf("%5d%10.1f%7.1f", info->npara, info->aic, info->aic - Minaic);
            if (Boots_optn) {
                printf("%8.4f", (float) info->bsprob / NUMBOOTS);
                if (n == Maxlkltree)
                    *bs_for_best = (double) info->bsprob / NUMBOOTS;
            }
            putchar('\n');
        }
    } /*_ tabletree2 */
    
    void
    tabletree3(infotrs, lklptrn, bs_for_best, std_err_fp)
    Infotree *infotrs;
#ifdef LIGHT
    fmatrix lklptrn;
#else  /* LIGHT */
    dmatrix lklptrn;
#endif /* LIGHT */
    double *bs_for_best; /* Bootstrap value for the best tree */
    FILE *std_err_fp;
    {
        int i, j, k, maxi, n;
        double ldiff, suml1, suml2, sdlkl, nn1;
        Infotree **info, *cp, *bp, *op;
#ifdef LIGHT
        fvector mlklptrn, alklptrn;
#else  /* LIGHT */
        dvector mlklptrn, alklptrn;
#endif /* LIGHT */
        
        maxi = 52;
        printf("\n%s %s \"%s\"", Prog_name, VERSION, Modelname);
        fprintf(std_err_fp, "\n%s %s \"%s\"", Prog_name, VERSION, Modelname);
        printf("  %d trees  %d OTUs %d sites\n\n", Numtree, Numspc, Numsite);
        fprintf(std_err_fp, "  %d trees  %d OTUs %d sites\n\n", Numtree, Numspc, Numsite);
        printf("%4s%9s%11s%6s%6s%6s%10s",
               "Tree","ln L","Diff ln L","S.E.","#Para","AIC","Diff AIC");
        fprintf(std_err_fp, "%4s%9s%11s%6s%6s%6s%10s",
                "Tree","ln L","Diff ln L","S.E.","#Para","AIC","Diff AIC");
        if (Boots_optn) {
            printf("%8s", "Boot P");
            fprintf(std_err_fp, "%8s", "Boot P");
            putchar('\n');
            fputc('\n', std_err_fp);
        }
        for (i = 0; i < maxi; i++) {
            putchar('-');
            fputc('-', std_err_fp);
        }
        if (Boots_optn) {
            for (i = 0; i < 8; i++) putchar('-');
            for (i = 0; i < 8; i++) putc('-', std_err_fp);
        }
        putchar('\n');
        fputc('\n', std_err_fp);
        mlklptrn = lklptrn[Maxlkltree]; /* Likelihood pattern of the maximum
                                         liklihood tree */
        nn1 = (double)(Numsite / (Numsite-1));
        /* For sorting */
        info = (Infotree **)malloc((unsigned)Numtree * sizeof(Infotree *));
        if (info == NULL) maerror("in tableree3().");
        for (cp = Atail2.up, i = Numtree; cp != &Ahead2; cp = cp->up) {
            info[--i] = cp;
        }
        for (n = 0; n < Numtree; n++) {
            alklptrn = lklptrn[n];
#if 0
            printf("Maxlkl = %f\n", Maxlkl);
#endif
            
            printf("%-4d%11.1f%8.1f", n+1, info[n]->lklhd, info[n]->lklhd - Maxlkl); /* offset */
            
            fprintf(std_err_fp, "%-4d%11.1f%8.1f", n+1, info[n]->lklhd, info[n]->lklhd - Maxlkl);
            /* offset */
#if 0 /* For accurate display */
            printf("%-4d%11.4f%8.4f", n+1, info[n]->lklhd, info-[n]>lklhd - Maxlkl); /* offset */
            fprintf(std_err_fp, "%-4d%11.4f%8.4f", n+1, info[n]->lklhd, info-[n]>lklhd - Maxlkl); /* offset */
#endif
            if(n == 0) {
                fputs(" <-best",stdout);
                fputs(" <-best", std_err_fp);
            } else {
                for (suml1 = suml2 = 0.0, k = 0; k < Numptrn; k++) {
                    ldiff = alklptrn[k] - mlklptrn[k];
                    suml1 += ldiff * Weight[k];
                    suml2 += ldiff * ldiff * Weight[k];
                }
                suml1 /= Numsite;
                sdlkl = sqrt( nn1 * (suml2 - suml1*suml1*Numsite) );
                printf("%7.1f", sdlkl);
                
                fprintf(std_err_fp, "%7.1f", sdlkl);
#if 0
                for (suml2 = 0.0, k = 0; k < Numptrn; k++) {
                    ldiff = alklptrn[k] - mlklptrn[k] - suml1;
                    suml2 += ldiff * ldiff * Weight[k];
                }
                sdlkl = sqrt( nn1 * suml2 );
                printf("%7.1f", sdlkl);
#endif
	        }
            printf("%5d%10.1f%7.1f", info[n]->npara, info[n]->aic, info[n]->aic - Minaic);
            fprintf(std_err_fp, "%5d%10.1f%7.1f", info[n]->npara, info[n]->aic, info[n]->aic - Minaic);
            if (Boots_optn) {
                printf("%8.4f", (float) info[n]->bsprob / NUMBOOTS);
                fprintf(std_err_fp, "%8.4f", (float) info[n]->bsprob / NUMBOOTS);
                if (n == 0)
                    *bs_for_best = (double) info[n]->bsprob / NUMBOOTS;
            }
#if 0
            if (previous_tree(info[n]->ltplgy, "njmltree", Numspc)) {
                /* njmltree is the previous tree file */
                printf(" <-prev");
                fprintf(std_err_fp, " <-prev");
            }
#endif
            putchar('\n');
            fputc('\n', std_err_fp);
        }
    } /*_ tabletree3 */
    
    void
    tableinfo(infotrs)
    Infotree *infotrs;
    {
        int n;
        Infotree *info;
        
        putchar('\n');
        for (n = 0; n < Numtree; n++) {
            info = &infotrs[n];
            if (Boots_optn)
                printf("%.4f\t", (float) info->bsprob / NUMBOOTS);
            printf("%.1f\t%d\t", info->lklhd - Maxlkl, n+1); /* offset */
            puts(info->ltplgy);
        }
    } /*_ tableinfo */
    
    
    void
    rerootq(tr, numspc)
    Tree *tr;
    int numspc;
    {
        Node *cp, *rp, *op, *xp, *yp;
        int i;
        
        for (i = 0; i < numspc; i++) {
            if (tr->bturn[i] == numspc - 1)
                break;
        }
        rp = tr->ebrnchp[i]->kinp;
        tr->rootp = rp;
        cp = rp;
        do {
            cp = cp->isop->kinp;
            if (cp->isop == NULL) { /* external node */
                cp->descen = TRUE; /* Descendant */
                cp = cp->kinp;
                cp->descen = FALSE; /* Ancester */
            } else { /* internal node */
                if (cp->descen != -1) { /* -1: Tempororay root? */
                    cp->descen = TRUE;
                    cp->kinp->descen = -1; /* Set temporary
                                            root */
                    tr->ibrnchp[cp->number] = cp; /* ? */
                } else { /* Root? */
                    cp->descen = FALSE; /* Ancester */
                }
#if 0
                /* Renumber */
                if (!cp->descen) {
                    op = cp->kinp;
                    xp = op->isop;
                    yp = xp->isop;
                    /* Sort xp->number and yp->number */
                    if (xp->number > yp->number) {
                        op->isop = yp;
                        yp->isop = xp;
                        xp->isop = op;
                    }
                    cp->number = op->isop->number;
                    xp->number = xp->kinp->number;
                    yp->number = yp->kinp->number;
                }
#endif
            }
        } while (cp != rp);
#if 0
        /* Renumber */
        op = cp;
        xp = op->isop;
        yp = xp->isop;
        if (xp->number > yp->number) {
            op->isop = yp;
            yp->isop = xp;
            xp->isop = op;
        }
        xp->number = xp->kinp->number;
        yp->number = yp->kinp->number;
#endif
    } /* rerootq */
    
    
    void
    outlklhd(lklptrn)
#ifdef LIGHT
    fmatrix lklptrn;
#else  /* LIGHT */
    dmatrix lklptrn;
#endif /* LIGHT */
    {
        int i, j, k, l, maxk;
        
        fprintf(Lklfp, "%5d%5d\n", Numspc, Numsite);
        for (i = 0; i < Numtree; i++) {
            fprintf(Lklfp, "%5d\n", i + 1);
            for (j = 0, l = 0; j < Numptrn; j++) {
                for (k = 0, maxk = Weight[j]; k < maxk; k++, l++) {
                    fprintf(Lklfp, "%12.5e", lklptrn[i][j]);
                    if ((l+1) % 6 == 0) fputc('\n', Lklfp);
                }
            }
            if (l % 6 != 0) fputc('\n', Lklfp);
        }
    } /* outlklhd */
    
    
    void free_tree(Tree *tr, int maxspc, int maxibrnch)
    {
        int n;
        Node *dp, *up;
        
        for (n = 0; n < maxibrnch; n++) {
            dp = tr->ibrnchp[n];
            up = dp->kinp;
            free_dmatrix(up->iprob);
            free_dmatrix(dp->iprob);
            free(up);
            free(dp);
        }
        for (n = 0; n < maxspc; n++) {
            dp = tr->ebrnchp[n];
            up = dp->kinp;
            free_dmatrix(up->iprob);
            free_ivector(dp->paths);
            free(up);
            free(dp);
        }
        free_ivector(tr->bturn);
        free(tr->ibrnchp);
        free(tr->ebrnchp);
        free(tr);
    } /*_ new_tree */
    
