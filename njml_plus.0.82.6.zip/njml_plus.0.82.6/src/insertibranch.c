/* Insert an internal branch:
   Function void insertibranch(Tree * tree, Node * rp, Node * ip)
   inserts internal branch ip (ip, ip->kinp) to node rp  in tree
   tree */

#include "protml.h"

void insertibranch(Tree * tree, Node * rp, Node * ip) {
  Node *np;

  ip->kinp->isop = rp->isop;
  for (np = rp->isop; np != rp; np = np->isop) {
    if (np->isop == rp) {
      ip->isop = np;
      break;
    }
  }
  for (np = rp->isop; np != rp; np = np->isop) {
    if (np->isop->isop == rp) {
      np->isop = ip->kinp;
      break;
    }
  }
  rp->isop = ip;
}


