/* boolean *select_mltree(FILE *, char **) selects the maximum likelihood
   tree from candidates */
/* Size of tree (string tree) must be less than 63488, which
   is defined in protml.h (BUFLINE) */

#include "protml.h"

cvector new_cvector_test();

boolean select_mltree(FILE *ifp, FILE *ofp, char *mltree) {
    char line[BUFLINE], *cp, *np, *return_value;

    fgets(line, BUFLINE, ifp); /* Read header */
    fputs(line, ofp); /* Write header to check liklihood values */
    
    return_value = strstr(line, "1 / 1");
    
    np = mltree;
    while (fgets(line, BUFLINE, ifp) != NULL) {
        for (cp = line; (*cp != ';') && (*cp != '\n');) {
            *np++ = *cp++;
        }
        if (*cp == ';') {
            *np = *cp;
            *np++ = *cp++;
            break;
        }
    }
    *np = '\0';
    if (return_value == NULL) {
        return FALSE;
    } else {
        return TRUE;
    }
}
