#include <stdio.h>
#include <math.h>

float on(float, float);

int main() {
  printf("%30.30f\n", on(0.8, 2.0));
  return 0;
}

/* Ota and Nei distance */

float on(float p, float a) {
  float d;
  
  d = a / pow(1.0-p, 1.0/a) - a;
  return d;
}
