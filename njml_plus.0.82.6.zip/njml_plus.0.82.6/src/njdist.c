/*
 * tridist.c   Adachi, J.   1994.06.24
 * Copyright (C) 1993, 1994 J. Adachi & M. Hasegawa, All rights reserved.
 */

#define MAIN_MODULE 1
#include "tridist.h"


void
copyright()
{
#ifndef NJ
	fprintf(stderr, "TriDist %s (%s) ", VERSION, DATE );
	fprintf(stderr, "Triad Distance Phylogeny from Distance Matrix\n");
#else  /* NJ */
	fprintf(stderr, "NJDist %s (%s) ", VERSION, DATE );
	fprintf(stderr, "Neighbor Joining Phylogeny from Distance Matrix\n");
#endif /* NJ */
	fprintf(stderr, "Copyright (C) 1993, 1994 J. Adachi & M. Hasegawa; ");
	fprintf(stderr, "All rights reserved.\n");
#ifdef NJ
	fprintf(stderr, "Ref: N. Saitou & M. Nei 1987.");
	fprintf(stderr, " Molecular Biology and Evolution 4:406-425\n");
#endif /* NJ */
}


void
usage()
{
	copyright();
	fprintf(stderr, "Usage: %s [-%s] distance_matrix_file\t\t-h : help\n",
		Prog_name, SWITCHES);
	fprintf(stderr, "  or : protml -D sequence_file | %s [-%s]\n",
		Prog_name, SWITCHES);
}


void
helpinfo()
{
	copyright();
	fprintf(stderr,
		"Usage: %s [switches] distance_matrix_file\n",Prog_name);
	fprintf(stderr, "Switches:\n");
	fprintf(stderr, "-w      branch length\n");
	fprintf(stderr, "-l      Least squares\n");
	fprintf(stderr, "-S      Sequential input format (PHYLIP)\n");
	fprintf(stderr, "-O num  branch number of Out group \n");
	fprintf(stderr, "-T str  output Tree file name\n");
}

static void prologue();
static void distmethod();


main(argc, argv)
int argc;
char **argv;
{
	FILE *distfp, *treefp;
	int i, ch;
	char **cpp;
	char *tfilename;
	extern int Optindex;   /* index of next argument */
	extern char *Optargp;  /* pointer to argument of current option */

	if((Prog_name = strrchr(argv[0], DIR_CHAR)) != NULL )
		Prog_name++;
	else
		Prog_name = argv[0];

	while((ch = mygetopt(argc, argv, SWITCHES)) != -1 ) {
		switch(ch) {
		case 'l': Least_optn = TRUE;  break;
		case 'i': Info_optn  = TRUE;  break;
		case 'm': cpp = &Optargp;
		          Multi_optn = TRUE;
		          if (i = strtol(Optargp, cpp, 10)) Numexe = i; break;
		case 'v': Verbs_optn = TRUE;  break;
		case 'w': Write_optn = TRUE;  break;
		case 'S': Seque_optn = TRUE;  break;
		case 'O': Outgr_optn = TRUE;
				  cpp = &Optargp;
		          if (i = strtol(Optargp, cpp, 10)) Outgroup = i-1; break;
		case 'T': Tfile_optn = TRUE;
				  tfilename = Optargp;   break;
		case 'z': Debug_optn = TRUE;  break;
		case 'Z': Debug      = TRUE;  break;
		case 'h':
		case 'H': helpinfo(); exit(1);
		default : usage(); exit(1);
		}
	}
#ifdef DEBUG
	if (Debug) {
		printf("argc = %d\n",argc);
		for(i = 0; i < argc; i++) printf("argv[%d] = %s\n",i,argv[i]);
		putchar('\n');
		printf("\nOptindex = %d\n",Optindex);
		printf("Optargp = %s\n",Optargp);
	}
#endif
	if (Optindex == argc) {
		distfp = stdin;
	} else if (Optindex + 1 == argc) {
		if ((distfp = fopen(argv[Optindex++], "r")) == NULL) {
			fprintf(stderr,"%s: can't open %s\n",Prog_name,argv[--Optindex]);
			exit(1);
		}
	} else {
		fprintf(stderr, "%s: Inconsistent number of file in command line\n",
			Prog_name);
		usage();
		exit(1);
	}

	Cnoexe = 0;
	if (Verbs_optn) copyright();
	if (!Multi_optn) Numexe = 1;
	for (Cnoexe = 0; Cnoexe < Numexe; Cnoexe++) {
		prologue(distfp, stdout);
		distmethod(distfp, stdout);
	}
	if (distfp != stdin) fclose(distfp);

	if (Tfile_optn) {
		if ((treefp = fopen(tfilename, "w")) == NULL) {
			fprintf(stderr,"%s: can't open treefile: %s\n",Prog_name,tfilename);
			exit(1);
		} else {
			fputcphylogeny(treefp, Ctree);
			fclose(treefp);
		}
	}
	return 0;
}


static void
prologue(ifp, ofp)
FILE *ifp;
FILE *ofp;
{
	char *comment;

	getsize(ifp, &Numspc, &comment);
	if (!Multi_optn) header(ofp, &Numspc, &comment);
	Identif = (char **)malloc((unsigned)Numspc * sizeof(char *));
	if (Identif == NULL) maerror("in prologue, Identif");
	Sciname = (char **)malloc((unsigned)Numspc * sizeof(char *));
	if (Sciname == NULL) maerror("in prologue, Sciname");
	Distanmat = new_dmatrix(Numspc, Numspc);
	if (Seque_optn)
		getdatas(ifp, Identif, Distanmat, Numspc);
	else
		getdata(ifp, Identif, Sciname, Distanmat, Numspc);
	Maxbrnch = 2 * Numspc - 3;
	Numpair = (Numspc * (Numspc - 1)) / 2;
}


static void
distmethod(ifp, ofp)
FILE *ifp;
FILE *ofp;
{
	int n;

	if (Write_optn && Info_optn) prdistanmat(Distanmat, Numspc);
	if (Least_optn) Distanvec = new_dvector(Numpair);
	if (Least_optn) changedistan(Distanmat, Distanvec, Numspc);
	if (!Cnoexe) Ctree = (Tree *)newtree(Maxbrnch);
	if (Cnoexe) {
		for (n = 0; n < Maxbrnch; n++) {
			Ctree->brnchp[n]->length = 0.0;
			Ctree->brnchp[n]->kinp->length = 0.0;
		}
	}
	getproportion(&Proportion, Distanmat, Numspc);
	distantree(Ctree, Distanmat, Numspc);
	free_dmatrix(Distanmat);
	if (!Multi_optn) prtopology(Ctree);
	if (Least_optn) pathing(Ctree);
	if (Least_optn) Lengths = new_dvector(Numbrnch);
	if (Least_optn) lslength(Ctree, Distanvec, Lengths);
	if (!Multi_optn && Write_optn) resulttree(Ctree);
	if (!Multi_optn) putchar('\n');
	putctopology(Ctree);
	if (Least_optn) copylengths(Ctree, Lengths, Numbrnch);
	if (Debug_optn) putchar('\n');
	if (Debug_optn) fputcphylogeny(stdout, Ctree);
	if (Least_optn) free_dvector(Lengths);
	if (Least_optn) free_dvector(Distanvec);
	free_cmatrix(Identif);
	free_cmatrix(Sciname);
} /* distmethod */
