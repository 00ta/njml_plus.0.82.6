#include "protml.h"

void getsubtree(char **, char **);
void subtree_open_par(char **, int *, int *, char**);
void subtree_distance(char **, int *, int *, char**);
void subtree_bs(char **, int *, int *, char**);
void subtree_set_strtree(char **, char **);
void subtree_set_strtree2(char **, char **);
void subtree_others(char **cp, int *, int *, char **np);
void subtree_make_str(int *, int *, char **);
void subtree_first_char(char **, int *, int *, char **);
void subtree_second_char(char **, int *, int *, char **);

void getsubtree(char **tree, char **subtree) {
  char *np;
  int par1 = 0, par2 = 0;
  
  np = *subtree;

  subtree_first_char(tree, &par1, &par2, &np);
  subtree_make_str(&par1, &par2, &np);
}

void subtree_first_char(char **cp, int *par1, int *par2, char **np) {
  switch(**cp) { 
  case ':':
    subtree_distance(cp, par1, par2, np);
    break;
  case ')':
    subtree_bs(cp, par1, par2, np);
    break;
  case '(':
    subtree_open_par(cp, par1, par2, np);
    break;
  case ',':
    **cp = '(';
    subtree_open_par(cp, par1, par2, np);
    break;
  default:
    subtree_others(cp, par1, par2, np);
    break;
  }
}

void subtree_second_char(char **cp, int *par1, int *par2, char **np) {
  switch(**cp) { 
  case ':':
    subtree_distance(cp, par1, par2, np);
    break;
  case ')':
    subtree_bs(cp, par1, par2, np);
    break;
  case '(':
    subtree_open_par(cp, par1, par2, np);
    break;
  default:
    subtree_others(cp, par1, par2, np);
    break;
  }
}

void subtree_open_par(char **cp, int *par1, int *par2, char **np) {
    (*par1)++;
    /* Remove the first parenthesis */
    if (*par1 != 1)
      subtree_set_strtree(cp, np);
    else
      (*cp)++;
    switch(**cp) { 
    case ':':
      subtree_distance(cp, par1, par2, np);
      break;
    case ')':
      subtree_bs(cp, par1, par2, np);
      break;
    case '(':
      subtree_open_par(cp, par1, par2, np);
      break;
    default:
      subtree_others(cp, par1, par2, np);
      break;
    }
}

void subtree_distance(char **cp, int *par1, int *par2, char **np) {
    for (; (**cp != ',') && (**cp != ')' ); ) {
      /* Get distance */
      subtree_set_strtree(cp, np);
    }
    if (*par1 == (*par2 + 1))
      return;
    if (**cp == ')' )
          (*par2)++;
    switch(**cp) { 
    case ')':
      subtree_bs(cp, par1, par2, np);
      break;
    default:
      subtree_others(cp, par1, par2, np);
      break;
    }
}


void subtree_bs(char **cp, int *par1, int *par2, char **np) {
  subtree_set_strtree(cp, np);
  for (; (**cp != ':') && (**cp != ';'); ) {
    /* Get bootstrap value */
    subtree_set_strtree(cp, np);    
  }
    switch(**cp) { 
    case ':':
      subtree_distance(cp, par1, par2, np);
      break;
    case ';':
      subtree_set_strtree2(cp, np);
      break;
    default:
      subtree_others(cp, par1, par2, np);
      break;
    }
}

void subtree_others(char **cp, int *par1, int *par2, char **np) {
    subtree_set_strtree(cp, np);
    switch(**cp) { 
    case ':':
      subtree_distance(cp, par1, par2, np);
      break;
    case ')':
      subtree_bs(cp, par1, par2, np);
      break;
    case '(':
      subtree_open_par(cp, par1, par2, np);
      break;
    default:
      subtree_others(cp, par1, par2, np);
      break;
    }
}

void subtree_set_strtree(char **cp, char **np) {
  **np = **cp;
  (*cp)++;
  (*np)++;
}

void subtree_set_strtree2(char **cp, char **np) {
  **np = **cp;
  (*np)++;
}

void subtree_make_str(int *par1, int *par2, char **np) {
  **np = '\0';
}

boolean leaf2(char *subtree) {
  if (strstr(subtree, "(") == '\0')
    return TRUE;
  else
    return FALSE;
}

