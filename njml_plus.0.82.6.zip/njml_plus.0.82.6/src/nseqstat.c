/*
 * seqstat.c   Adachi, J.   1994.05.16
 * Copyright (C) 1993, 1994 J. Adachi & M. Hasegawa, All rights reserved.
 */

#include "protst.h"


void
seqinsdel(seqchar, numspc, numsite, insdel, numnoinsdel)
cmatrix seqchar;
int numspc, numsite;
ivector insdel;
int *numnoinsdel;
{
	int i, k, ninsdel;

	ninsdel = 0;
	for (k = 0; k < numsite; k++) {
		insdel[k] = FALSE;
		for (i = 0; i < numspc; i++) {
			if (seqchar[i][k] == Tpmradix) {
				insdel[k] = TRUE;
				ninsdel++;
				break;
			}
		}
	}
	*numnoinsdel = numsite - ninsdel;
} /* seqinsdel */


void
seqdiff(seqchar, numspc, numsite, insdel, numnoinsdel)
cmatrix seqchar;
int numspc, numsite;
ivector insdel;
int numnoinsdel;
{
	int i, j, k, x, y, z, dif1, dif2, maxk, numk;
	cvector seqchi, seqchj;
	imatrix diff;

	diff = new_imatrix(numspc, numspc);
	for (i = 0; i < numspc-1; i++) {
		seqchi = seqchar[i];
		for (j = i+1; j < numspc; j++) {
			seqchj = seqchar[j];
		/*	for (k=0;k<numsite;k++) printf("%2d",seqchj[k]); putchar('\n'); */
			for (k = 0, dif1 = 0, dif2 = 0; k < numsite; k++) {
				if (!insdel[k]) {
					if ((x = seqchi[k]) != (y = seqchj[k])) {
#ifndef NUC
						dif1++;
#else
						z = x + y;
						if ((z == 1) || (z == 5))
							dif1++;
						else
							dif2++;
#endif /* NUC */
					}
				}
			}
#ifndef NUC
			diff[i][j] = dif1;
			diff[j][i] = dif1;
#else
			diff[i][j] = dif1;
			diff[j][i] = dif2;
#endif /* NUC */
		}
		diff[i][i] = 0;
	}
	diff[numspc-1][numspc-1] = 0;
 
	printf("\nexcluding ins/del sites: %d\n", numnoinsdel);

	numk = 14;
	for (k = 0; maxk = k + numk, k < numspc; k += numk) {
		if (maxk > numspc) maxk = numspc;
		if (Tpmradix == NUMAMI)
			printf("\n%4s%5s", "","");
		else
			printf("\n%4s%-5s", " ","Ts");
		for (j = k; j < maxk; j++) printf("%5d", j + 1); putchar('\n');
		if (Tpmradix == NUMAMI)
			printf("%4s%5s", "","");
		else
			printf("%-4s%5s", "Tv","");
		for (j = k; j < maxk; j++) printf("%5.3s", Identif[j]); putchar('\n');
		for (i = 0; i < numspc; i++) {
			printf("%-4d%-5.5s", i + 1, Identif[i]);
			for (j = k; j < maxk; j++) {
				if (i != j)
					printf("%5d", diff[i][j]);
				else
					printf("%5.3s", Identif[i]);
			}
			putchar('\n');
		}
	}

	free_imatrix(diff);
} /* seqdiff */


void
seqfreq(seqchar, numspc, numsite, insdel, numnoinsdel)
cmatrix seqchar;
int numspc, numsite;
ivector insdel;
int numnoinsdel;
{
	int i, j, k, numfreq;
	cvector seqchi;
	imatrix freqs;
	ivector freq;
	ivector freqall;

	freqs = new_imatrix(numspc, Tpmradix + 1);
	freqall = new_ivector(Tpmradix + 1);
	for (j = 0; j < Tpmradix + 1; j++) freqall[j] = 0;
	for (i = 0; i < numspc; i++) {
		seqchi = seqchar[i];
		freq = freqs[i];
		for (j = 0; j < Tpmradix + 1; j++) freq[j] = 0;
		for (k = 0; k < numsite; k++) {
			if (!insdel[k])
				freq[seqchi[k]]++;
		}
		for (j = 0; j < Tpmradix + 1; j++) freqall[j] += freq[j];
	}

	if (Tpmradix == NUMAMI)
		numfreq = NUMAMI / 2;
	else
		numfreq = NUMNUC;
	printf("\n%9s", " ");
	if (Tpmradix == NUMAMI) {
		for (j = 0; j < numfreq; j++) printf("%3s%4s", Cacid1[j], Cacid3[j]);
	} else {
		for (j = 0; j < numfreq; j++) printf("%5s%2s", Cacid1[j], " ");
		printf("%7.4s%7.4s", "A&T ", "G&C ");
	}
	putchar('\n');
	for (i = 0; i < numspc; i++) {
		freq = freqs[i];
		printf("%-4d%-5.5s", i + 1, Identif[i]);
		for (j = 0; j < numfreq ; j++) {
			if (freq[j] != 0)
				printf("%7.3f", (double)freq[j] / numnoinsdel);
			else
				printf("%5.1f  ", (double)freq[j] / numnoinsdel);
		}
		if (Tpmradix == NUMNUC) {
			printf("%7.3f", (double)(freq[0]+freq[2]) / numnoinsdel);
			printf("%7.3f", (double)(freq[1]+freq[3]) / numnoinsdel);
		}
		putchar('\n');
	}
	printf("%4s%-5s", " ", "mean");
	for (j = 0; j < numfreq ; j++) {
		if (freqall[j] != 0)
			printf("%7.3f", (double)freqall[j] / (numspc * numnoinsdel));
		else
			printf("%5.1f  ", (double)freqall[j] / (numspc * numnoinsdel));
	}
	if (Tpmradix == NUMNUC) {
		printf("%7.3f", (double)(freqall[0]+freqall[2])/(numspc*numnoinsdel));
		printf("%7.3f", (double)(freqall[1]+freqall[3])/(numspc*numnoinsdel));
	}
	putchar('\n');

	if (Tpmradix == NUMAMI) {
	printf("\n%9s", " ");
	if (Tpmradix == NUMAMI) {
		for (j = numfreq; j < Tpmradix; j++)
			printf("%3s%4s", Cacid1[j], Cacid3[j]);
	} else {
		for (j = numfreq; j < Tpmradix; j++)
			printf("%5s%2s", Cacid1[j], " ");
	}
	putchar('\n');
	for (i = 0; i < numspc; i++) {
		freq = freqs[i];
		printf("%-4d%-5.5s", i + 1, Identif[i]);
		for (j = numfreq; j < Tpmradix ; j++) {
			if (freq[j] != 0)
				printf("%7.3f", (double)freq[j] / numnoinsdel);
			else
				printf("%5.1f  ", (double)freq[j] / numnoinsdel);
		}
		putchar('\n');
	}
	printf("%4s%-5s", " ", "mean");
	for (j = numfreq; j < Tpmradix ; j++) {
		if (freqall[j] != 0)
			printf("%7.3f", (double)freqall[j] / (numspc * numnoinsdel));
		else
			printf("%5.1f  ", (double)freqall[j] / (numspc * numnoinsdel));
	} putchar('\n');
	}

	free_ivector(freqall);
	free_imatrix(freqs);
} /* seqfreq */


void
seqtran(seqchar, numspc, numsite, insdel, numnoinsdel)
cmatrix seqchar;
int numspc, numsite;
ivector insdel;
int numnoinsdel;
{
	int i, j, k, numradix, ii, jj;
	cvector seqchi, seqchj;
	imatrix trans;
	ivector tran;
	ivector tranall;

	trans = new_imatrix(Tpmradix + 1, Tpmradix + 1);
	tranall = new_ivector(Tpmradix + 1);
	for (i = 0; i < Tpmradix + 1; i++) {
		for (j = 0; j < Tpmradix + 1; j++) trans[i][j] = 0;
		tranall[j] = 0;
	}
	for (i = 0; i < numspc - 1; i++) {
		seqchi = seqchar[i];
		for (j = i + 1; j < numspc; j++) {
			seqchj = seqchar[j];
			for (k = 0; k < numsite; k++) {
				if (!insdel[k]) {
					trans[seqchi[k]][seqchj[k]]++;
					trans[seqchj[k]][seqchi[k]]++;
				}
			}
		}
	}

	if (Tpmradix == NUMAMI)
		numradix = NUMAMI / 2;
	else
		numradix = NUMNUC;

	printf("\n%7s", " ");
	if (Tpmradix == NUMAMI) {
		for (j = 0; j < numradix; j++) printf("%3s%4s", Cacid1[j], Cacid3[j]);
	} else {
		for (j = 0; j < numradix; j++) printf("%5s%2s", Cacid1[j], " ");
	}
	putchar('\n');
	for (i = 0; i < Tpmradix; i++) {
		if (Tpmradix == NUMAMI) {
			printf("%3s%4s", Cacid1[i], Cacid3[i]);
		} else {
			printf("%5s%2s", Cacid1[i], " ");
		}
		for (j = 0; j < numradix ; j++) {
			printf("%7d", trans[i][j]);
		}
		putchar('\n');
	}

	if (Tpmradix == NUMAMI) {
	printf("\n%7s", " ");
	if (Tpmradix == NUMAMI) {
		for (j = numradix; j < Tpmradix; j++)
			printf("%3s%4s", Cacid1[j], Cacid3[j]);
	} else {
		for (j = numradix; j < Tpmradix; j++)
			printf("%5s%2s", Cacid1[j], " ");
	}
	putchar('\n');
	for (i = 0; i < Tpmradix; i++) {
		if (Tpmradix == NUMAMI) {
			printf("%3s%4s", Cacid1[i], Cacid3[i]);
		} else {
			printf("%5s%2s", Cacid1[i], " ");
		}
		for (j = numradix; j < Tpmradix ; j++) {
			printf("%7d", trans[i][j]);
		}
		putchar('\n');
	}
	}

#if 0
	for (i = 0; i < numspc - 1; i++) {
		seqchi = seqchar[i];
		for (j = i + 1; j < numspc; j++) {
			seqchj = seqchar[j];
			for (ii = 0; ii < Tpmradix + 1; ii++) {
				for (jj = 0; jj < Tpmradix + 1; jj++) trans[ii][jj] = 0;
			}
			for (k = 0; k < numsite; k++) {
				if (!insdel[k]) {
					trans[seqchi[k]][seqchj[k]]++;
					trans[seqchj[k]][seqchi[k]]++;
				}
			}

			printf("\n%-3d %-3d  %s  %s\n", i+1, j+1, Identif[i], Identif[j]);
			for (jj = 0; jj < Tpmradix; jj++) printf("%4s", Cacid1[jj]);
			putchar('\n');
			for (ii = 0; ii < Tpmradix; ii++) {
				printf("%1s", Cacid1[ii]);
				printf("%3d", trans[ii][0]);
				for (jj = 1; jj < Tpmradix ; jj++) {
					printf("%4d", trans[ii][jj]);
				}
				putchar('\n');
			}

		}
	}
#endif

	free_ivector(tranall);
	free_imatrix(trans);
} /* seqtran */
