#!/bin/csh
#setenv NJMLDIR ~/Documents/Projects/NJML/njml_plus.0.82;
setenv NJMLDIR /Users/oota/Documents/Projects/NJML/njml_plus.0.82.5
$NJMLDIR/src/njml_plus $NJMLDIR/src/njml_plus.ctl;
