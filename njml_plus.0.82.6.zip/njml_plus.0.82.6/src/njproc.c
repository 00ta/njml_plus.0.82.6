/*
 * procnj.c   Adachi, J.   1994.06.11
 * Copyright (C) 1993, 1994 J. Adachi & M. Hasegawa, All rights reserved.
 */

#include "tridist.h"

void
distantree(tr, distan, numspc)
Tree *tr;
dmatrix distan;
int numspc;
{
	int i, j, otui, otuj, otuk, nsp2, cinode, step, restsp;
	double dij, bix, bjx, bkx, sij, smax, smax2, q, dnsp2, diff, diffmax;
	ivector p1, p2;
	dvector s1, s2, r;
	Node **psotu, *cp, *ip, *jp, *kp;

	nsp2 = numspc - 2;
	dnsp2 = 1.0 / nsp2;
	cinode = numspc;
	r = new_dvector(numspc);
	s1 = new_dvector(numspc);
	s2 = new_dvector(numspc);
	p1 = new_ivector(numspc);
	p2 = new_ivector(numspc);
	psotu = (Node **)new_npvector(numspc);
	for (i = 0; i < numspc; i++) psotu[i] = tr->brnchp[i]->kinp;
	restsp = numspc;
	for (step = 0; restsp > 3; step++) {
		for (i = 0, q = 0.0; i < numspc; i++) {
			if (psotu[i] != NULL) {
				for (j = 0, r[i] = 0.0; j < numspc; j++) {
					if (psotu[j] != NULL)
						r[i] += distan[i][j];
				}
				q += r[i];
			}
			p1[i] = p2[i] = 0;
			s1[i] = s2[i] = 0.0;
		}
		if (Write_optn && Debug_optn) putchar('\n');
		for (i = 0, smax = 0.0, smax2 = 0.0; i < numspc-1; i++) {
			if (psotu[i] != NULL) {
				if (Write_optn && Debug_optn) {
					printf("%3d", i);
					for (j = 1; j < i+1; j++) fputs("    ",stdout);
				}
				for (j = i+1; j < numspc; j++) {
					if (psotu[j] != NULL) {
						sij = ( r[i] + r[j] ) * dnsp2 - distan[i][j];
					/*	sij = (distan[i][j] + (q - r[i] - r[j]) / nsp2) / 2.0;*/
					/*	sij = distan[i][j] * nsp2 - r[i] - r[j]; */
					/*	printf("%3d%3d %.5f %.5f %.5f\n", i,j,sij,r[i],r[j]); */
						if (sij > smax) {
							smax2 = smax;
							smax = sij;
							otui = i;
							otuj = j;
						} else if (sij > smax2) {
							smax2 = sij;
						}
						if (sij > s1[i]) {
							s2[i] = s1[i];
							p2[i] = p1[i];
							s1[i] = sij;
							p1[i] = j;
						} else if (sij > s2[i]) {
							s2[i] = sij;
							p2[i] = j;
						}
						if (sij > s1[j]) {
							s2[j] = s1[j];
							p2[j] = p1[j];
							s1[j] = sij;
							p1[j] = i;
						} else if (sij > s2[j]) {
							s2[j] = sij;
							p2[j] = i;
						}
						if (Write_optn && Debug_optn) printf("%4d", (int)(sij));
					}
				}
				if (Write_optn && Debug_optn) putchar('\n');
			}
		}
		for (i = 0, diffmax = 0.0; i < numspc; i++) {
			if (psotu[i] != NULL) {
				j = p1[i];
				if (i == p1[j] && i < j) {
					diff = (s1[i]-s2[i] + s1[j]-s2[j]) * 0.5;
#if 0
					if (diff > diffmax) {
						otui = i;
						otuj = j;
						diffmax = diff;
					}
#endif
#if 1
					if (Info_optn)
					printf("%3s%4d%4d%7.1f%4d%7.1f%4d%7.1f%7.1f%7.1f%7.1f\n",
						"",i,j,s1[i]-smax,p2[i],s2[i],p2[j],s2[j],
						s1[i]-s2[i], s1[j]-s2[j], diff);
#endif
				}
			/*	printf("%5d%5d%8.1f%5d%8.1f%8.1f\n",
					i,p1[i],s1[i],p2[i],s2[i],s1[i]-s2[i]); */

			}
		}
#if 0
		if (Info_optn)
			printf("%-3d%4d%4d%9.3f\n\n", cinode+1, otui, otuj, diffmax);
#endif
#if 1
		if (Info_optn)
			printf("%-3d%4d%4d%9.3f%9.3f\n",
			cinode+1,otui,otuj,smax-smax2,(smax-s2[otui]+smax-s2[otuj])*0.5);
#endif
		dij = distan[otui][otuj];
		bix = (dij + r[otui]/nsp2 - r[otuj]/nsp2) * 0.5;
		bjx = dij - bix;
		cp = tr->brnchp[cinode];
		ip = psotu[otui];
		jp = psotu[otuj];
		cp->isop = ip;
		ip->isop = jp;
		jp->isop = cp;
		ip->length += bix;
		jp->length += bjx;
		ip->kinp->length = ip->length;
		jp->kinp->length = jp->length;
		cp = cp->kinp;
		cp->length = dij * -0.5;
		psotu[otui] = cp;
		psotu[otuj] = NULL;
		for (j = 0; j < numspc; j++) {
			if (psotu[j] != NULL && j != otui) {
				dij = (distan[otui][j] + distan[otuj][j]) * 0.5;
				distan[otui][j] = dij;
				distan[j][otui] = dij;
			}
			distan[otuj][j] = 0.0;
			distan[j][otuj] = 0.0;
		}
		cinode++;
		Numbrnch = cinode;
		restsp--;
		nsp2--;
		dnsp2 = 1.0 / nsp2;
		if (Debug_optn) {
			for (putchar('\n'), i = 0; i < numspc; i++) {
				for (j = 0; j < numspc; j++)
					printf("%8.3f", distan[i][j]);
				putchar('\n');
			}
		}
	}

	otui = otuj = otuk = -1;
	for (i = 0; i < numspc; i++) {
		if (psotu[i] != NULL) {
			if (otui == -1)
				otui = i;
			else if (otuj == -1)
				otuj = i;
			else
				otuk = i;
		}
	}
	bix = (distan[otui][otuj] + distan[otui][otuk] - distan[otuj][otuk]) * 0.5;
	bjx = distan[otui][otuj] - bix;
	bkx = distan[otui][otuk] - bix;
	ip = psotu[otui];
	jp = psotu[otuj];
	kp = psotu[otuk];
	ip->isop = jp;
	jp->isop = kp;
	kp->isop = ip;
	ip->length += bix;
	jp->length += bjx;
	kp->length += bkx;
	ip->kinp->length = ip->length;
	jp->kinp->length = jp->length;
	kp->kinp->length = kp->length;
	tr->ablength = sij;
	if (Outgr_optn) {
		reroot(tr, tr->brnchp[Outgroup]->kinp);
	} else {
		tr->rootp = kp;
	}
	free_ivector(p2);
	free_ivector(p1);
	free_dvector(s2);
	free_dvector(s1);
	free_dvector(r);
	free_npvector(psotu);
} /*_ distantree */
