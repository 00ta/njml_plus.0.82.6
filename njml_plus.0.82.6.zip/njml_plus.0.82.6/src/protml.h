//
//  protml.h
//  conbstree_plus
//
//  Created by Satoshi Oota on 3/26/14.
//  Copyright (c) 2014 Satoshi Oota. All rights reserved.
//

#ifndef conbstree_plus_protml_h
#define conbstree_plus_protml_h

/*
 * protml.h   Adachi, J.   1994.06.30
 * Copyright (C) 1992-1994 J. Adachi & M. Hasegawa; All rights reserved.
 */

/* Modified by Satoshi Ota :- OOta.
 * March 1, 2000 - Jan 17, 2001
 */

#include "molphy.h"
#include "matrixut.h"

#define MAXARC     300.0   /* upper limit on branch length (subsutitutions) */
// Following molphy-2.3b3
#define MINARC     0.001   /* lower limit on branch length (subsutitutions) */
#define EPSILON    0.00001   /* stopping value of error (branch length) */
#define DEPSILON   0.0001  /* stopping value of error (distance) */
#define NUMBOOTS   1000    /* number of bootstrap resamplings */

#if 0
#define MAXIT      15      /* maximum number of iterates of smoothing */
#endif
#if 1
#define MAXIT      15000      /* maximum number of iterates of smoothing */
#endif

#define MINFREQ    0.005
#define NUMALTREES 100
#define NUMQLTREES 50
#define MAXQLBUF   9
#define MAXSLBUF   20
#define RSRATE     0.5
#define QRSRATE    1.15
#define SRSRATE    1.3
#define NUMAMI     20
#define NUMNUC     4

#ifdef TPM
#define MINRTF     1.0     /* 1.0e-3 TPM! */
#endif /* TPM */

#define LKLFILE     "lnlklhd.lkl"
#ifndef NUC
#define TPMRADIX    NUMAMI
#define INFOMOL     "Amino"
#define RTFINFILE   "prot.rtf"
#define RTFOUTFILE  "p.rtf"
#define LOGFILE     "Protml.log"
#else  /* NUC*/
#define TPMRADIX    NUMNUC
#define INFOMOL     "Nucleic"
#define RTFINFILE   "nuc.rtf"
#define RTFOUTFILE  "n.rtf"
#define LOGFILE     "Nucml.log"
#define ALPHABETA   4.0
#define ALPHAYR     1.0
#define MINAB       1.0
#define MAXAB       50.0
#define MINAYR      0.1
#define MAXAYR      5.0
#endif /* NUC*/

#define MAXCOLUMN  80
#define LINESITES  60
/*
 #define BUFLINE    512
 */
#define BUFLINE    63488
#define MAXWORD    32
#define MAXOVER    50
#define MAXLENG    30
#define MIDARC     100.0
#define NMLNGTH    10 /* max. num. of characters in species name with S or I */
// #define NMLNGTH    80
#define SWITCHES   "AbcCdDefFhHiIjlLm:n:pqQRrSst:TuvVwxzZ"
#define VERSION    "2.2"
#define DATE       "Jun 30 1994 - March 3 2000"
#define REPSILON    0.005   /* stopping value of error (local rearrangement) */
#define LOWERLIMIT  0.001   /* lower limit on branch length (subsutitutions) */
#define NUMBOOTSR   1000    /* number of bootstrap resamplings (reliability) */


typedef int       ivectpmty[TPMRADIX];
typedef double    dvectpmty[TPMRADIX];
typedef dvectpmty dmattpmty[TPMRADIX];

typedef struct node {
    struct node *isop;
    struct node *kinp;
    int descen;
    int inum;      /* ID of Node */
    int number;    /* ID of Branch */
    double length;  /* Branch length */
    double lklhdl;
    int bootstrap;  /* Bootstrap value */
    int step;  /* NJML step */
    double reliab;  /* Reliability of branch */
    ivector paths;
    ivector eprob;
    dmatrix iprob;
} Node;

typedef struct tree {
    Node *rootp;
    Node *firstp;
    Node **ebrnchp;
    Node **ibrnchp;
    double lklhd;
    double varilkl;
    double lklmin;
    double lklmean;
    double aic;
    double tblength;
    double tbldis;
    double rssleast; /* ratio (rate) of the current residural and
                      the minimum residural */
    int npara;
    int numorder;
    ivector bturn;
    ivector bootstrap_s;  /* Bootstrap values to be passed to
                           function wedge_njml */
} Tree;

typedef struct infotree {
	struct infotree *up;
	int npara;
	int bsprob;
	double lklhd;
	double varilkl;
	double lklaprox;  /* Not used */
	double lklbs;
	double aic;
	double tblength;
	double abdistan;
	char *ltplgy;
	char *tree_phb;
} Infotree;

typedef struct infoaltree {
	struct infoaltree *up;
	double lklaprox;
	double varilkl;
	double rss;
	char *ltplgy;
} Infoaltree;

typedef struct infoqltree {
	struct infoqltree *up;
	Node *ap;
	double lklaprox;
	double residual;
	dvector lengths;
} Infoqltree;

typedef struct infoaddtree {
	struct infoaddtree *dp;
	double lklaprox;
	int frequency;
	char *ltplgy;
} Infoaddtree;

typedef struct infosltree { /* Information of star decompostion tree? */
	struct infosltree *up; /* Other infosltree */
	Node *ibp; /* Node i of an internal branch */
	Node *jbp; /* Node j of the internal branch */
	double lklaprox; /* Approximate likelihood value */
	double residual; /* Residual of LS */
	dvector lengths; /* Branch lengths */
} Infosltree;

typedef struct myOption {
    char *seqfile;
    char *threshold;
    char *model;
    char *ts_tv;
    char *mode;
    char *n;
} MyOption;

extern char *Cacid1[];
extern char *Cacid3[];


#ifdef MAIN_MODULE

#define EXTERN
int Tpmradix = TPMRADIX;
char *Infomol = INFOMOL;

#else

#define EXTERN extern
EXTERN int Tpmradix;
EXTERN char *Infomol;

#endif


EXTERN FILE *Lklfp;
EXTERN FILE *Logfp;
EXTERN FILE *Rtfofp; /* TPM! */
EXTERN FILE *Rtfifp; /* TPM! */

EXTERN boolean Auto_optn;     /* a option  auto mode */
EXTERN boolean Aprox_optn;    /* A option  Approximate likelihood */
EXTERN boolean Boots_optn;    /* b option  no Bootstrap probability */
EXTERN boolean Ctacit_optn;   /* C option  taCiturnity */
EXTERN boolean Dayhf_optn;    /* d option  Dayhoff model */
EXTERN boolean Distn_optn;    /* D option  Distance matrix only */
EXTERN boolean Frequ_optn;    /* f option  with data frequency */
EXTERN boolean Logdet_optn;   /* F option  */
EXTERN boolean Inlvd_optn;    /* I option  interleaved input format */
EXTERN boolean Info_optn;     /* i option  */
EXTERN boolean Jtt_optn;      /* j option  JTT model */
EXTERN boolean Lklhd_optn;    /* l option  */
EXTERN boolean Logfl_optn;    /* L option  */
EXTERN boolean Multi_optn;    /* m option  multiple data sets */
EXTERN boolean Outlk_optn;    /* o option  */
EXTERN boolean Poisn_optn;    /* p option  Poisson process */
EXTERN boolean Quick_optn;    /* q option  quick mode */
EXTERN boolean Quick1_optn;   /* Q option  quick 1 mode */
EXTERN boolean Rrtf_optn;     /* r option  Read RTF, TPM! */
EXTERN boolean Semi_optn;     /* s option  semi-auto mode */
EXTERN boolean Seque_optn;    /* S option  PHYLIP Sequential input format */
EXTERN boolean Triad_optn;    /* T option  */
EXTERN boolean Tstv_optn;     /* t option  with decimal number */
EXTERN boolean Toptim_optn;   /* t option  without decimal number */
EXTERN boolean User_optn;     /* u option  designate user trees */
EXTERN boolean Verbs_optn;    /* v option  Verbose to stderr */
EXTERN boolean Varia_optn;    /* V option  Variance */
EXTERN boolean Write_optn;    /* w option  output sequence infomation */
EXTERN boolean Stard_optn;    /* x option  Star Decomposition */
EXTERN boolean Debug_optn;    /* z option  */
EXTERN boolean Debug;         /* Z option  */

#ifndef NUC
#else  /* NUC */
EXTERN double AlphaBeta;
EXTERN double AlphaYR;
#endif /* NUC */

EXTERN boolean Converg;
EXTERN boolean Topting;
EXTERN char *Prog_name;
EXTERN char Modelname[64];
EXTERN int Maxspc;
EXTERN int Numspc;
EXTERN int Maxibrnch;
EXTERN int Numibrnch;
EXTERN int Maxbrnch;
EXTERN int Numbrnch;
EXTERN int Maxpair;
EXTERN int Numpair;
EXTERN int Maxsite;
EXTERN int Numsite;
EXTERN int Numptrn;
EXTERN int Numtree;
EXTERN int Numaltree;
EXTERN int Numqltree;
EXTERN int Numaddtree;
EXTERN int Cnotree;
EXTERN int Maxlkltree;
EXTERN int Minaictree;
EXTERN int Numexe;
EXTERN int Cnoexe;
EXTERN int Numit;
EXTERN double Maxlkl;
EXTERN double Minaic;
EXTERN double Proportion;

EXTERN Tree *Ctree;
EXTERN Infotree *Infotrees;
EXTERN Infoaltree *Infoaltrees;
EXTERN Infoaltree Atail, Ahead;
EXTERN Infotree Atail2, Ahead2;
EXTERN Infoqltree *Infoqltrees;
EXTERN Infoqltree *Qtail, *Qhead;

EXTERN char **Identif;
EXTERN char **Sciname;
EXTERN cmatrix Seqchar;
EXTERN imatrix Seqconint;
EXTERN ivector Weight;
EXTERN dmatrix Distanmat;
EXTERN dvector Distanvec;
EXTERN dvector Brnlength;
EXTERN cvector Strtree;
EXTERN ivector Poolorder;

#ifdef LIGHT
EXTERN fmatrix Lklptrn;
EXTERN fvector Alklptrn;
#define LPVECTOR fvector
#define LPCUBE   fcube
#define NEW_LPCUBE    new_fcube
#define FREE_LPCUBE   free_fcube
#else  /* LIGHT */
#define LPVECTOR dvector
#define LPCUBE   dcube
#define NEW_LPCUBE    new_dcube
#define FREE_LPCUBE   free_dcube
EXTERN dmatrix Lklptrn;
EXTERN dvector Alklptrn;
#endif /* LIGHT */

EXTERN dvectpmty Freqemp;
EXTERN dvectpmty Freqtpm;
EXTERN dvectpmty Eval;
EXTERN dvectpmty Evl2;
EXTERN dmattpmty Evec;
EXTERN dmattpmty Ievc;

/* For reliabranch */
EXTERN boolean Relia_optn;    /* R option  Reliability of a branch */
EXTERN double Epsilon;
EXTERN ivector Relistat;
EXTERN dmatrix Reliprob;
EXTERN imatrix Relinum;
EXTERN FILE *Tplfp;
EXTERN double Llimit;
EXTERN boolean Xreli_optn;    /* X option  Reliability of a branch 2 */
EXTERN double Ulimit;

#ifdef TPM
EXTERN dmattpmty Rtf; /* TPM! */
EXTERN dmattpmty Tpm; /* TPM! */
EXTERN int Itpm; /* TPM! */
EXTERN int Jtpm; /* TPM! */
#endif /* TPM */

#ifndef DBL_MAX
#define DBL_MAX 1.7976931348623157e+308
#endif /* DBL_MAX */

#endif
