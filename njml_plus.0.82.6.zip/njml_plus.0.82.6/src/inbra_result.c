/* inbra result */
/* July 19, 2000 */

#define MAIN_MODULE 1
#include "protml.h"

void get_average(FILE *, int *, float *);
void get_variance(FILE *, float, float *);

int main(int argc, char *argv[])
{
  FILE *ifp;
  int numdata;
  float ave, var;

  if (argc != 2) {
    puts("result <Result file>");
    return 1;
  }

  /* Open a inbra_results file */ 
  if ((ifp = fopen(argv[1], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n", "result", argv[1]);
  get_average(ifp, &numdata, &ave);
  fclose(ifp);
  /* Open a results file */ 
  if ((ifp = fopen(argv[1], "r")) == NULL)
    fprintf(stderr,"%s: can't open %s\n", "result", argv[1]);
  get_variance(ifp, ave, &var);
  fclose(ifp);

  printf("# of data = %d\n", numdata);
  printf("Average = %f\n", ave);
  printf("Variance = %f\n", var);
  printf("SD = %f\n", sqrt(var));

  return 0;

}
  
void get_average(FILE *ifp, int *numdata, float *ave) {
  int i1, i2, i3, i4, i5;
  char line[BUFLINE];
  char s1[BUFLINE], s2[BUFLINE], s3[BUFLINE], s4[BUFLINE], s5[BUFLINE];
  float time, sum;

  *numdata = 0;
  sum = 0;
  for (; ;) {
    if (fgets(line, BUFLINE, ifp) == NULL)
      break;
    sscanf(line, "%s %s %s %s %s", s1, s2, s3, s4, s5);
    (*numdata)+=5;
    i1 = atoi(s1);
    i2 = atoi(s2);
    i3 = atoi(s3);
    i4 = atoi(s4);
    i5 = atoi(s5);
    sum += (i1 + i2 + i3 + i4 + i5);
  }
  *ave = sum / (float)*numdata;
}

void get_variance(FILE *ifp, float ave, float *var) {
  char line[BUFLINE];
  char s1[BUFLINE], s2[BUFLINE], s3[BUFLINE], s4[BUFLINE], s5[BUFLINE];
  int i1, i2, i3, i4, i5;
  int numdata;
  float time, sum;

  numdata = 0;
  sum = 0;
  for (; ;) {
    if (fgets(line, BUFLINE, ifp) == NULL)
      break;
    sscanf(line, "%s %s %s %s %s", s1, s2, s3, s4, s5);
    i1 = atoi(s1);
    i2 = atoi(s2);
    i3 = atoi(s3);
    i4 = atoi(s4);
    i5 = atoi(s5);
    sum = sum + (i1 - ave) * (i1 - ave) + (i2 - ave) * (i2 - ave)
      + (i3 - ave) * (i3 - ave) + (i4 - ave) * (i4 - ave)
      + (i5 - ave) * (i5 - ave);
    numdata+=5;
  }
  *var = sum / (float)numdata;
}








