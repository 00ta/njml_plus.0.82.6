//
//  molphy.h
//  conbstree_plus
//
//  Created by Satoshi Oota on 3/26/14.
//  Copyright (c) 2014 Satoshi Oota. All rights reserved.
//

#ifndef conbstree_plus_molphy_h
#define conbstree_plus_molphy_h

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <limits.h>
#include <time.h>

#define TRUE 1
#define FALSE 0

#define boolean int

#ifndef MSDOS
#define SW_CHAR  '-' /* switch charcter '-' (UNIX) */
#define DIR_CHAR '/' /* directory separator '/' (UNIX) */
#else
#define SW_CHAR  '/' /* switch charcter '/' (MSDOS) */
#define DIR_CHAR '\\' /* directory separator '\' (MSDOS) */
#endif

#ifdef RAND_MAX
#define RANDOM_MAX RAND_MAX
#else
#define RANDOM_MAX INT_MAX
#endif

#endif
