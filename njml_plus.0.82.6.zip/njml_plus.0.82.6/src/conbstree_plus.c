//
//  main.c
//  conbstree_plus
//
//  Created by Satoshi Oota on 3/26/14.
//  Copyright (c) 2014 Satoshi Oota. All rights reserved.
//

#define MAIN_MODULE 1
#define GAME_TEST 0
/*
 #define NUMREMOVE 3
 */
#define IMAGINARY_VALUE 9999

#include "protml.h"

void getbstree(FILE *, cvector, int);
void get_strtree(int *, int *, char **);
void set_strtree(char **, char **);
void constructbstree(Tree*, cvector);
double get_distance(char **);
int get_bsvalue(char **);
Node *internalnode_bs(Tree*, char**, int*);
void set_option();
void pass_carriage_return(char **);
void resultbstree(Tree*);
void traverse(Tree*);
void print_bootstrap(Tree*);
void remove_low_bootstrap_branch(Tree *, int);
void remove_lowest_bootstrap_branch(Tree *);
void remove_lowbs_branches(Tree *);
void chk_bs(Tree *, Node *, int *);
Node *removeibranch2(Tree *, Node *);
void remove_lowest_bootstrap_branch2(Tree *, int);
void node_number(Tree *);
float get_threshold(Tree *);
void put_threshold(float, char*);
Tree *new_tree();
void getsize();
void getseqi();
void getseqs2();
void removeibranch();
void rerootq();
char *fputcphylogeny3();

float Threshold; /* For removing internal branches */

int main(int argc, char**argv){
    FILE *ifp, *tplfp, *ofp, *ofp2;
    int buftree, numremove, n;
    char *comment;
    ivector alias;
    cmatrix seqchar2;
    
    /*
    argc=5;
    argv[1]="seq2";
    argv[2]="infile";
    argv[3]="90";
    argv[4]="A";
    argv[5]="1";
    */
    
    /* Open files for sequence data and  topologies */
    if ((ifp = fopen(argv[1], "r")) == NULL) {
        fprintf(stderr,"%s: can't open %s\n",argv[0],argv[1]);
        return -1;
    }
    if ((tplfp = fopen(argv[2], "r")) == NULL) {
        fprintf(stderr,"%s: can't open %s\n",argv[0],argv[2]);
        return -1;
    }
    
    /* Get size of sequence data */
    getsize(ifp, &Maxspc, &Maxsite, &comment);
    
    /* Allocate memory space for names of sequence data */
    Identif = (char **)malloc((unsigned)Maxspc * sizeof(char *));
    if (Identif == NULL) maerror("in tree");
    
    /* Allocate memory space for sequene data */
    Seqchar = new_cmatrix(Maxspc, Maxsite);   /* Conventional sequence format */
    /* Character-based sequence format */
    seqchar2 = new_cmatrix(Maxspc, Maxsite);
    
    
    /* Get sequence data */
    /*
     getseqs(ifp, Identif, Seqchar, Maxspc, Maxsite);
     */
    /* Get a sequence set in interleaved input format */
    getseqi(ifp, Identif, Seqchar, Maxspc, Maxsite);
    getseqs2(ifp, Identif, seqchar2, Maxspc, Maxsite);
    
//    int i;
//    for (i=0; i<Maxspc; i++){
//        printf("%s\n", Identif[i]);
//    }
    
    /* Allocate memory space for a topology represented by a string */
    int getbuftree();
    buftree =  getbuftree(Maxspc, Identif);
    buftree = buftree * 20; /* This Ad hoc! */
    Strtree = new_cvector(buftree);
    
    /* Some preparations for making trees */
    void getfreqepm();
    getfreqepm(Seqchar, Freqemp, Maxspc, Maxsite);
    alias = new_ivector(Maxsite);
    void radixsort_njml();
    radixsort_njml(Seqchar, alias, Maxspc, Maxsite, &Numptrn);
    Seqconint = new_imatrix(Maxspc, Numptrn);
    Weight = new_ivector(Numptrn);
    void condenceseq();
    condenceseq(Seqchar, alias, Seqconint, Weight, Maxspc, Maxsite, Numptrn);
    void convseq();
    convseq(Seqconint, Maxspc, Numptrn);
    
    Maxbrnch = 2 * Maxspc - 3;
    Maxibrnch = Maxspc - 3;
    Maxpair = (Maxspc * (Maxspc - 1)) / 2;
    
    Numspc = Maxspc;
    Numbrnch = Maxbrnch;
    Numpair = Maxpair;
    Numsite = Maxsite;
    Numibrnch = Numspc - 3;
    Converg = TRUE;
    Numit = 0;
    
    Ctree = (Tree *) new_tree(Maxspc, Maxibrnch, Numptrn, Seqconint);
    
    /* Get a topology */
    getbstree(tplfp, Strtree, buftree);
    puts(Strtree);
    constructbstree(Ctree, Strtree);
    /*
     printf("%s\n", Strtree);
     */
    void prtopology();
    prtopology(Ctree);
#if 0
    node_number(Ctree); /* Node numbering */
#endif
    resultbstree(Ctree);
    if ((ofp2 = fopen("inbravalue", "a")) == NULL)
        fprintf(stderr,"%s: can't open %s\n","conbstree", "inbravalue");
    void resultbstree2();
    resultbstree2(ofp2, Ctree);
    fclose(ofp2);
    
    /* Get threshold */
    if (strcmp(argv[3], "auto"))
        Threshold = atof(argv[3]);
    else {
        Threshold = get_threshold(Ctree);
        put_threshold(Threshold, "threshold");
    }
    
    printf("Threshold = %f\n", Threshold);
    
    /* For games (Takezaki) */
#if 0
    game_tree(Ctree);
#endif
    /*
     traverse(Ctree);
     print_bootstrap(Ctree);
     */
    numremove = atoi(argv[4]) - (Maxibrnch - Numibrnch);
    if (numremove < 0)
        return 1;
    for (n = 0; n < numremove; n++) {
        /*
         remove_lowest_bootstrap_branch2(Ctree);
         */
        remove_lowest_bootstrap_branch2(Ctree, atoi(argv[5]));
    }
    /*
     traverse(Ctree);
     */
    prtopology(Ctree);
    void rerootq();
    rerootq(Ctree, Numspc);
    resultbstree(Ctree);
    /*
     printf("%s\n", fputcphylogeny3(Ctree));
     */
    /* Open files for a tree file */
    if ((ofp = fopen("treefile", "w")) == NULL)
        fprintf(stderr,"%s: can't open %s\n",argv[0],argv[1]);
    fputs((char*)fputcphylogeny3(Ctree), ofp);
    fclose(ifp);
    fclose(tplfp);
    /* fclose(ofp); */ /* ? */
    printf("Used CPU time: %f in conbstree3\n", (double)clock() / CLOCKS_PER_SEC);
    return 0;
}

Node *
internalnode_bs(tr, chpp, ninode)
Tree *tr;    /* Tree */
char **chpp; /* Pointer to strtree */
int *ninode; /* Internal branch number */
{
	Node *xp, *np, *rp;
	int i, j, dvg, bootstrap;
	double distance;
	char ident[MAXWORD];
	char *idp;
    
	(*chpp)++;
	if (**chpp == '(') {
		if (Debug) printf("external: %c\n", **chpp);
		xp = internalnode_bs(tr, chpp, ninode);
		xp->isop = xp;
		dvg = 1;
		while (**chpp != ')') {
			if (**chpp == '\0') {
				fputs("ERROR users tree, in internalnode_bs 1\n", stderr);
				fputs(*chpp, stderr); fputc('\n', stderr);
				exit(1);
			}
			dvg++;
			np = internalnode_bs(tr, chpp, ninode);
			np->isop = xp->isop;
			xp->isop = np;
			xp = np;
		}
		bootstrap = get_bsvalue(chpp);
		distance = get_distance(chpp);
		/*
         printf("%d\n", bootstrap);
         printf("%f\n", distance(chpp));
         */
		if (dvg < 2) {
			fputs("ERROR users tree, in internalnode_bs 2\n", stderr);
			fputs(*chpp, stderr); fputc('\n', stderr);
			exit(1);
		}
		/* Make an internal branch (node): rp */
		rp = tr->ibrnchp[*ninode];
		rp->isop = xp->isop;
		xp->isop = rp;
		/* Bootstrap values must be the same
         in either directions */
		rp->bootstrap = bootstrap;
		rp->kinp->bootstrap = bootstrap;
		/* Distances must be the same
         in either directions */
		rp->length = distance;
		rp->kinp->length = distance;
		/* Set path to OTU */
		/* Initialize paths */
		for (j = 0; j < Numspc; j++)
			rp->paths[j] = 0;
		xp = rp->isop;
		/* Sync all paths of internal nodes */
		while (xp != rp) {
			for (j = 0; j < Numspc; j++) {
				if (xp->paths[j] == 1)
					rp->paths[j] = 1;
			}
			xp = xp->isop;
		}
		if (Debug) {
			for (j = 0; j < Numspc; j++) printf("%2d",rp->paths[j]);
			putchar('\n');
		}
        
		(*ninode)++;
		return rp->kinp;
	} else if (isalnum(**chpp)) {
		if (Debug) printf("internal: %c\n", **chpp);
		for (idp = ident; **chpp != ':' && **chpp != '\0'; (*chpp)++) {
			*idp++ = **chpp;
			if (Debug) putchar(**chpp);
		}
		switch(**chpp) {
            case ':':
                distance = get_distance(chpp);
                /*
                 printf("%f\n", distance);
                 */
                *idp = '\0';
                if (Debug) putchar('\n');
                /* if (**chpp == ',') (*chpp)++; */
                /* puts(ident); */
                for (i = 0; i < Numspc; i++) {
                    /* puts(Identif[i]); */
                    if (!strncmp(ident, Identif[i], NMLNGTH)) {
                        if (Debug) {
                            for (j = 0; j < Numspc; j++)
                                printf("%2d",tr->ebrnchp[i]->paths[j]);
                            putchar('\n');
                        }
                        /* Distances must be the same
                         in either directions */
                        tr->ebrnchp[i]->length = distance;
                        tr->ebrnchp[i]->kinp->length = distance;
                        return tr->ebrnchp[i]->kinp;
                    }
                }
            case '\0':
                fputs("ERROR users tree, in internalnode_bs 3\n", stderr);
                fputs(*chpp, stderr); fputc('\n', stderr);
                fprintf(stderr, "abnormal identifier(name): %s\n", ident);
                return NULL;
            default:
                fputs("ERROR users tree, in internalnode_bs 4\n", stderr);
                fputs(*chpp, stderr); fputc('\n', stderr);
                return NULL;
		}
	}
    return 0;
} /*_ internalnode_bs */


void
constructbstree(tr, strtree)
Tree *tr;
cvector strtree;
{
	char *chp;
	int ninode;
	int dvg;
	Node *xp, *np;
    
	ninode = 0;
	chp = strtree;
	/* puts(chp); */
	if (*chp == '(') {
		if (Debug) printf("roottre0: %c\n", *chp);
		xp = internalnode_bs(tr, &chp, &ninode);
		xp->isop = xp;
		dvg = 1;
		while (*chp != ')') {
			if (*chp == '\0') {
				fprintf(stderr, "ERROR user tree, in constructtree 1\n");
				fputs(strtree, stderr);
				putc('\n', stderr);
				exit(1);
			}
			dvg++;
			if (Debug) printf("roottre1: %c\n", *chp);
			np = internalnode_bs(tr, &chp, &ninode);
			np->isop = xp->isop;
			xp->isop = np;
			xp = np;
		}
		if (dvg < 2) {
			fputs("ERROR users tree, in constructtree 2\n", stderr);
			fputs(strtree, stderr);
			putc('\n', stderr);
			exit(1);
		}
		tr->rootp = xp;
		Numibrnch = ninode;
		Numbrnch = Numspc + ninode;
	} else {
		fprintf(stderr, "ERROR users tree, in constructtree 3\n");
		fputs(strtree, stderr);
		putc('\n', stderr);
		exit(1);
	}
} /*_ constructtree */

void
getbstree(ifp, strtree, buftree)
FILE *ifp;
cvector strtree;
int buftree;
{
	char line[BUFLINE];
	char *cp, *np;
	int par1, par2, bra1, bra2;
	    
	if (Debug) printf("buftree = %5d\n", buftree);
        par1 = 0; par2 = 0;
        bra1 = 0; bra2 = 0;
        np = strtree;
        strtree[buftree - 1] = '\0';
        while (fgets(line, BUFLINE, ifp) != NULL) {
            for (cp = line; (*cp != ';') && (*cp != '\n') && (*cp != (int) NULL);) {
                set_strtree(&cp, &np);
            }
            switch(*cp) {
                case ';':
                    set_strtree(&cp, &np);
                    get_strtree(&par1, &par2, &np);
                    return;
                case '\n':
                    pass_carriage_return(&cp);
                    break;
                case '\0':
                    break;
                default:
                    fputs("Something wrong, in getbstree\n", stderr);
            }
        }
} /*_ getbstree*/

void get_strtree(int *par1, int *par2, char **np) {
    **np = '\0';
}

void set_strtree(char **cp, char **np) {
    **np = **cp;
    (*cp)++;
    (*np)++;
}

int get_bsvalue(char **cp) {
    char bs[6]; /* Bootstrap value must be up to 999,999 */
    int i;
    
    (*cp)++; /* Skip ')' */
    for (i = 0; **cp != ':'; (*cp)++, i++) {
        bs[i] = **cp;
    }
    bs[i] = '\0';
    return atoi(bs);
}

void pass_carriage_return(char **cp) {
    (*cp)++;
}

void print_bootstrap(Tree *tr) {
    int i;
    
    for (i = 0; i < Numibrnch; i++) {
        printf("ibrnchp[%d]->bootstrap = %d\n", i, tr->ibrnchp[i]->bootstrap);
    }
}

void remove_low_bootstrap_branch(Tree *tr, int min_bootstrap) {
    int i;
    
    for (i = 0; i < Numibrnch; i++) {
        if (tr->ibrnchp[i]->bootstrap < min_bootstrap) {
            removeibranch(tr, i);
            rerootq(tr, Numspc);
        }
    }
}

void remove_lowest_bootstrap_branch(Tree *tr) {
    int i, j, current_bootstrap;
    /* Remove a branch having the lowest bootstrap value */
    i = 0;
    current_bootstrap = tr->ibrnchp[i]->bootstrap;
    j = i;
    for (i = 1; i < Numibrnch; i++) {
        if (tr->ibrnchp[i]->bootstrap < current_bootstrap) {
            current_bootstrap = tr->ibrnchp[i]->bootstrap;
            j = i;
        }
    }
    if (((float) current_bootstrap < Threshold ) &&
        (current_bootstrap >= 0))
        removeibranch(tr, j);
    rerootq(tr, Numspc);
}

void remove_lowest_bootstrap_branch2(Tree *tr, int step) {
    int i, j, current_bootstrap;
    
    /* Remove a branch having the lowest bootstrap value */
    i = 0;
    if (tr->ibrnchp[i]->bootstrap >=0) {
        current_bootstrap = tr->ibrnchp[i]->bootstrap;
    } else {
        current_bootstrap = 100;
    }
    j = i;
    for (i = 1; i < Numibrnch; i++) {
        if ((tr->ibrnchp[i]->bootstrap < current_bootstrap) &&
            (tr->ibrnchp[i]->bootstrap >= 0)) {
            current_bootstrap = tr->ibrnchp[i]->bootstrap;
            j = i;
        }
    }
    if (current_bootstrap < Threshold) {
        removeibranch(tr, j);
#if 1
        tr->ibrnchp[j]->bootstrap = -1 * step;  /* Imaginary value */
#endif
    }
    rerootq(tr, Numspc);
}

void remove_lowbs_branches(Tree *tr) {
    int i, j, current_bootstrap, numdel;
    /* Remove a branch having the lowest bootstrap value */
    i = 0;
    current_bootstrap = tr->ibrnchp[i]->bootstrap;
    j = i;
    for (i = 1; i < Numibrnch; i++) {
        if (tr->ibrnchp[i]->bootstrap < current_bootstrap) {
            current_bootstrap = tr->ibrnchp[i]->bootstrap;
            j = i;
        }
    }
    numdel = 0;
    if (current_bootstrap < Threshold ) {
        chk_bs(tr, tr->ibrnchp[j], &numdel);
        chk_bs(tr, tr->ibrnchp[j]->kinp, &numdel);
        removeibranch(tr, j);
    }
    rerootq(tr, Numspc);
}

void chk_bs(Tree *tr, Node *rp, int *numdel) {
    Node *cp;
    
    cp = rp->isop;
    do {
        if (cp->kinp->isop == NULL) /* External branch */
            cp = cp->isop;
        else {
            if ((cp->bootstrap < Threshold) && (*numdel < 2)) {
                cp = removeibranch2(tr, cp);
                (*numdel)++;
            } else
                cp = cp->isop;
        }
    } while ((cp != rp) && (*numdel < 2));
}

Node *removeibranch2(Tree * tree, Node *rp) {
    Node *cp, *np;
    
    for (cp = rp->isop; cp != rp; cp = cp->isop) {
        if (cp->isop == rp) {
            cp->isop = rp->kinp->isop;
            if (tree->rootp == rp)
                tree->rootp = cp->isop;
            break;
        }
    }
    np = rp->kinp->isop;
    rp = rp->kinp;
    for (cp = rp->isop; cp != rp; cp = cp->isop) {
        if (cp->isop == rp) {
            cp->isop = rp->kinp->isop;
            if (tree->rootp == rp)
                tree->rootp = cp->isop;
            break;
        }
    }
    /* Remove the internal branch completely */
    rp->isop = NULL;
    rp->kinp->isop = NULL;
    
    return np;
}

double get_distance(char **cp) {
    char length[12]; /* Length must be presented up to by 12 digits */
    int i;
    
    (*cp)++; /* Skip ':' */
    for (i = 0; (**cp != ',') && (**cp != ')' ); (*cp)++, i++) {
        /* Get distance */
        length[i] = **cp;
    }
    length[i] = '\0';
    return atof(length);
}

#if GAME_TEST
void node_number(Tree *tr) {
    Node *cp, *rp, *rp2;
    
    int wk_inum = Numspc;
    
    cp = rp = tr->rootp;
    do {
        cp = cp->isop->kinp;
        if (cp->isop == NULL) { /* external node */
            cp->inum = cp->number + 1;
            cp = cp->kinp;
        } else { /* internal node */
            rp2 = cp;
            cp->isop->inum = cp->inum;
            cp = cp->isop;
            while (cp != rp2) {
                cp->isop->inum = cp->inum;
                cp = cp->isop;
            }
            if (cp->inum == 0) {
                wk_inum++;
                cp->inum = wk_inum;
            }
            rp2 = cp;
            cp->isop->inum = cp->inum;
            cp = cp->isop;
            while (cp != rp2) {
                cp->isop->inum = cp->inum;
                cp = cp->isop;
            }
        }
    } while (cp != rp);
}
#endif

float get_threshold(Tree *tr) {
    float sum_bootstrap = 0.0;
    int numdata = 0, n;
    Node *ip;
    
    for (n = 0; n < Numibrnch; n++) {
        ip = tr->ibrnchp[n];
        if (ip->bootstrap < IMAGINARY_VALUE) {
            sum_bootstrap += (float) ip->bootstrap;
            numdata++;
        }
    }
    return sum_bootstrap/(float) numdata;
}

void put_threshold(float threshold, char *filename) {
    FILE *ofp;
    
    if ((ofp = fopen(filename, "w")) == NULL) {
        fprintf(stderr,"%s: can't open %s\n", "put_threshold", filename);
        exit (1);
    }
    fprintf(ofp, "%f", threshold);
    fclose(ofp);
}
