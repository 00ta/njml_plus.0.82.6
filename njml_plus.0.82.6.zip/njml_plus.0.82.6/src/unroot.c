#include "protml.h"

void unroot2(char **tree, char **urtree) {
  char *subtree1, *subtree2, *subtree3, *subtree4;

  subtree1 = new_cvector(5000); /* Ad hoc! */  
  subtree2 = new_cvector(5000); /* Ad hoc! */  
  subtree3 = new_cvector(5000); /* Ad hoc! */  
  subtree4 = new_cvector(5000); /* Ad hoc! */  

  getsubtree(tree, &subtree1);
  getsubtree(tree, &subtree2);

  if (leaf2(subtree1)) {
    getsubtree(&subtree2, &subtree3);
    getsubtree(&subtree2, &subtree4);

    strcpy(*urtree, "(");
    strcat(*urtree, subtree3);
    strcat(*urtree, ",");
    strcat(*urtree, subtree4);
    strcat(*urtree, ",");
    strcat(*urtree, subtree1);
    strcat(*urtree, ");");
  } else {
    getsubtree(&subtree1, &subtree3);
    getsubtree(&subtree1, &subtree4);

    strcpy(*urtree, "(");
    strcat(*urtree, subtree3);
    strcat(*urtree, ",");
    strcat(*urtree, subtree4);
    strcat(*urtree, ",");
    strcat(*urtree, subtree2);
    strcat(*urtree, ");");
  }
}


