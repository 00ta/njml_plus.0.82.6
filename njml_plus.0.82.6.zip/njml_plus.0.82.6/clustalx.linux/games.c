#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#define ACU  0.00000000001
#define ERR stderr
#define MAXSTATES 17

typedef struct nds{
  int nkey,nc;
  double height,dx,dy,x,y;
  struct nds *b, *lc,*rc;
  double *bbx,*blcx,*brcx;
  int *bstbx,*bstlcx,*bstrcx;
  int *bstbx1,*bstlcx1,*bstrcx1;
  char states[MAXSTATES];
  int nstate,amnflg;
  unsigned char *pbx,*plcx,*prcx;
} Nds;

struct com{
  int nseq,npc;
  unsigned char **part/*[MAXOTU-2][(MAXOTU-1)/8+1]*/;
  char **fl/*[MAXOTU][MAXNM]*/;
  int mr,ml,mb,*nlr/*[MAXOTU]*/,*nll/*[MAXOTU]*/,*nlb/*[MAXOTU]*/,bc,nlc;
  Nds *bt1,*bt2;
  int nsub,amnflg;
};
struct com comm;
Nds *nda/*[2*MAXOTU-2]*/,**adpart/*[MAXOTU-2]*/;
int dflg;
static char base[8]={'T','C','A','G','-','?','*','N'};
static char amn[24]={'A','C','D','E','F','G','H','I','K','L','M','N','P','Q',
                     'R','S','T','V','W','Y','-','?','*','X'};
rdtv(fp,nseqw,fl,nda,blen)
     Nds *nda/*[2*MAXOTU-2]*/;
     FILE *fp;
     int *nseqw;
     double *blen/*[2*MAXOTU-2]*/;
     char **fl/*[MAXOTU][MAXNM]*/;
{
  int i,j, rn,n,**ntb/*[2*MAXOTU-3][2]*/,nw,n1,n2,n3,bstn,nl;
  char b[1000],bw[200],bw1[200];
  float fw,fw1,fw2;
  extern int **imatrix();
  extern void free_imatrix();
  
  ntb = imatrix(comm.nseq*2-3,2);
  
  nl=0;
  
  for(i=0; i<200; i++){
    bw[i]=bw1[i]=0;
  }
  for( ; ; ){
    rn=rdline(fp,b,&n);
    nl++;
    /*     printf("nl=%d\n",nl); */
    if( rn == 2 ) continue;
    if( rn == 1 ){
      printf("first line read error\n");
      exit(1);
    }
    break;
  }
  
  sscanf(b,"%d %s %d %s\n",nseqw,bw,&bstn,bw1);
  if( strcmp(bw,"sequences") != 0 ){
    printf("first line invalid format\n");
    exit(1);
  }
  for(i=0; i<*nseqw ; i++){
    if( (rn=rdline(fp,b,&n)) != 0 ){
      printf("sequence names read error\n");
    }
    nl++;
    /*     printf("nl=%d\n",nl); */
    sscanf(b,"%d %s",&nw,bw);
    sscanf(b,"%d %s",&nw,bw);
    if( nw != i+1 ){
      printf("sequence number read error %d %d\n",nw,i+1);
      exit(1);
    }
    nw = strlen(bw);
    
    if( strcmp(fl[i],bw) != 0 ) {
      printf("sequence name inconsistency %d %s %s\n",i+1,fl[i],bw);
      exit(1);
    }
    /*       printf("bw %s fl %s\n",bw,fl[i]); */
  }
  /*  printf("bootstap =%d\n",comm.bstflg); */
  for(i=0; i< 2*(*nseqw)-3 ; i++){
    for( ; ; ){
      rn = rdline(fp,b,&n);
      nl++;
      /*        printf("nl=%d\n",nl); */
      if( rn == 2 ) continue;
      if( rn == 1 ){
	printf("format error\n");
	exit(1);
      }
      break;
    }
    /*
      if( i == 0 ){
      for(j=0; j<n ; j++){
      if( b[j] == '%' ) {
      comm.bstflg=2;
      break;
      }
      }
      }
      */
    /*      printf("comm.bstflg=%d\n",comm.bstflg); */
    sscanf(b,"%d and %d %f",&n1,&n2,&fw);
    ntb[i][0]=n1;
    ntb[i][1]=n2;
    blen[i]=fw;
  }
  
  rn=trnd(*nseqw,ntb,nda,blen);
  free_imatrix(ntb,comm.nseq*2-3,2);
  
  return(0);
}

brm(b,n)
     char b[];
{
  int i,psflg;
  psflg=0;
  for(i=0; i<n ; i++){
    if( b[i] == '%' ) psflg++;
    if( b[i] < 0x26 || b[i] > 0x7e ) b[i] = ' ';
  }
  if( psflg != 1 ){
    printf("invalid format in input file confidence level is assumed %d\n%s\n",psflg,b);
    exit(1);
  }
  return(0);
}


trnd(nseqw,ntb,nda,blen)
     int nseqw,**ntb/*[2*MAXOTU-3][2]*/;
     Nds *nda/*[2*MAXOTU-2]*/;
     double *blen/*[2*MAXOTU-2]*/;
{
  int i,j,k,n1,ns;
  
  for(i=0; i<2*nseqw-2; i++){
    nda[i].nkey = i+1;
    nda[i].lc=NULL;
    nda[i].rc=NULL;
    nda[i].b=NULL;
    nda[i].plcx=NULL;
    nda[i].prcx=NULL;
    nda[i].pbx=NULL;
    nda[i].blcx=NULL;
    nda[i].brcx=NULL;
    nda[i].bbx=NULL;
  }
  for(i=0; i<nseqw ; i++){
    ns=0;
    for(j=0; j<2*nseqw-3; j++){
      if( ntb[j][1] == i+1 ){
	nda[i].b = &nda[ntb[j][0]-1];
	nda[i].bbx = &blen[j];
	/*             printf(" %d %d %f\n",i+1,ntb[j][0],blen[j]); */
	ns++;
      }
      if( ntb[j][0] == i+1 ){
	nda[i].b = &nda[ntb[j][1]-1];
	nda[i].bbx = &blen[j];
	/*             printf(" %d %d %f\n",i+1,ntb[j][1],blen[j]); */
	ns++;
      }
    }
    if( ns != 1 ){
      printf("sequence %d format error\n",i+1);
    }
  }
  
  
  for( i=nseqw+1 ; i<= 2*nseqw-2 ; i++){
    ns=0;
    for(j=0; j<2*nseqw-3 ; j++){
      for(k=0; k<2 ; k++){
	if( ntb[j][k] == i ){
	  switch(k){
	  case 0: n1 = ntb[j][1];
	    break;
	  case 1: n1 = ntb[j][0];
	    break;
	  }
	  switch(ns){
	  case 0: nda[i-1].lc = &nda[n1-1];
	    nda[i-1].blcx = &blen[j];
	    break;
	  case 1: nda[i-1].rc = &nda[n1-1];
	    nda[i-1].brcx = &blen[j];
	    break;
	  case 2: nda[i-1].b = &nda[n1-1];
	    nda[i-1].bbx = &blen[j];
	    break;
	  default: printf("format error node%d ns=%d\n",i,ns);
	    exit(1);
	  }
	  ns++;  
	  break;
	}
      }
    }
    if( ns != 3 ){
      printf("format error node%d ns=%d\n",i,ns);
      exit(1);
    }
  }
  
  /*for(i=0; i<2*nseqw-3 ; i++){
    if( nda[i].nkey <= nseqw ) printf("%d b:%d\n",nda[i].nkey,nda[i].b->nkey);
    if( nda[i].nkey > nseqw ) printf("%d b:%d l:%d r:%d\n",nda[i].nkey,nda[i].b->nkey,nda[i].lc->nkey,nda[i].rc->nkey);
    
    }
    */
  return(0);
}

rdline(fp,b,n)
     int *n;
     char *b;
     FILE *fp;
{
  int c,np;
  *n=0;
  
  np=0;
  for( ; ; ){
    c = fgetc(fp);
    if( c == EOF ) return(1);
    if( c != ' ' ) np++;
    b[*n]=c;
    (*n)++;
    if( c == '\n' ) break;
  }
  if( np == 0 ) return(2);
  return(0);
}




rdseq(fpi,nseq,nsite,seq,seqnm,maxnm)
     FILE *fpi;
     int nseq,nsite,maxnm;
     char **seq,**seqnm;
{
  int i,cw,flg,fc,sc,flg1,cw1,seqc,sitec,cn;
  /* flg  0   initial
     1   file name
     2   file name end
     3   sequence
     flg1 1   comment
     */
  cn=0;
  seqc=0;
  sitec=0;
  fc=0;
  sc=0;
  flg1=0;
  flg = 0;
  cw =0;
  cw1=0;
  for( ; ; ){
    cw1=cw;
    if( cw1 != EOF ) cw = getc(fpi);
    if( cw1 == EOF ) break;
    cn++;
    if( cn == 1 ) continue;
    if( cw1 == '/' && cw == '*' ){
      flg1 = 1;
      continue;
    }
    if( flg1 == 1 ) {
      if( cw1 == '*' && cw == '/' ){
	flg1=0;
      }
      continue;
    }
    
    
    switch(flg){
    case 0: if( cw1 == ' ' || cw1 == '\t' ) break;
      if( cw1 == '\n' ) break;
      flg=1;
      seqnm[seqc][fc]=cw1;
      fc++;
      if( fc > maxnm ) printf("fc=%d maxnm=%d seq %d\n",fc,maxnm,seqc);
      break;
    case 1: if( cw1 == ' ' || cw1 == '\t' ) {
      fc=0;
      flg = 2;
      break;
    }
    if( cw1 == '\n' ){
      fprintf(ERR,"format error (1) in data file\n");
      exit(1);
    }
    seqnm[seqc][fc]=cw1;
    fc++;
    if( fc > maxnm ) printf("fc=%d maxnm=%d seq %d\n",fc,maxnm,seqc);
    break;
    case 2: if( cw1 == ' ' || cw1 == '\t' ) break;
      if( cw1 == '\n' ){
	fprintf(ERR,"format error (2) in data file\n");
	exit(1);
      }
      flg=3;
      seq[sc][seqc]=cw1;
      sc++;
      break;
    case 3: if( cw1 == '\n'){
      if( sc != nsite ){
	fprintf(stderr,"nsite is not the same %d (in seq %d)\n",sc,(seqc)+1);
	exit(1);                                                                    }
      seqc++;
      if( seqc > nseq ) printf("seqc=%d nseq=%d\n",seqc,nseq);
      flg=0;
      sc=0;
      fc=0;
      break;
    }
    if( cw1 == ' ' || cw1 == '\t' ) break;
    seq[sc][seqc]=cw1;
    sc++;
    break;
    default: break;
    }
    
  }
  if( sc != 0 ){
    if( sc != nsite ){
      fprintf(stderr,"nsite is not the same %d (in seq %d)\n",sc,seqc+1);
      exit(1);                                                                    }
    seqc++;
  }
  if( seqc != nseq ){
    printf("sequence number inconsistency seqc=%d nseq=%d\n",seqc,nseq);
    exit(1);
  }
  
  
  /*   printf("rdseq seqc=%d\n",seqc); */
  /*   for(i=0; i<nseq ; i++) printf("%d %s\n",i+1,seqnm[i]); */
  
  return(0);
}



checkfl(fpi,nseq,nsite,maxnm)
     FILE *fpi;
     int *nseq,*nsite,*maxnm;
{
  int cw,flg,fc,sc,flg1,cw1;
  /* flg  0   initial
     1   file name
     2   file name end
     3   sequence
     flg1 1   comment
     */
  
  *nseq=0;
  *nsite =0;
  *maxnm=0;
  fc=0;
  sc=0;
  flg1=0;
  flg = 0;
  cw =0;
  cw1=0;
  for( ; ; ){
    cw1=cw;
    if( cw1 != EOF ) cw = getc(fpi);
    if( cw1 == EOF ) break;
    if( cw1 == '/' && cw == '*' ){
      flg1 = 1;
      continue;
    }
    if( flg1 == 1 ) {
      if( cw1 == '*' && cw == '/' ){
	flg1=0;
      }
      continue;
    }
    switch(flg){
    case 0: if( cw1 == ' ' || cw1 == '\t' ) break;
      if( cw1 == '\n' ) break;
      flg=1;
      fc++;
      break;
    case 1: if( cw1 == ' ' || cw1 == '\t' ) {
      if( fc > *maxnm ) *maxnm=fc;
      fc=0;
      flg = 2;
      break;
    }
    if( cw1 == '\n' ){
      fprintf(ERR,"format error (1) in data file\n");
      exit(1);
    }
    fc++;
    break;
    case 2: if( cw1 == ' ' || cw1 == '\t' ) break;
      if( cw1 == '\n' ){
	fprintf(ERR,"format error (2) in data file\n");
	exit(1);
      }
      flg=3;
      sc++;
      break;
    case 3: if( cw1 == '\n'){
      if( *nseq == 0 ) {
	*nsite = sc;
      }else{
	if( sc != *nsite ){
	  fprintf(ERR,"nsite is not the same %d (in seq %d)\n",sc,(*nseq)+1);
	  exit(1);                                                                    }
      }
      (*nseq)++;
      flg=0;
      sc=0;
      fc=0;
      break;
    }
    if( cw1 == ' ' || cw1 == '\t' ) break;
    sc++;
    }
    
  }
  if( sc != 0 ){
    if( sc != *nsite ){
      fprintf(ERR,"nsite is not the same %d (in seq %d)\n",sc,(*nseq)+1);
      exit(1);                                                                    }
    (*nseq)++;
  }
  return(0);
}


delchk(a,nseq0,nsite,npsite,nasite,asite,cdnpos,a0site)
     int nseq0,nsite,*npsite,*nasite,*asite,cdnpos[3],*a0site;
     char **a/*[MAXSITE][MAXOTU]*/;
{
  int i,j,k,flg,iw,pol,del,nbs,nmis;
  
  
  nmis=0;
  printf("missing sites:");
  (*npsite) =0;
  (*nasite) =0;
  for(i=0; i<nsite ; i++){
    a0site[i]=-2;
    del=0;
    pol=0;
    for(j=0; j<nseq0; j++){
      if( del != 0 ) break;
      flg=0;
      /*          if( dflg == 1 ) printf("a[%d][%d]=%c %x\n",i,j,a[i][j],a[i][j]); */
      if( a[i][j] == '.' ) {
	a[i][j] = a[i][0];
      }else{
	
	for(k=0; k<8 ; k++){
	  if( a[i][j] == base[k] ) {
	    a[i][j]=k; 
	    flg=1;
	    break;
	  }
	}
	if( flg == 0 ){
	  printf("seq %d site %d  invalid base %c %x\n",j+1,i+1,a[i][j],a[i][j]);
	  exit(1);
	}
      }
      if( a[i][j] > 3 ){
	del=1;   
	break;
      }
      if( a[i][j] != a[i][0] ) pol=1;
      
      
    }
    
    if( del != 0  ){
      printf(" %d",i+1);
      nmis++;
      if( nmis%20 == 0 ) printf("\n");
      continue;
    }
    if( cdnpos[i%3] == 0 ) continue;
    a0site[i] = -1;
    (*nasite)++;
    if( pol == 1 ){
      asite[(*npsite)]=i;
      a0site[i] = (*npsite);
      (*npsite)++;
    }
  }
  printf("\n");
  
  return(0);
}



delchka(a,nseq0,nsite,npsite,nasite,asite,a0site)
     int nseq0,nsite,*npsite,*nasite,*asite,*a0site;
     char **a/*[MAXSITE][MAXOTU]*/;
{
  int i,j,k,flg,iw,pol,del,nbs;
  (*npsite) =0;
  (*nasite) =0;
  printf("delchka\n");
  fflush(stdout);
  for(i=0; i<nsite ; i++){
    del=0;
    pol=0;
    a0site[i]=-2;
    for(j=0; j<nseq0; j++){
      if( del != 0 ) break;
      flg=0;
      /*          if( dflg == 1 ) printf("a[%d][%d]=%c %x\n",i,j,a[i][j],a[i][j]); */
      if( a[i][j] == '.' ){
	a[i][j] = a[i][0];
      }else{
	for(k=0; k<24 ; k++){
	  if( a[i][j] == amn[k] ) {
	    a[i][j]=k; 
	    flg=1;
	    break;
	  }
	}
	if( flg == 0 ){
	  printf("seq %d site %d  invalid amn %c %x\n",j+1,i+1,a[i][j],a[i][j]);
	  exit(1);
	}
      }
      if( a[i][j] > 19 ){
	del=1;   
	break;
      }
      if( a[i][j] != a[i][0] ) pol=1;
      
      
    }
    
    if( del != 0  ) continue;
    (*nasite)++;
    a0site[i]=-1;
    if( pol == 1 ){
      a0site[i]=(*npsite);
      asite[(*npsite)]=i;
      (*npsite)++;
    }
  }
  printf("delchka\n");
  fflush(stdout);
  return(0);
}



dwnarg(cur,anc)
     struct nds *cur, *anc;
{
  struct nds *pw;
  double *bw,dnc,dw1,dw;
  int flg,i,j,nw,nm,nc,na,iw,*ip;
  unsigned char nx,ny, *pc;
  
  /* printf("dwnarg cur %d anc %d\n",cur->nkey,anc->nkey); 
     if( cur->b != NULL ) printf("cur b %d",cur->b->nkey);
     if( cur->lc != NULL ) printf("cur l %d",cur->lc->nkey);
     if( cur->rc != NULL ) printf("cur r %d",cur->rc->nkey);
     printf("cur->lc=%p anc=%p cur->rc=%p cur->b=%p\n",cur->lc,anc,cur->rc,cur->b);
     printf("\n");
     fflush(stdout); 
     */
  flg = 0;
  if( cur->b  == anc ) flg += 1;
  if( cur->lc == anc ){
    flg += 2;
    pw=cur->lc;
    cur->lc = cur->b;
    cur->b = pw;
    bw = cur->blcx;
    cur->blcx = cur->bbx;
    cur->bbx=bw;
    ip = cur->bstlcx;
    cur->bstlcx = cur->bstbx;
    cur->bstbx=ip;
    pc = cur->plcx;
    cur->plcx = cur->pbx;
    cur->pbx=pc;
  }
  
  if( cur->rc == anc ){
    pw=cur->rc;
    cur->rc = cur->b;
    cur->b = pw;
    bw = cur->brcx;
    cur->brcx = cur->bbx;
    cur->bbx=bw;
    ip = cur->bstrcx;
    cur->bstrcx = cur->bstbx;
    cur->bstbx=ip;
    
    pc = cur->prcx;
    cur->prcx = cur->pbx;
    cur->pbx=pc;
    
    flg += 3;
  }
  
  if( flg < 1 || flg > 3 ){
    printf("flg =%d\n",flg);
    exit(1);
  }
  if( cur->rc != NULL) {
    dwnarg(cur->rc,cur);
  }
  
  if( cur->lc != NULL) {
    dwnarg(cur->lc,cur);
  }
  
  
  return(0);
  
}


dwnarg1(cur,anc)
     struct nds *cur, *anc;
{
  struct nds *pw;
  double *bw,dnc,dw1,dw;
  int flg,i,j,nw,nm,nc,na,iw,*ip;
  unsigned char nx,ny, *pc;
  
  /* printf("dwnarg cur %d anc %d\n",cur->nkey,anc->nkey); 
     if( cur->b != NULL ) printf("cur b %d",cur->b->nkey);
     if( cur->lc != NULL ) printf("cur l %d",cur->lc->nkey);
     if( cur->rc != NULL ) printf("cur r %d",cur->rc->nkey);
     printf("cur->lc=%p anc=%p cur->rc=%p cur->b=%p\n",cur->lc,anc,cur->rc,cur->b);
     printf("\n");
     fflush(stdout); 
     */
  flg = 0;
  /*    printf("cur %d upflg=%d\n",cur->nkey,comm.upflg); */
  
  if( cur->b  == anc ) flg += 1;
  if( cur->lc == anc ){
    flg += 2;
    pw=cur->lc;
    cur->lc = cur->b;
    cur->b = pw;
    bw = cur->blcx;
    cur->blcx = cur->bbx;
    cur->bbx=bw;
    ip = cur->bstlcx;
    cur->bstlcx = cur->bstbx;
    cur->bstbx=ip;
    pc = cur->plcx;
    cur->plcx = cur->pbx;
    cur->pbx=pc;
  }
  
  if( cur->rc == anc ){
    pw=cur->rc;
    cur->rc = cur->b;
    cur->b = pw;
    bw = cur->brcx;
    cur->brcx = cur->bbx;
    cur->bbx=bw;
    ip = cur->bstrcx;
    cur->bstrcx = cur->bstbx;
    cur->bstbx=ip;
    
    ip = cur->bstrcx1;
    cur->bstrcx1 = cur->bstbx1;
    cur->bstbx1=ip;
    
    pc = cur->prcx;
    cur->prcx = cur->pbx;
    cur->pbx=pc;
    
    flg += 3;
  }
  
  if( flg < 1 || flg > 3 ){
    printf("flg =%d\n",flg);
    exit(1);
  }
  
  
  if( cur->rc != NULL) {
    dwnarg1(cur->rc,cur);
  }
  
  if( cur->lc != NULL) {
    dwnarg1(cur->lc,cur);
  }
  
  if( cur->rc != NULL && cur->lc != NULL){
    cur->nstate=0;
    if( cur->rc->nstate == 0 ) {
      printf("state is not set up node %d\n",cur->rc->nkey);
      exit(1);
    }
    if( cur->lc->nstate == 0 ) {
      printf("state is not set up node %d\n",cur->lc->nkey);
      exit(1);
    }
    for(i=0; i<cur->rc->nstate ; i++){
      for(j=0; j<cur->lc->nstate ; j++){
	if( cur->rc->states[i] == cur->lc->states[j] ){
	  cur->states[cur->nstate]=cur->rc->states[i];
	  (cur->nstate)++;
	  break;
	}
      }
    }
    if( cur->nstate == 0 ){
      flg=0;
      for(i=0; i<cur->rc->nstate ; i++) cur->states[i]=cur->rc->states[i];
      for(i=0; i<cur->lc->nstate ; i++) cur->states[cur->rc->nstate+i]=cur->lc->states[i];
      cur->nstate = cur->lc->nstate + cur->rc->nstate;
      (comm.nsub)++;
    }
    if( dflg == 1 ){
      printf("cur %d nstate %d rc%d lc %d  nsub=%d\n",cur->nkey,cur->nstate,cur->rc->nkey,cur->lc->nkey,comm.nsub);
      for(i=0; i<cur->nstate; i++) {
	if( comm.amnflg == 0 ) printf(" %c",base[cur->states[i]]);
	if( comm.amnflg == 1 ) printf(" %c",amn[cur->states[i]]);
      }
      printf("\n");
      
    }
    
  }
  
  
  return(0);
}



under(ac,cur,nmem,nmeml)
     struct nds *ac,*cur;
     int *nmem,*nmeml;
{
  struct nds *pw;
  double *bw,dsum,ra,rb;
  int flg,i,j,nw;
  unsigned char nx,ny, *pc;
  /* printf("nseq=%d  cur=%d\n",nseq,cur->nkey); 
     fflush(stdout); 
     */
  flg = 0;
  if( cur->b  == ac ) flg += 1;
  if( cur->lc == ac ){
    flg += 2;
    pw=cur->lc;
    cur->lc = cur->b;
    cur->b = pw;
    bw = cur->blcx;
    cur->blcx = cur->bbx;
    cur->bbx=bw;
    
    pc = cur->plcx;
    cur->plcx = cur->pbx;
    cur->pbx=pc;
  }
  
  if( cur->rc == ac ){
    pw=cur->rc;
    cur->rc = cur->b;
    cur->b = pw;
    bw = cur->brcx;
    cur->brcx = cur->bbx;
    cur->bbx=bw;
    pc = cur->prcx;
    cur->prcx = cur->pbx;
    cur->pbx=pc;
    flg += 3;
  }
  
  if( flg < 1 || flg > 3 ){
    printf("flg =%d\n",flg);
    exit(1);
  }
  
  
  if( cur->rc != NULL) {
    under(cur,cur->rc,nmem,nmeml);
  }
  
  if( cur->lc != NULL) {
    under(cur,cur->lc,nmem,nmeml);
  }
  if( cur->lc != NULL && cur->rc != NULL){
    if( cur->lc->nkey <= comm.nseq ) {
      cur->plcx=NULL;
      nw=cur->lc->nkey;
      nmeml[*nmem]=nw;
      (*nmem)++;
    }
    if( cur->rc->nkey <= comm.nseq ) {
      cur->prcx=NULL;
      nw=cur->rc->nkey;
      nmeml[*nmem]=nw;
      (*nmem)++;
    }
  }
  
  
  
  
  
  
  
  return(0);
}

setsite(nseq,a,siten,nda,asite)
     int nseq,siten,asite[];
     char **a/*[MAXSITE][MAXOTU]*/;
     Nds *nda/*[2*MAXOTU-2]*/;
{
  int i,nw;
  char cw;
  
  for(i=0; i<nseq ; i++){
    nda[i].nstate=1;
    nda[i].states[0]=cw=a[asite[siten]][i];
  }
  return(0);
}


Nds *Ndsvector(n)
     int n;
{
  Nds *vp;
  
  vp = (Nds *)malloc((unsigned) n*sizeof(Nds));
  if( !vp ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"integer vector[%d]\n",n);
    exit(1);
  }
  return(vp);
}

Nds **Ndspvector(n)
     int n;
{
  Nds **vp;
  
  vp = (Nds **)malloc((unsigned) n*sizeof(Nds *));
  if( !vp ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"integer vector[%d]\n",n);
    exit(1);
  }
  return(vp);
}

int *ivector(n)
     int n;
{
  int *vp;
  
  vp = (int *)malloc((unsigned) n*sizeof(int));
  if( !vp ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"integer vector[%d]\n",n);
    exit(1);
  }
  return(vp);
}
char *cvector(n)
     int n;
{
  char *vp;
  
  vp = (char *)malloc((unsigned) n*sizeof(char));
  if( !vp ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"char vector[%d]\n",n);
    exit(1);
  }
  return(vp);
}

double *dvector(n)
     int n;
{
  double *vp;
  
  vp = (double *)malloc((unsigned) n*sizeof(double));
  if( !vp ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"double vector[%d]\n",n);
    exit(1);
  }
  return(vp);
}

int **imatrix(n1,n2)
     int n1,n2;
{
  int i,**ip;
  
  ip = (int **) malloc((unsigned ) n1*sizeof(int*) );
  if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 integer matrix %d %d\n",n1,n2);
    exit(1);
  }
  for(i=0; i<n1 ; i++){
    ip[i] = (int *) malloc((unsigned) n2*sizeof(int));
    if( !ip[i] ) {
      fprintf(ERR,"memory allocation error\n");
      fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
      exit(1);
      
    }
  }
  
  return(ip);
  
}




char **cmatrix(n1,n2)
     int n1,n2;
{
  int i;
  char **ip;
  
  ip = (char **) malloc((unsigned ) n1*sizeof(char*) );
  if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
  for(i=0; i<n1 ; i++){
    ip[i] = (char *) malloc((unsigned) n2*sizeof(char));
    if( !ip[i] ) {
      fprintf(ERR,"memory allocation error\n");
      fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
      exit(1);
      
    }
  }
  
  return(ip);
}


unsigned char **ucmatrix(n1,n2)
     int n1,n2;
{
  int i;
  unsigned char **ip;
  
  ip = (unsigned char **) malloc((unsigned ) n1*sizeof(char*) );
  if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
  for(i=0; i<n1 ; i++){
    ip[i] = (unsigned char *) malloc((unsigned) n2*sizeof(char));
    if( !ip[i] ) {
      fprintf(ERR,"memory allocation error\n");
      fprintf(ERR,"step2(i=%d) integer matrix %d %d\n",i,n1,n2);
      exit(1);
      
    }
  }
  
  return(ip);
  
}




double **dmatrix(n1,n2)
     int n1,n2;
{
  int i;
  double **ip;
  
  ip = (double **) malloc((unsigned ) n1*sizeof(double*) );
  if( !ip ) {
    fprintf(ERR,"memory allocation error\n");
    fprintf(ERR,"step1 char matrix %d %d\n",n1,n2);
    exit(1);
  }
  for(i=0; i<n1 ; i++){
    ip[i] = (double *) malloc((unsigned) n2*sizeof(double));
    if( !ip[i] ) {
      fprintf(ERR,"memory allocation error\n");
      fprintf(ERR,"step2(i=%d) double matrix %d %d\n",i,n1,n2);
      exit(1);
      
    }
  }
  
  return(ip);
  
}




void free_ivector(v,n)
     int *v,n;
{
  free((char*) v );
  return ;
}

void free_dvector(v,n)
     double *v;
     int n;
{
  free((char*) v );
  return ;
}


void free_cvector(v,n)
     char *v;
     int n;
{
  free((char*) v );
  return ;
}


void free_cmatrix(m,n1,n2)
     char **m;
     int n1,n2;
{
  int i;
  
  for(i=n1-1 ; i >= 0 ; i-- ){
    free((char *) (m[i]));
  }
  free((char *) m);
}

void free_imatrix(m,n1,n2)
     int  **m;
     int n1,n2;
{
  int i;
  
  for(i=n1-1 ; i >= 0 ; i-- ){
    free((char *) (m[i]));
  }
  free((char *) m);
}


void free_dmatrix(m,n1,n2)
     double  **m;
     int n1,n2;
{
  int i;
  
  for(i=n1-1 ; i >= 0 ; i-- ){
    free((char *) (m[i]));
  }
  free((char *) m);
}

double *games(char *seqfile, char *treefile)
{
  struct nds *cur,*anc;
  FILE *fpi,*fpo=stdout,*fpt;
  float fw;
  char **a/*[MAXSITE][MAXOTU]*/;
  int i,j,k,l,rn,ifc,itc,iw,outflg,n1,n2,nbst,nseqw,maxnm;
  int nsite,npsite,nasite,sc,nw,flg;
  int dop=0,outgroup=0,noutg,*outg/*[MAXOTU]*/,nfnode,*fnode/*[MAXOTU]*/;
  int *nsub/*[MAXSITE]*/,ns,*asite/*[MAXSITE]*/,cdnpos[3],*a0site/*[MAXSITE]*/;
  int fin;
  double *blen/*[2*MAXOTU-2]*/,xscale=1.0,yscale=1.0,linew=0.5;
  double dw,dw1,db,dn,dw2,dw3,dwt,dwb,dwl,dwr;
  double msub,vsub;
  char fps[20];
  char cw;
  double *alpha, alpha_wk;

  dflg=0;
  noutg=1;
  nfnode=0;
  outflg=0;
  comm.amnflg=0;
  cdnpos[0]=cdnpos[1]=cdnpos[2]=1;
  
  if((fpi = fopen(seqfile,"r")) == NULL ){
    printf("Can't open file %s\n",seqfile);
    exit(1);
  }
  if( (fpt = fopen(treefile,"r")) == NULL ){
    printf("Can't open %s\n", treefile);
    exit(1);
  }
  comm.amnflg=1; /* Amino acid */
  if( comm.amnflg == 0 ) fprintf(fpo,"nucleotide sequence data\n");
  if( comm.amnflg == 1 ) fprintf(fpo,"amino acid sequence data\n");
  comm.nseq=0;
  nsite=0;
  checkfl(fpi,&comm.nseq,&nsite,&maxnm);
  fclose(fpi);
  if( (fpi= fopen(seqfile,"r")) == NULL ){
    fprintf(fpo,"Can't open file %s\n",treefile);
    exit(1);
  }
  
  comm.part = ucmatrix(comm.nseq-2,(comm.nseq-1)/8+1);
  comm.fl = cmatrix(comm.nseq,maxnm+1);
  comm.nlr = ivector(comm.nseq);
  comm.nll = ivector(comm.nseq);
  comm.nlb = ivector(comm.nseq);
  nda = Ndsvector(2*comm.nseq-2);
  adpart = Ndspvector(comm.nseq-2);
  a = cmatrix(nsite,comm.nseq);
  nsub = ivector(nsite);
  asite = ivector(nsite);
  a0site = ivector(nsite);
  blen = dvector(2*comm.nseq-2);
  
  for(i=0; i<comm.nseq ; i++){
    for(j=0; j< maxnm+1 ; j++) comm.fl[i][j]=0;
  }
  rdseq(fpi,comm.nseq,nsite,a,comm.fl,maxnm);
  
  rdtv(fpt,&nseqw,comm.fl,nda,blen);
  fclose(fpi);  
  fclose(fpt);
  if( nseqw != comm.nseq ){
    printf("nseq inconsistent %d %d\n",nseqw,comm.nseq);
    exit(1);
  }   
  /*   printf("delchk\n"); */
  
  if( comm.amnflg == 0 ) delchk(a,comm.nseq,nsite,&npsite,&nasite,asite,cdnpos,a0site);
  if( comm.amnflg == 1 ) delchka(a,comm.nseq,nsite,&npsite,&nasite,asite,a0site);
  
  for(i=0; i<(comm.nseq-1)/8+1 ; i++){
    for(j=0; j<comm.nseq-2; j++) comm.part[j][i]=0;
  }
  
  fprintf(fpo,"datafile %s: topology file %s\n   # of sequences = %d\n   # of sites = %d\n   # of actual sites = %d\n   # of polymorphic sites = %d\n",seqfile,treefile,comm.nseq,nsite,nasite,npsite);
  
  if( cdnpos[0]+cdnpos[1]+cdnpos[2] != 3 ){
    fprintf(fpo,"codon position:");
    for(i=0; i<3 ; i++){
      if( cdnpos[i] == 1 ) fprintf(fpo," %d",i+1);
    }
    fprintf(fpo,"\n");
  }
  
  /*fprintf(fpo,"outgroup:");
    for(i=0; i<noutg ; i++) fprintf(fpo,"  %d %s",outg[i],comm.fl[outg[i]-1]);
    */
  fprintf(fpo,"\n");
  
  
  for(i=0; i<npsite ; i++){
    nsub[i]=0;
  }
  comm.bt1 = &nda[0];
  comm.bt2 = nda[0].b;
  dwnarg(comm.bt1,comm.bt2);
  dwnarg(comm.bt2,comm.bt1);
  msub=0.0;
  vsub=0.0;
  for(i=0; i<npsite; i++){
    setsite(comm.nseq,a,i,nda,asite);
    comm.nsub=0;
    dwnarg1(comm.bt2,comm.bt1);
    dwnarg1(comm.bt1,comm.bt2);
    ns=0;
    if( dflg == 1 ) printf("site %d nsub %d\n",asite[i],comm.nsub);
    for(j=0; j<comm.bt1->nstate ; j++){
      for(k=0; k<comm.bt2->nstate ; k++){
	if( comm.bt1->states[j] == comm.bt2->states[k] ) ns++;
      }
    }
    if( ns == 0 ) comm.nsub++;
    nsub[i]=comm.nsub;
    /*       printf("site %d  sub %d\n",asite[i]+1,nsub[i]); */
    msub += comm.nsub;
    vsub += comm.nsub*comm.nsub;
  }
  msub /= nasite; /* Expectation */
  vsub /= nasite;
  vsub -= msub*msub; /* Variance */
  /* Wrong? */
  alpha_wk = msub*msub/(vsub-msub);
  /*
  alpha_wk = msub*msub/vsub;
  */
  if (alpha_wk < 0)
    alpha_wk = 99.0;
  alpha = &alpha_wk;
  fprintf(fpo,"gamma parameter a=%f mean=%f variance=%f\n",*alpha,msub,vsub);
  return alpha;
}











